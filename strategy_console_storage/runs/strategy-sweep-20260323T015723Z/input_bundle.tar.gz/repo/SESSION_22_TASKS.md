SESSION 22 TASKS — Fix Remote Python Version for GCP Runner + Quick Re-Run

Context

Session 21 infra hardening mostly worked.
The real quick-test run failed on the sweep VM before engine start, during dependency install.

Confirmed preserved status from failed run:

state: failed
stage: pip
message: Dependency installation failed

Confirmed pip failure from preserved runner log:

No matching distribution found for numpy==2.1.4

Root cause:
The remote runner is using a Python version too new for the pinned dependency stack. NumPy’s official notes show NumPy 2.2.0 supports Python 3.11–3.13, with Python 3.14 support arriving later, which is consistent with the observed failure.

Goal

Make the GCP runner use a known-good Python version explicitly for remote cloud runs, then do a quick dry run + quick real run to verify the fix.

Do not change strategy logic.
Do not touch the core engine beyond what is needed for runner stability.

Step 1 — Force remote runner to use Python 3.12 explicitly

Find where the remote VM bootstrap / remote_runner.sh / launcher-generated runner script creates the venv.

Right now it likely does something like:

python3 -m venv "$RUN_ROOT/venv"

or otherwise relies on the system default python3.

Change this so the remote runner:

installs Python 3.12 and venv support explicitly
uses python3.12 explicitly for venv creation
fails fast with a clear error if python3.12 is unavailable

Expected shape:

sudo apt-get update
sudo apt-get install -y python3.12 python3.12-venv python3.12-dev

python3.12 --version

python3.12 -m venv "$RUN_ROOT/venv"
source "$RUN_ROOT/venv/bin/activate"

python --version
pip --version
python -m pip install --upgrade pip
pip install -r requirements.txt

Important:

do not rely on python3
do not rely on whatever Ubuntu currently points to by default
remote runs must be deterministic

Commit: fix: force remote GCP runner to use python3.12 for venv creation

Step 2 — Add explicit environment logging to runner logs

Before pip install, add clear logging lines into the remote runner log:

echo "[env] system python:"
command -v python3 || true
python3 --version || true

echo "[env] required python:"
command -v python3.12 || true
python3.12 --version || true

echo "[env] venv python:"
python --version || true
pip --version || true

This must end up in runner.log so future failures are obvious immediately.

Commit: chore: log remote python and pip versions before dependency install

Step 3 — Fail fast with a better error if python3.12 is missing

If python3.12 install or lookup fails, the runner should set a clear failure state in run_status.json, not just generic pip failure.

Preferred message:

{
  "state": "failed",
  "stage": "python_bootstrap",
  "message": "python3.12 not available on remote VM"
}

If Python bootstrap succeeds but pip install fails, keep the existing pip-stage failure behavior.

Commit: fix: add explicit python bootstrap failure state for remote runner

Step 4 — Add/adjust launcher test coverage

Add fast local tests for the runner-generation logic or helper logic that confirm:

generated remote runner references python3.12
it does not create the venv with plain python3
environment logging lines are present
bootstrap failure state path is covered if testable without GCP

Keep tests local-only.
Do not require actual cloud access.

Commit: test: cover remote runner python3.12 bootstrap and logging

Step 5 — Update docs

Update CLAUDE.md and CHANGELOG_DEV.md.

CHANGELOG_DEV.md

Add a new Session 22 entry at the top:

quick-test failure root cause was remote dependency bootstrap, not engine logic
failed run preserved run_status.json with stage=pip
numpy==2.1.4 install failure traced to remote Python version mismatch
remote runner now explicitly installs and uses Python 3.12
added environment logging for Python/pip versions
next step is quick validation run on GCP
CLAUDE.md

Update known issues / resolved issues to reflect:

Python 3.14 drift on remote/cloud environments can break pinned stack
cloud runner now pins Python 3.12 explicitly for remote venv creation

Commit: docs: record session 22 python bootstrap fix and remote dependency root cause

Step 6 — Run local validation

Run at minimum:

python -m pytest tests/test_smoke.py -v
python -m pytest tests/test_cloud_launcher.py -v

If runner-related tests live elsewhere, include them too.

Fix any failures before push.

Commit (only if needed): fix: resolve test issues from session 22 runner changes

Step 7 — Push to GitHub
git push origin main

Confirm the new commit is on main.

Step 8 — Re-run quickly
8A. Dry run first

Run:

python run_cloud_sweep.py --config cloud/config_quick_test.yaml --dry-run

or if the repo expects:

python -m cloud.launch_gcp_run --config cloud/config_quick_test.yaml --dry-run

Acceptance:

config loads
dataset resolves correctly
bundle/manifest build correctly
no cloud resources created
8B. Quick real run

Run the quick test config for real immediately after dry run.

Acceptance:

VM launches
remote runner starts
run_status.json gets past python_bootstrap / pip
engine actually starts this time
artifacts or preserved logs are available
VM is destroyed automatically if run completes cleanly
if run fails, preserved logs must clearly show the new Python bootstrap environment lines
Final report required from Codex

Do not say it is done unless all of these are provided:

commit hash pushed to GitHub
exact file(s) changed
confirmation that generated remote runner now uses python3.12
test results
dry-run result
quick real-run result
whether the VM auto-destroyed or had to be preserved
if preserved, exact preserved run_status.json and relevant log tail
Non-goals

Do not:

change strategy rules
change refinement logic
alter dataset architecture
rework dashboard layout in this session unless needed for compatibility

This is a runner environment fix + rapid validation session only.