# SESSION 4: Structured logging + cloud launcher fix

Read CLAUDE.md and CHANGELOG_DEV.md first for full project context.

This session has 4 steps. Work through them in order. After each step, git commit with the message shown. Do NOT move to the next step until the current one compiles cleanly (run `python -c "import master_strategy_engine"` to verify imports).

---

## STEP 1: Create `modules/progress.py` — structured progress tracker

Create a new module `modules/progress.py` that replaces scattered print statements with structured, timestamped progress logging. This is critical for monitoring cloud runs via SSH.

### What to build

A `ProgressTracker` class that:

1. Writes timestamped log lines to stdout in this exact format:
```
[2026-03-18 04:23:15] [MR] [SWEEP] 342/968 (35.3%) — ETA 5.2 min
[2026-03-18 04:25:01] [MR] [PROMOTION] 9 candidates promoted (cap=20)
[2026-03-18 04:25:02] [MR] [REFINEMENT] 48/768 (6.3%) — ETA 12.1 min
[2026-03-18 04:40:55] [MR] [LEADERBOARD] Leader: RefinedMR_HB12 PF=1.71 OOS_PF=1.80
[2026-03-18 04:41:00] [PORTFOLIO] Evaluating 2 strategies...
[2026-03-18 04:41:30] [DONE] Total runtime: 1043.2s
```

2. Maintains and writes a `status.json` file to the output directory, updated at each stage transition and every N iterations during sweeps/refinements. The file should contain:
```json
{
  "timestamp": "2026-03-18T04:23:15",
  "dataset": "ES_60m",
  "current_family": "mean_reversion",
  "current_stage": "SWEEP",
  "progress_pct": 35.3,
  "items_done": 342,
  "items_total": 968,
  "elapsed_seconds": 312.5,
  "eta_seconds": 580.0,
  "families_completed": ["trend"],
  "families_remaining": ["breakout"],
  "last_event": "SWEEP combo 342/968"
}
```

3. Update frequency for status.json: every 10% of items in sweeps/refinements, plus at every stage transition (start of sweep, promotion, refinement, leaderboard, portfolio eval, done).

### Implementation details

```python
# modules/progress.py
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ProgressTracker:
    """Structured progress tracking for cloud monitoring."""

    def __init__(self, output_dir: str | Path, dataset_label: str = ""):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.dataset_label = dataset_label
        self.status_path = self.output_dir / "status.json"
        self.start_time = time.perf_counter()
        self.families_completed: list[str] = []
        self.families_remaining: list[str] = []
        self._current_family = ""
        self._current_stage = ""
        self._stage_start = time.perf_counter()

    def _ts(self) -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _elapsed(self) -> float:
        return time.perf_counter() - self.start_time

    def log(self, family: str, stage: str, msg: str) -> None:
        prefix = f"[{self._ts()}]"
        if family:
            prefix += f" [{family.upper()[:3]}]"  # e.g. TRE, MEA, BRE
        if stage:
            prefix += f" [{stage}]"
        print(f"{prefix} {msg}", flush=True)

    def set_families(self, all_families: list[str]) -> None:
        self.families_remaining = list(all_families)

    def start_family(self, family_name: str) -> None:
        self._current_family = family_name
        if family_name in self.families_remaining:
            self.families_remaining.remove(family_name)
        self.log(family_name, "START", f"Beginning {family_name} family")
        self._write_status("STARTING", 0, 0, 0)

    def end_family(self, family_name: str) -> None:
        self.families_completed.append(family_name)
        self.log(family_name, "DONE", f"Completed {family_name} family")
        self._write_status("FAMILY_DONE", 100, 0, 0)

    def update_sweep(self, done: int, total: int) -> None:
        pct = (done / total * 100) if total > 0 else 0
        elapsed_stage = time.perf_counter() - self._stage_start
        eta = (elapsed_stage / done * (total - done)) if done > 0 else 0
        # Log every 10% or at completion
        step = max(1, total // 10)
        if done % step == 0 or done == total:
            self.log(self._current_family, "SWEEP",
                     f"{done}/{total} ({pct:.1f}%) — ETA {eta/60:.1f} min")
            self._write_status("SWEEP", pct, done, total, eta)

    def update_refinement(self, done: int, total: int) -> None:
        pct = (done / total * 100) if total > 0 else 0
        elapsed_stage = time.perf_counter() - self._stage_start
        eta = (elapsed_stage / done * (total - done)) if done > 0 else 0
        step = max(1, total // 10)
        if done % step == 0 or done == total:
            self.log(self._current_family, "REFINEMENT",
                     f"{done}/{total} ({pct:.1f}%) — ETA {eta/60:.1f} min")
            self._write_status("REFINEMENT", pct, done, total, eta)

    def log_promotion(self, count: int, cap: int) -> None:
        self.log(self._current_family, "PROMOTION",
                 f"{count} candidates promoted (cap={cap})")
        self._write_status("PROMOTION", 100, count, cap)

    def log_leaderboard(self, leader_name: str, pf: float, oos_pf: float) -> None:
        self.log(self._current_family, "LEADERBOARD",
                 f"Leader: {leader_name} PF={pf:.2f} OOS_PF={oos_pf:.2f}")
        self._write_status("LEADERBOARD", 100, 0, 0)

    def log_portfolio(self, n_strategies: int) -> None:
        self.log("", "PORTFOLIO", f"Evaluating {n_strategies} strategies...")
        self._write_status("PORTFOLIO", 0, 0, n_strategies)

    def log_done(self) -> None:
        total = self._elapsed()
        self.log("", "DONE", f"Total runtime: {total:.1f}s")
        self._write_status("DONE", 100, 0, 0)

    def reset_stage_timer(self) -> None:
        self._stage_start = time.perf_counter()

    def _write_status(self, stage: str, pct: float, done: int, total: int,
                      eta: float = 0) -> None:
        status = {
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "dataset": self.dataset_label,
            "current_family": self._current_family,
            "current_stage": stage,
            "progress_pct": round(pct, 1),
            "items_done": done,
            "items_total": total,
            "elapsed_seconds": round(self._elapsed(), 1),
            "eta_seconds": round(eta, 1),
            "families_completed": self.families_completed,
            "families_remaining": self.families_remaining,
            "last_event": f"{stage} {done}/{total}" if total > 0 else stage,
        }
        try:
            self.status_path.write_text(json.dumps(status, indent=2))
        except Exception:
            pass  # never crash the pipeline for a status write failure
```

### Git commit message: `feat: add modules/progress.py — structured progress tracker with status.json`

---

## STEP 2: Integrate ProgressTracker into master_strategy_engine.py

Wire the ProgressTracker into the main pipeline. The goal is that every stage transition and major iteration emits a structured log line.

### Changes needed in master_strategy_engine.py

1. Import ProgressTracker at the top:
```python
from modules.progress import ProgressTracker
```

2. In `_run_dataset()`, create a tracker instance and pass it through:
```python
tracker = ProgressTracker(
    output_dir=ds_output_dir,
    dataset_label=f"{ds_market}_{ds_timeframe}",
)
```

3. Set the family list at the start:
```python
tracker.set_families(family_names_to_run)  # e.g. ["trend", "mean_reversion", "breakout"]
```

4. In `_run_single_family()` (or wherever the family loop body is), add tracker calls:
   - `tracker.start_family(strategy_type_name)` at the start
   - `tracker.reset_stage_timer()` before sweep
   - After sweep completes: no change needed yet (sweep progress is inside the strategy type)
   - `tracker.log_promotion(len(promoted_df), max_promoted)` after promotion gate
   - `tracker.reset_stage_timer()` before refinement
   - `tracker.end_family(strategy_type_name)` at the end

5. After portfolio evaluation: `tracker.log_portfolio(n_strategies)`
6. At the very end: `tracker.log_done()`

### Important: Also pass tracker into sweep and refinement functions

The sweep runs inside each strategy type's `run_filter_combination_sweep()`. That function uses ProcessPoolExecutor and prints per-combo results. We need the tracker to be available there.

**Approach**: Add an optional `progress_callback` parameter to the sweep and refinement functions. The callback signature is `callback(done: int, total: int)`. In the parallel loop, call it after each result. In `master_strategy_engine.py`, pass `tracker.update_sweep` as the callback.

Specifically, modify these functions to accept an optional `progress_callback: Callable[[int, int], None] | None = None` parameter:

- `run_family_filter_combination_sweep()` in master_strategy_engine.py (the wrapper)
- Each strategy type's `run_filter_combination_sweep()` method
- `StrategyParameterRefiner.run_refinement()` in modules/refiner.py

In the executor loop of each, after processing each result:
```python
if progress_callback is not None:
    progress_callback(idx, total_runs)
```

**Do NOT break the existing function signatures** — the callback must be optional with default None so the existing code still works without it.

### Verify

After this step, a local run should produce timestamped log lines AND create a `status.json` in `Outputs/ES_60m/`. You can verify with:
```bash
python -c "
from modules.progress import ProgressTracker
t = ProgressTracker('test_output', 'ES_60m')
t.set_families(['trend', 'mean_reversion', 'breakout'])
t.start_family('trend')
t.reset_stage_timer()
import time; time.sleep(0.1)
t.update_sweep(50, 100)
t.log_promotion(5, 20)
t.end_family('trend')
t.log_done()
import json; print(json.dumps(json.loads(open('test_output/status.json').read()), indent=2))
import shutil; shutil.rmtree('test_output')
"
```

### Git commit message: `feat: integrate ProgressTracker into pipeline — structured cloud monitoring`

---

## STEP 3: Fix run_cloud_job.py — start_engine timeout

The `run_cloud_job.py` script works but `start_engine()` times out because the `ssh_exec()` call uses a 60-second default timeout. The nohup + python startup on the droplet takes longer than that.

### Find and fix

Open `run_cloud_job.py`. Find the `start_engine()` function (or wherever the engine is launched via SSH). The command will look something like:

```python
ssh_exec(client, "nohup ... master_strategy_engine.py ... &")
```

There are two possible fixes depending on the code structure:

**Option A**: If `ssh_exec` has a `timeout` parameter, increase it:
```python
ssh_exec(client, cmd, timeout=120)
```

**Option B**: If `ssh_exec` doesn't have a timeout parameter, or if the issue is that it blocks waiting for the nohup process to return, change the approach to fire-and-forget:
```python
def start_engine(client):
    """Launch the engine on the droplet without waiting for completion."""
    cmd = (
        'bash -c "cd /root/python-master-strategy-creator && '
        'nohup ./venv/bin/python master_strategy_engine.py '
        '> Outputs/logs/run_$(date +%Y%m%d_%H%M%S).log 2>&1 & '
        'echo $!"'
    )
    # Use exec_command directly with a short timeout — we only need the PID back
    stdin, stdout, stderr = client.exec_command(cmd, timeout=30)
    pid = stdout.read().decode().strip()
    print(f"Engine started with PID: {pid}")
    return pid
```

**Also check**: If there's a `wait_for_completion()` or polling loop that checks if the engine has finished, make sure it uses `status.json` from Step 1 (check if `current_stage == "DONE"`) rather than just tailing the log for the finish marker.

### Git commit message: `fix: increase ssh_exec timeout in run_cloud_job.py for engine startup`

---

## STEP 4: Update CLAUDE.md, CHANGELOG_DEV.md, and push

### 4a. Update CLAUDE.md

In the Known Issues section, check off:
- [x] Progress logging with ETA for long runs

Add a new entry under "Nice to have":
- [ ] Integrate status.json polling into run_cloud_job.py wait loop

Update "Last updated" line at the bottom to:
```
2026-03-18 — Session 4: Structured progress logging (ProgressTracker, status.json), cloud launcher timeout fix
```

### 4b. Update CHANGELOG_DEV.md

Add a new entry at the TOP of the file:

```markdown
## 2026-03-18 — Session 4: Structured logging + cloud launcher fix

**What was done**:
- Created `modules/progress.py` — ProgressTracker class with timestamped log lines and status.json output
- Integrated ProgressTracker into master_strategy_engine.py pipeline — all stage transitions and sweep/refinement progress now logged
- Added optional `progress_callback` parameter to sweep and refinement functions (backward compatible)
- Fixed `run_cloud_job.py` start_engine timeout issue (was 60s, now handles nohup startup properly)
- status.json written to each dataset's output directory, updated every 10% of sweep/refinement progress

**Output changes vs Session 3**:
- Log output now has structured timestamps and stage prefixes
- `Outputs/ES_60m/status.json` created during runs — instant progress check via `cat status.json`
- run_cloud_job.py can now start the engine without SSH timeout errors

**Verified**:
- ProgressTracker unit test passed (manual quick test)
- All imports OK
- Existing pipeline behaviour unchanged (progress_callback is optional)

**Next session priorities**:
1. Run updated engine on new DigitalOcean droplet to test structured logging
2. Analyze results from current cloud run (still in progress on 209.38.86.189)
3. Expand to additional ES timeframes (5m, 15m, 30m, daily)
4. Design master leaderboard aggregator for multi-dataset runs
```

### 4c. Final commit and push

```bash
git add -A
git commit -m "session 4 complete: structured logging, cloud launcher fix"
git push origin main
```

### Git commit message: `docs: update CLAUDE.md and CHANGELOG_DEV.md for session 4`
