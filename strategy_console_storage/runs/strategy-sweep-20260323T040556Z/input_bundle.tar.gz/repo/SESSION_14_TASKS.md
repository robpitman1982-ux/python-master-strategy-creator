# SESSION 14 TASKS — One-Click GCP Run Orchestrator

## Goal

Build a true **one-click cloud execution flow** for the strategy engine so a full run can be started from Windows with one command and automatically handle:

1. launch VM
2. run sweep
3. download results
4. destroy VM

This should build on the existing Windows-first GCP launcher work already in the repo.

Do **not** change strategy logic.

Do **not** modify `master_strategy_engine.py` unless absolutely necessary.

Focus on orchestration, safety, usability, and handoff quality.

---

## Read these first

- `CLAUDE.md`
- `CHANGELOG_DEV.md`
- `cloud/launch_gcp_run.py`
- `dashboard.py`
- `dashboard_utils.py`
- `cloud/GCP_WINDOWS_RUNBOOK.md`
- `cloud/run_gcp_job.ps1`
- `cloud/run_gcp_job.sh`
- `tests/test_cloud_launcher.py`
- `tests/test_dashboard_utils.py`
- `tests/test_smoke.py`

Also inspect the current launcher flow carefully before editing.

---

## Core objective

The launcher already does most of the workflow. Session 14 should turn it into a **clean, dependable one-click run path** for day-to-day use.

The target experience is:

```bash
python -m cloud.launch_gcp_run --config cloud/config_es_all_timeframes_gcp96.yaml

and the launcher should:

preflight
create VM
upload bundle
launch remote runner
monitor run
download artifacts/results
verify results
destroy VM automatically if successful
preserve VM only when something failed or verification did not pass

This must feel production-safe enough for overnight use.

Main tasks
1. Finalize the one-click automatic lifecycle

Review cloud/launch_gcp_run.py and ensure the normal non---keep-vm path truly behaves as:

create VM
run job
retrieve outputs
verify outputs
destroy VM

Make sure there are no hidden gaps where the VM might remain running after a successful run.

Acceptance:

on successful verified completion, the final launcher state must indicate VM destruction clearly
VM destroy should only be skipped if:
--keep-vm was explicitly set
download failed
extraction failed
verification failed
remote state failed and inspection is needed
2. Add a dedicated one-click wrapper script

Create a simple top-level Windows-friendly runner script so the user has an obvious single entry point.

Create:

run_cloud_sweep.py

Purpose:

thin wrapper around cloud.launch_gcp_run
sensible default config
easy to run from project root
optionally allow config override via CLI

Minimum default behavior:

python run_cloud_sweep.py

should be equivalent to:

python -m cloud.launch_gcp_run --config cloud/config_es_all_timeframes_gcp96.yaml

Also support:

python run_cloud_sweep.py --config cloud/config_es_all_timeframes_gcp96.yaml
python run_cloud_sweep.py --dry-run
python run_cloud_sweep.py --keep-vm

Keep it lightweight — no duplication of launcher logic.

Acceptance:

wrapper delegates to the existing launcher
wrapper is simple and maintainable
wrapper works cleanly from repo root on Windows
3. Make final result download behavior more explicit

Right now the launcher downloads preserved artifacts tarball-first. Strengthen the user-facing behavior so the downloaded output location is obvious and useful.

Ensure the final local run folder clearly contains:

run_manifest.json
launcher_status.json
launcher_status.jsonl
artifacts.tar.gz
extracted artifacts directory
preserved logs
preserved outputs

If helpful, add a small LATEST_RUN.txt or similar pointer in cloud_results/ that contains the latest run directory name/path.

Acceptance:

the user can easily find the most recent run output locally
final console output clearly prints the exact local results path
dashboard can naturally pick up the latest run
4. Improve final console summary

At the end of a real run, print a concise but very clear summary such as:

run_id
local results path
run outcome
vm outcome
whether billing should have stopped
whether verification passed

For example:

run_completed_verified
vm_destroyed
Billing should now be stopped

or if something failed:

remote_failed_artifacts_preserved
vm_preserved_for_inspection
Billing may still be active

Acceptance:

user should not need to interpret raw state files to know whether the run succeeded and whether the VM is still billing
5. Add a lightweight “latest run” helper for dashboard usability

If not already present in a reliable way, make it easy for the dashboard and the user to identify the newest completed run.

Acceptable approaches:

write/update cloud_results/LATEST_RUN.txt
or another tiny helper file
or a robust helper function if already sufficient

Keep this very lightweight.

Acceptance:

dashboard defaults cleanly to the newest run
user can quickly identify where the latest outputs landed
6. Tighten docs for the one-click path

Update docs so the one-click path is crystal clear.

Update as appropriate:

cloud/GCP_WINDOWS_RUNBOOK.md
CLAUDE.md
CHANGELOG_DEV.md

Docs should clearly distinguish:

dry run
safe first run with VM preserved
normal one-click run

Make the recommended commands explicit:

python run_cloud_sweep.py --dry-run
python run_cloud_sweep.py --keep-vm
python run_cloud_sweep.py

and also note the equivalent launcher commands.

Acceptance:

a new chat or new LLM should be able to understand the intended workflow immediately from repo docs
no confusing outdated instructions remain as the primary guidance
7. Add/adjust tests

Update tests with fast local-only coverage for the wrapper and final lifecycle behavior where practical.

Add/update tests for:

wrapper delegates correctly to launcher arguments
one-click defaults resolve to expected config
final success state shaping is preserved
latest-run helper behavior if implemented
no live GCP required

Do not add brittle integration tests.

Acceptance:

tests remain fast
no real cloud dependency
launcher/wrapper behavior is better protected
Non-goals

Do not:

redesign the engine
change strategy scoring
modify parameter sweeps
add multi-VM orchestration yet
add exact live GCP billing integration yet

This session is about finishing the single-VM one-click workflow properly.

Acceptance criteria
The user can run:
python run_cloud_sweep.py

to launch a full sweep from the project root.

The wrapper uses the existing launcher rather than duplicating its logic.
A successful run automatically:
downloads results
verifies them
destroys the VM
A failed or unverified run preserves the VM unless explicitly handled otherwise.
Final console output clearly states:
run outcome
VM outcome
local results path
whether billing should have stopped
Docs reflect the one-click flow clearly.
Tests pass locally.
Final verification

Run:

python -m py_compile cloud/launch_gcp_run.py dashboard.py dashboard_utils.py run_cloud_sweep.py
python -m pytest tests/test_smoke.py tests/test_cloud_launcher.py tests/test_dashboard_utils.py -v --basetemp=.tmp_pytest_run

Also run a local dry-run of the wrapper:

python run_cloud_sweep.py --dry-run

If practical, also run:

python run_cloud_sweep.py --keep-vm

only if safe and appropriate in the current environment.

Deliverables

Expected changed files likely include:

run_cloud_sweep.py
cloud/launch_gcp_run.py
cloud/GCP_WINDOWS_RUNBOOK.md
CLAUDE.md
CHANGELOG_DEV.md
relevant tests
At the end

Please:

summarize all changed files
list the exact one-click commands:
dry run
safe first run
normal run
confirm whether the one-click flow now automatically stops VM billing on success
commit the changes
push them to GitHub

Use a sensible commit message such as:

SESSION 14: add one-click GCP sweep wrapper and finalize automatic VM lifecycle