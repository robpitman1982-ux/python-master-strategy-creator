SESSION 15 TASKS — One-Click Launcher Safety Fix After Failed Overnight Run
Goal

Fix the specific regression discovered in the first real unattended Session 14 run:

the VM was destroyed
run_outcome remained null
no artifacts.tar.gz was downloaded locally
no extracted outputs/ or logs/ were present
the launcher status trail jumped from remote start/running to destroy/destroyed

This means the current one-click path is not yet safe for unattended overnight use.

Session 15 is a focused launcher safety and failure-handling fix-up.

Do not change strategy logic. Do not modify sweep logic. Do not modify ranking, filtering, or portfolio evaluation.

Only touch:

cloud/launch_gcp_run.py
run_cloud_sweep.py only if needed for messaging
dashboard.py
dashboard_utils.py if needed
tests/test_cloud_launcher.py
small helper utilities if truly necessary
What just happened

The real run reached remote execution successfully.

Evidence from the live VM/log check:

engine was actively running on the VM
engine_run.log showed progress like Done 96/288
accepted candidates were being found

Evidence from local launcher artifacts after the run:

local run directory contained only:
input_bundle.tar.gz
launcher_status.json
launcher_status.jsonl
remote_runner.sh
run_manifest.json
missing:
artifacts.tar.gz
extracted outputs
extracted logs

Most important status bug:

launcher_status.json ended with:
run_outcome: null
vm_outcome: "vm_destroyed"
state: "vm_destroyed"
launcher_status.jsonl showed the flow reached remote start, then later destroy/destroyed, without a successful artifact retrieval/verification trail.

So the critical failure is:

the launcher can destroy the VM even when the run has not been marked completed or verified and no local artifacts were retrieved.

That must be fixed before the next unattended run.

Non-negotiable rule for Session 15
Automatic VM destruction must be forbidden unless success is explicit.

The launcher may auto-destroy only if all of the following are true:

remote run reached a terminal success state OR artifacts clearly exist remotely
artifacts.tar.gz was downloaded locally
local artifact file exists
local artifact file size is greater than zero
extraction succeeded
expected extracted content exists locally
run_outcome is explicitly set to a success state before destroy

If any of these conditions are not met:

do not auto-destroy
preserve the VM unless it is already gone
write a clear failure/interruption state
write a clear failure reason
print a loud console warning that unattended verification failed

This is the core acceptance rule.

Read these first
CLAUDE.md
CHANGELOG_DEV.md
cloud/launch_gcp_run.py
run_cloud_sweep.py
dashboard.py
dashboard_utils.py
tests/test_cloud_launcher.py
SESSION_12A_TASKS.md
SESSION_13A_TASKS.md
SESSION_14_TASKS.md
SESSION_HANDOFF_4.md

Before editing, inspect the current destroy path carefully.

Especially inspect:

final try/finally logic
any cleanup path that always destroys
any branch that sets vm_outcome without checking run_outcome
monitor loop terminal conditions
artifact download and verification return values
handling of Spot interruptions / lost SSH / missing remote status
Main tasks
Task 1 — Make destroy permission explicit and centralized

Create a single helper decision path in cloud/launch_gcp_run.py for whether VM destruction is allowed.

Add something conceptually like:

can_auto_destroy(status, verification_result, args)
or equivalent central helper

This helper must return True only when:

--keep-vm is not set
run success is explicit
artifact verification passed
extracted results are present locally

It must return False when any of these are true:

run_outcome is None
run_outcome is a failure/interrupted state
download failed
extraction failed
artifact verification failed
remote state is unknown
Spot interruption suspected but artifacts not recovered
monitor loop exited unexpectedly
local extracted outputs/logs are missing
Acceptance

There must be no scattered destroy decisions. There must be one obvious guard that controls whether destroy happens.

Task 2 — Introduce explicit terminal run outcomes

Right now run_outcome can stay null, which is unacceptable.

Standardize terminal run_outcome values.

Use a clean, finite set such as:

dry_run_complete
run_completed_verified
run_completed_unverified
artifact_download_failed
artifact_verification_failed
remote_start_failed
remote_monitor_failed
remote_interrupted_vm_preserved
spot_preempted_artifacts_missing
vm_missing_before_retrieval
unexpected_launcher_failure

You do not need this exact wording if the implementation prefers slightly different names, but the important rules are:

every real run must end with a non-null run_outcome
success and failure must be clearly distinguishable
destroy is only allowed for explicit success
Acceptance

At the end of every run, launcher_status.json must contain a non-null terminal run_outcome.

Task 3 — Separate run outcome from VM outcome cleanly

The current bug shows vm_outcome = vm_destroyed while run_outcome = null.

That must never happen again.

Rules:

run_outcome answers: what happened to the run?
vm_outcome answers: what happened to the VM?

Examples:

Valid combinations:

run_completed_verified + vm_destroyed
artifact_verification_failed + vm_preserved_for_inspection
spot_preempted_artifacts_missing + vm_already_gone
remote_monitor_failed + vm_preserved_for_inspection

Invalid combination:

run_outcome = null with any terminal VM outcome
Acceptance

launcher_status.json and console summary must always show both clearly.

Task 4 — Handle Spot/preemption and missing-instance cases properly

The run used Spot provisioning.

Whether this exact run was preempted or hit another launcher cleanup path, the launcher must handle both safely.

Add explicit handling for these cases:

Case A — VM disappears before artifact retrieval

If SSH fails and instance lookup confirms the VM no longer exists before artifacts were downloaded:

do not mark success
set clear run_outcome such as:
vm_missing_before_retrieval
or spot_preempted_artifacts_missing
set vm_outcome = vm_already_gone
preserve local status trail
print loud final warning:
results were not retrieved
VM is already gone
run must be considered failed/unverified
Case B — Spot preemption detected but artifacts may exist remotely or be partially recoverable

If you can positively detect Spot preemption:

do not restart blindly unless current restart logic is clearly safe
do not auto-destroy on top of that state
mark explicit interruption state
Case C — Instance still exists but retrieval/verification failed
preserve VM
set vm_outcome = vm_preserved_for_inspection
never destroy automatically
Acceptance

Lost VM must no longer be silently treated like a completed run.

Task 5 — Strengthen artifact verification beyond tar existence

Session 12A already required tar existence/size/extraction checks. That was not enough operationally.

After download, verify all of the following:

local artifacts.tar.gz exists
size > 0
extraction succeeds
extracted directory exists
at least one expected subdirectory exists, such as:
Outputs/
logs/
preserved/
at least one expected result file or expected log file exists

At minimum, verify one or more of:

Outputs/master_leaderboard.csv
Outputs/family_summary_results.csv
logs/engine_run.log
preserved/...

If extraction succeeds but expected contents are missing, treat as verification failure.

Acceptance

Success cannot be declared on an empty or structurally incomplete artifact bundle.

Task 6 — Do not destroy from finally unless success guard passes

Inspect the cleanup/finally logic carefully.

This is the most likely source of the current bug.

If there is any unconditional or overly broad cleanup path like:

always call destroy at the end unless --keep-vm
destroy on any normal exit even if monitor result is ambiguous
destroy after exception handling without checking verification

Fix it.

The final cleanup path must behave like:

if success verified and --keep-vm is false → destroy
else if VM still exists → preserve
else if VM already gone → record that clearly
Acceptance

A failed or ambiguous run must never auto-destroy a still-existing VM.

Task 7 — Persist explicit failure reason fields in launcher status

Add stable fields such as:

failure_reason
destroy_allowed
artifact_verified
artifacts_downloaded
extraction_verified
expected_outputs_present
instance_exists_at_end

These fields should be persisted in launcher_status.json and included in launcher_status.jsonl updates when relevant.

This will make future debugging much easier.

Acceptance

The next failed run should be diagnosable from local status files alone.

Task 8 — Improve final console summary

The final summary must be brutally clear.

On every run, print:

Run ID
Local Results Path
Run Outcome
VM Outcome
Artifact Downloaded: yes/no
Artifact Verified: yes/no
Destroy Allowed: yes/no
Billing should now be stopped: yes/no/unknown

If the run failed or was ambiguous, print a warning banner such as:

WARNING: Run did not complete verified artifact retrieval.
VM was preserved or may have already disappeared.
Do not trust this run's outputs until checked manually.

If the VM is already gone but outputs were not retrieved, print that explicitly.

Acceptance

The user must be able to understand the final run state from console output alone.

Task 9 — Dashboard status polish for failed/incomplete runs

Update the Cloud Monitor so it clearly distinguishes:

completed and verified
completed but unverified
failed with VM preserved
failed because VM disappeared before retrieval
dry run

Show prominent badges or banners.

Suggested mapping:

🟢 run_completed_verified
🟡 run_completed_unverified
🔴 artifact_download_failed
🔴 artifact_verification_failed
🔴 remote_monitor_failed
🔴 vm_missing_before_retrieval
⚪ dry_run_complete

Also show these booleans if available:

artifact downloaded
artifact verified
destroy allowed
billing likely stopped

If the latest run has no extracted outputs, the dashboard should say that explicitly instead of leaving the impression that the run simply has no logs yet.

Acceptance

A failed run like the one tonight must be obvious within one glance in Streamlit.

Task 10 — Add regression tests for this exact failure class

Extend tests/test_cloud_launcher.py with focused regression tests.

At minimum add tests for:

Test A — No destroy when run_outcome is null

Simulate a terminal path where:

run_outcome = None
vm exists = True
--keep-vm = False

Ensure:

destroy is not allowed
final VM outcome becomes preserved, not destroyed
Test B — No destroy when artifacts missing

Simulate:

monitor completed or exited
no local artifacts.tar.gz

Ensure:

run_outcome = artifact_download_failed or equivalent
destroy is not called
Test C — No destroy when extraction fails

Simulate downloaded tarball but extraction failure.

Ensure:

artifact_verified = False
VM preserved
no destroy
Test D — VM already gone before retrieval

Simulate:

SSH failure
instance check says instance does not exist
no local artifacts

Ensure:

run_outcome is explicit non-null failure/interruption state
vm_outcome = vm_already_gone
no false success
Test E — Verified success permits destroy

Simulate:

artifacts downloaded
extraction succeeded
expected outputs present
run outcome marked verified
--keep-vm = False

Ensure:

destroy is allowed
vm_outcome = vm_destroyed
Test F — --keep-vm still wins

Even on verified success, if --keep-vm is set:

do not destroy
mark VM preserved intentionally
Test G — Final status fields are never null on real runs

For all terminal run paths in tests:

run_outcome must not be null
vm_outcome must not be null
Task 11 — Optional but strongly recommended: lightweight remote salvage before giving up

If the monitor loses confidence but the instance still exists, try one last lightweight salvage pass before deciding final failure:

check if remote artifacts.tar.gz exists
if yes, attempt download
if download succeeds, continue verification
only preserve VM if salvage fails

Do not overcomplicate this. A simple final retrieval attempt is enough.

This is optional for Session 15, but recommended.

Task 12 — Keep wrapper behavior simple and honest

run_cloud_sweep.py should remain a thin wrapper.

If needed, only improve:

final wording
error propagation
help text

Do not duplicate launcher logic in the wrapper.

Do not touch

Do not modify:

master_strategy_engine.py
strategy generation logic
filter combinations
Monte Carlo logic
ranking logic
portfolio logic
prop firm simulator

This session is launcher safety only.

Acceptance criteria

Session 15 is successful only if all of the following are true:

A real run can no longer end with:
run_outcome = null
vm_outcome = vm_destroyed
Automatic destroy occurs only when:
artifacts downloaded
extraction verified
expected contents present
run_outcome = run_completed_verified
If the VM disappears before retrieval:
launcher records explicit non-success outcome
dashboard shows failure/interruption clearly
no false success impression remains
If download/extraction/verification fails and VM still exists:
VM is preserved
final summary says so clearly
Final console summary must explicitly state:
run outcome n - VM outcome
artifact downloaded yes/no
artifact verified yes/no
destroy allowed yes/no
Tests cover the regression that happened tonight.
Local validation passes.
Recommended implementation order
Refactor destroy gating into one helper
Standardize terminal run outcomes
Fix cleanup/finally path
Improve artifact verification
Handle missing/preempted VM case cleanly
Improve final console summary
Update dashboard badges/messages
Add regression tests
Run local validation
Required local validation

Run from repo root:

cd "C:\Users\Rob\Documents\GIT Repos\python-master-strategy-creator"
python -m py_compile cloud\launch_gcp_run.py dashboard.py dashboard_utils.py run_cloud_sweep.py

Then:

cd "C:\Users\Rob\Documents\GIT Repos\python-master-strategy-creator"
python -m pytest tests\test_cloud_launcher.py -v --basetemp=.tmp_pytest_run_session15

If there are smoke tests already relied on for launcher safety, also run:

cd "C:\Users\Rob\Documents\GIT Repos\python-master-strategy-creator"
python -m pytest tests\test_smoke.py tests\test_cloud_launcher.py -v --basetemp=.tmp_pytest_run_session15
Final deliverable expected from Codex

Codex should:

implement the Session 15 fixes
update/add tests
run local validation
provide a short summary of:
root cause found
exact destroy guard added
new terminal states
test results

Also ask Codex to commit in a few clean commits, for example:

fix: centralize auto-destroy guard and explicit terminal outcomes
fix: harden artifact verification and missing-vm failure handling
feat: improve launcher final summary and dashboard failure visibility
test: add regression coverage for destroy-without-artifacts bug
Plain-English objective

After Session 15, the launcher must behave like this:

if the run truly completed and artifacts are verified → destroy VM automatically
if anything is ambiguous or failed → do not destroy a live VM
if the VM already disappeared → record that clearly and never pretend success
never again allow run_outcome = null at terminal state  
Audit all timeout values in cloud/launch_gcp_run.py
subprocess.run(..., timeout=...)
monitor loop wall-clock limits
SSH readiness timeouts
artifact retrieval timeouts
any “max runtime” or “deadline” logic
Log explicit failure reasons
monitor_timeout
ssh_disconnect
subprocess_timeout
vm_missing_before_retrieval
artifact_download_failed
Add SSH keepalive options where appropriate
or at minimum make loss of SSH/log streaming non-fatal unless remote run status also says failed
Never destroy on monitor timeout unless artifacts are already verified
this is the real safety fix either way
Add a regression test for elapsed-time timeout behavior
simulate a long-running monitor path
ensure it does not destroy unless verified success is explicit

One useful comparison point: an older session note mentions a 60-second start timeout issue in run_cloud_job.py, which proves timeout-related launcher bugs have happened before in this project — just not necessarily this exact one-click launcher path.