SESSION_18_TASKS.md

Strategy Console — Dashboard UX, Storage Layout, and Auto-Deploy

Objective

Turn strategy-console into a genuinely useful operator console for daily use.

This session must do four things:

Upgrade the Streamlit dashboard into a much better visual control panel
Make the app aware of the new storage layout under ~/strategy_console_storage
Fix remaining service/deploy rough edges from Sessions 16–17
Add GitHub auto-deploy to strategy-console on push to main

This session is not about multi-VM orchestration or scaling compute. It is about making the single-console experience polished and reliable.

Current State

We now have:

Session 17 launcher cleanup / destroy-decision logic pushed to GitHub.
strategy-dashboard.service tracked in repo with robpitman1982 paths.
scripts/start_dashboard.sh and scripts/update_console.sh tracked in repo.
WinSCP access to:
~/strategy_console_storage/uploads
~/strategy_console_storage/runs
~/strategy_console_storage/exports
~/strategy_console_storage/backups
Dashboard currently still reads from repo-local cloud_results and is visually minimal.
Task 1 — Fix Remaining Service / Deploy Rough Edges

Update scripts/start_dashboard.sh so it starts Streamlit with explicit external binding:

#!/usr/bin/env bash
set -e
cd ~/python-master-strategy-creator
source venv/bin/activate
exec streamlit run dashboard.py \
  --server.port 8501 \
  --server.address 0.0.0.0

Update scripts/update_console.sh so it becomes a real deploy script:

#!/usr/bin/env bash
set -e
cd ~/python-master-strategy-creator
git pull origin main
source venv/bin/activate
pip install -r requirements.txt
systemctl restart strategy-dashboard || true
git rev-parse HEAD

Important:

avoid brittle reliance on sudo if possible
if service restart requires privilege, handle it explicitly and safely
print useful operator output

Acceptance criteria:

deploy script updates code and dependencies cleanly
dashboard start script works for external access
no manual patching required after a normal deploy
Task 2 — Make Dashboard Storage-Aware

Introduce a clear configuration layer for console storage.

Dashboard should understand:

~/strategy_console_storage/
    uploads/
    runs/
    exports/
    backups/

Implement a small helper/config approach so dashboard can read these paths robustly instead of hardcoding only cloud_results.

At minimum:

add constants or a config helper for storage roots
support browsing runs from ~/strategy_console_storage/runs
support browsing uploaded datasets from ~/strategy_console_storage/uploads

Acceptance criteria:

dashboard can show uploaded datasets
dashboard can show run folders from storage
storage layout is not mixed into random hardcoded strings everywhere
Task 3 — Add a Real Dashboard Layout

Upgrade dashboard.py from a minimal status page into a more polished operator console.

Desired sections:

Sidebar
current git commit
hostname
dashboard started time
selected run
selected dataset
Main header
Strategy Console
latest run state
billing state
operator action summary
Top metrics row
Run Outcome
VM Outcome
Billing Status
Artifact Verified
Machine Type
Bundle Size
Dataset panel

Show datasets in ~/strategy_console_storage/uploads

Example columns:

filename
size
modified time
Run history panel

Show runs from ~/strategy_console_storage/runs and/or launcher-managed cloud results

Example columns:

run id
updated time
run outcome
vm outcome
billing status
Run detail panel

For selected run:

run metadata
destroy reason
operator action
recovery commands
engine log tail
Leaderboard preview panel

If a master_leaderboard.csv exists, preview top rows in a dataframe

Acceptance criteria:

dashboard feels like a research console, not just a warning page
user can browse uploaded datasets visually
user can browse past runs visually
user can inspect latest leaderboard without going to the filesystem
Task 4 — Add Dataset Discovery Helpers

Create helper functions in dashboard_utils.py or a new module to:

list uploaded datasets from ~/strategy_console_storage/uploads
format dataset sizes nicely
identify candidate leaderboard/result files in run folders
detect latest run folders in storage
support clean sorting by modified time

Acceptance criteria:

dataset listing logic is not embedded directly in Streamlit UI code
run discovery logic is reusable and testable
Task 5 — Add Export / Download Awareness

In the dashboard, add a visible section for files in:

~/strategy_console_storage/exports

Show:

filename
size
modified time

This does not need direct browser download yet, but the dashboard should at least surface what is there.

Acceptance criteria:

exports folder is visible in UI
user can see what files are ready to pull with WinSCP
Task 6 — GitHub Auto-Deploy to strategy-console

Add a GitHub Actions workflow that runs on push to main.

Goal:

SSH into strategy-console
pull latest repo
install/update requirements
restart dashboard service

Implementation notes:

use GitHub Actions secrets for host, user, and SSH private key
keep the action minimal and reliable
fail clearly if deploy fails

Suggested workflow:

checkout repo
start ssh-agent with secret key
ssh into VM
run update script

Acceptance criteria:

push to main triggers deploy workflow
strategy-console updates automatically
deploy logs are visible in GitHub Actions

Important:

document required GitHub Secrets in a small markdown note or comments
Task 7 — Tests

Add focused tests for new storage-aware helpers.

Suggested tests:

dataset discovery returns expected files
run folder discovery sorts correctly
leaderboard candidate detection works
export folder listing works
billing/operator summary helpers still behave as expected

Do not get bogged down in full end-to-end Streamlit tests.

Acceptance criteria:

new helper logic has targeted tests
existing Session 17 logic remains intact
Files Likely To Change

Primary:

dashboard.py
dashboard_utils.py
scripts/start_dashboard.sh
scripts/update_console.sh

New:

.github/workflows/deploy_strategy_console.yml
possibly a small config/helper module for storage paths

Possibly:

requirements.txt
tests/test_dashboard_utils.py
Acceptance Criteria

After Session 18:

dashboard has a much nicer research-console layout
dashboard knows about ~/strategy_console_storage
uploaded datasets are visible in UI
run history is visible in UI
leaderboard preview is visible in UI
service/deploy scripts are cleaned up
GitHub push to main can auto-deploy to strategy-console
Out of Scope

Not part of Session 18:

multi-VM orchestration
region hunting
shard/queue system
scaling beyond your current CPU quota
Operator Goal After Session 18

You should be able to:

upload datasets with WinSCP
open the dashboard
see datasets available
see latest and past runs
inspect billing state and recovery actions
preview leaderboards
push code to GitHub and have strategy-console update automatically

without digging around manually in the VM.