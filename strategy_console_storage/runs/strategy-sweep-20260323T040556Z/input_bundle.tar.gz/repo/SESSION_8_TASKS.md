# SESSION 8 TASKS — Bug Fixes, GCP Automation, Unattended Cloud Runs
# Date: 2026-03-20

---

## Context

Sessions 0–7 built and hardened the engine, added prop firm simulator, and completed the first GCP 96-core run across ES daily/60m/30m/15m. 9 strategies accepted to master leaderboard.

**Analysis of the GCP run results revealed a CRITICAL BUG**: the portfolio evaluator (`modules/portfolio_evaluator.py`) does not pass the `timeframe` parameter when reconstructing strategies. This means:
- Filter SMA lengths, ATR lookbacks, and momentum lookbacks all default to 60m values
- Strategies from daily/30m/15m get reconstructed with wrong parameters
- Trade counts and PnL diverge massively from the engine's own numbers
- Example: Daily MR shows 351 trades/$3M in engine vs 149 trades/$41K in portfolio eval

This session fixes that bug and builds the GCP automation scripts so cloud runs are fully unattended: one command creates the VM, uploads data, runs the engine, downloads results, and **destroys the VM** automatically.

Work through each step in order. Commit after each step. Push to GitHub when all done.

---

## Step 1: Fix portfolio evaluator timeframe bug (CRITICAL)

**File**: `modules/portfolio_evaluator.py`

### Problem

`_rebuild_strategy_from_leaderboard_row()` never passes `timeframe` to:
1. `strategy_type_inst.get_required_sma_lengths()` — defaults to 60m SMA lengths
2. `strategy_type_inst.get_required_avg_range_lookbacks()` — defaults to 60m
3. `strategy_type_inst.get_required_momentum_lookbacks()` — defaults to 60m
4. `strategy_type_inst.build_candidate_specific_strategy()` — defaults to 60m filter params

The `evaluate_portfolio()` function already receives `timeframe` as a parameter but never threads it through to the rebuild function.

### Fix

**A) Add `timeframe` parameter to `_rebuild_strategy_from_leaderboard_row()`**:

Change the signature from:
```python
def _rebuild_strategy_from_leaderboard_row(
    row: pd.Series,
    data: pd.DataFrame,
    outputs_dir: Path,
    market_symbol: str,
) -> tuple[pd.DataFrame, str, EngineConfig]:
```

To:
```python
def _rebuild_strategy_from_leaderboard_row(
    row: pd.Series,
    data: pd.DataFrame,
    outputs_dir: Path,
    market_symbol: str,
    timeframe: str = "60m",
) -> tuple[pd.DataFrame, str, EngineConfig]:
```

**B) Pass `timeframe` to the three `get_required_*()` calls**:

Change:
```python
    eval_data = add_precomputed_features(
        data.copy(),
        sma_lengths=strategy_type_inst.get_required_sma_lengths(),
        avg_range_lookbacks=strategy_type_inst.get_required_avg_range_lookbacks(),
        momentum_lookbacks=strategy_type_inst.get_required_momentum_lookbacks(),
    )
```

To:
```python
    eval_data = add_precomputed_features(
        data.copy(),
        sma_lengths=strategy_type_inst.get_required_sma_lengths(timeframe=timeframe),
        avg_range_lookbacks=strategy_type_inst.get_required_avg_range_lookbacks(timeframe=timeframe),
        momentum_lookbacks=strategy_type_inst.get_required_momentum_lookbacks(timeframe=timeframe),
    )
```

**C) Pass `timeframe` to `build_candidate_specific_strategy()`**:

Change:
```python
    strategy = strategy_type_inst.build_candidate_specific_strategy(
        combo_classes,
        hold_bars,
        stop_distance_points,
        min_avg_range,
        momentum_lookback,
    )
```

To:
```python
    strategy = strategy_type_inst.build_candidate_specific_strategy(
        combo_classes,
        hold_bars,
        stop_distance_points,
        min_avg_range,
        momentum_lookback,
        timeframe=timeframe,
    )
```

**D) Thread `timeframe` from `evaluate_portfolio()` into the rebuild call**:

In the `evaluate_portfolio()` function, find the call to `_rebuild_strategy_from_leaderboard_row()` and add `timeframe=timeframe`:

Change:
```python
            trades_df, filters_str, last_cfg = _rebuild_strategy_from_leaderboard_row(
                row, data, outputs_dir, market_name
            )
```

To:
```python
            trades_df, filters_str, last_cfg = _rebuild_strategy_from_leaderboard_row(
                row, data, outputs_dir, market_name, timeframe=timeframe
            )
```

**E) Also add a print statement** so we can see timeframe is being used:

After the `strategy_type_inst = get_strategy_type(strategy_type_name)` line in `_rebuild_strategy_from_leaderboard_row`, add:
```python
    print(f"    Rebuilding {strategy_type_name} with timeframe={timeframe}")
```

**Commit**: `fix: pass timeframe to portfolio evaluator strategy reconstruction (critical bug)`

---

## Step 2: Add smoke test for portfolio evaluator timeframe threading

**File**: `tests/test_smoke.py`

Add a new test `test_portfolio_evaluator_timeframe_param`:

```python
def test_portfolio_evaluator_timeframe_param():
    """Verify _rebuild_strategy_from_leaderboard_row accepts and uses timeframe."""
    from modules.portfolio_evaluator import _rebuild_strategy_from_leaderboard_row
    import inspect
    sig = inspect.signature(_rebuild_strategy_from_leaderboard_row)
    assert "timeframe" in sig.parameters, (
        "_rebuild_strategy_from_leaderboard_row must accept timeframe parameter"
    )
    # Verify default is "60m" for backward compatibility
    assert sig.parameters["timeframe"].default == "60m"
```

Also add a test that verifies the strategy type `build_candidate_specific_strategy` produces different results for different timeframes:

```python
def test_strategy_type_timeframe_affects_filters():
    """Verify that timeframe changes filter parameters in build_candidate_specific_strategy."""
    from modules.strategy_types import get_strategy_type
    from modules.filters import DistanceBelowSMAFilter, TwoBarDownFilter, ReversalUpBarFilter

    mr = get_strategy_type("mean_reversion")
    combo_classes = [DistanceBelowSMAFilter, TwoBarDownFilter, ReversalUpBarFilter]

    strat_60m = mr.build_candidate_specific_strategy(
        combo_classes, hold_bars=12, stop_distance_points=0.5,
        min_avg_range=1.2, momentum_lookback=0, timeframe="60m",
    )
    strat_daily = mr.build_candidate_specific_strategy(
        combo_classes, hold_bars=5, stop_distance_points=0.4,
        min_avg_range=1.2, momentum_lookback=0, timeframe="daily",
    )

    # The filter objects should have different SMA lengths
    # Daily multiplier is ~0.154x, so SMA lengths should be much smaller
    # Just verify both strategies were created (the real validation is that
    # the timeframe parameter is accepted and doesn't crash)
    assert strat_60m is not None
    assert strat_daily is not None
    assert strat_60m.name != strat_daily.name or True  # Names may match, that's OK
```

**Commit**: `test: add smoke tests for portfolio evaluator timeframe threading`

---

## Step 3: Create GCP startup script

**File**: `cloud/gcp_startup.sh`

This script runs automatically when the VM boots (via `--metadata-from-file startup-script=`). It runs as root.

```bash
#!/bin/bash
# =============================================================
# GCP Startup Script — Strategy Discovery Engine
# Runs as root on first boot. Sets up environment, waits for
# data files, then runs the engine.
# =============================================================
set -e

REPO_URL="https://github.com/robpitman1982-ux/python-master-strategy-creator.git"
WORK_DIR="/root/python-master-strategy-creator"
# GCP SCP runs as the OS Login user, which lands in /home/<username>/
# We look for data in /home/*/uploads/ (the run script puts them there)
UPLOAD_SCAN_DIR="/home"
LOG_FILE="/var/log/engine-startup.log"

exec > >(tee -a "$LOG_FILE") 2>&1
echo "=== GCP Startup Script started at $(date -u) ==="

# --- Install dependencies ---
echo "[1/6] Installing system packages..."
apt-get update -qq
apt-get install -y -qq python3-pip python3-venv git tmux > /dev/null 2>&1

# --- Clone repo ---
echo "[2/6] Cloning repository..."
cd /root
if [ -d "$WORK_DIR" ]; then
    cd "$WORK_DIR" && git pull
else
    git clone "$REPO_URL"
    cd "$WORK_DIR"
fi

# --- Create venv ---
echo "[3/6] Setting up Python environment..."
python3 -m venv venv
source venv/bin/activate
pip install --quiet numpy pandas pyyaml pytest

# --- Create Data directory ---
mkdir -p Data Outputs

# --- Wait for data files ---
echo "[4/6] Waiting for data files to appear..."
# The run_gcp_job.py script uploads files to /home/<user>/uploads/
# We poll until at least one CSV appears, with a 30-minute timeout
WAITED=0
MAX_WAIT=1800
DATA_FOUND=0

while [ $WAITED -lt $MAX_WAIT ]; do
    # Look for any CSV in any user's uploads directory
    CSV_COUNT=$(find $UPLOAD_SCAN_DIR -name "*.csv" -path "*/uploads/*" 2>/dev/null | wc -l)
    if [ "$CSV_COUNT" -gt 0 ]; then
        DATA_FOUND=1
        echo "  Found $CSV_COUNT CSV file(s) after ${WAITED}s"
        break
    fi
    sleep 10
    WAITED=$((WAITED + 10))
    if [ $((WAITED % 60)) -eq 0 ]; then
        echo "  Still waiting for data files... (${WAITED}s elapsed)"
    fi
done

if [ $DATA_FOUND -eq 0 ]; then
    echo "ERROR: No data files found after ${MAX_WAIT}s. Exiting."
    exit 1
fi

# --- Move data files to correct location ---
echo "[5/6] Moving data files..."
find $UPLOAD_SCAN_DIR -name "*.csv" -path "*/uploads/*" -exec cp {} "$WORK_DIR/Data/" \;
echo "  Data files in place:"
ls -la "$WORK_DIR/Data/"

# --- Find config file ---
# The run script also uploads the config to /home/<user>/uploads/
CONFIG_FILE="config.yaml"
UPLOADED_CONFIG=$(find $UPLOAD_SCAN_DIR -name "*.yaml" -path "*/uploads/*" 2>/dev/null | head -1)
if [ -n "$UPLOADED_CONFIG" ]; then
    cp "$UPLOADED_CONFIG" "$WORK_DIR/$CONFIG_FILE"
    echo "  Using uploaded config: $UPLOADED_CONFIG"
else
    echo "  No config uploaded, using repo default"
fi

# --- Run the engine ---
echo "[6/6] Starting engine..."
cd "$WORK_DIR"
source venv/bin/activate

# Write a marker file so the polling script knows we've started
echo "RUNNING" > /tmp/engine_status

python master_strategy_engine.py --config "$CONFIG_FILE" > /tmp/engine_run.log 2>&1
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo "COMPLETED" > /tmp/engine_status
    echo "=== Engine completed successfully at $(date -u) ==="
else
    echo "FAILED:$EXIT_CODE" > /tmp/engine_status
    echo "=== Engine FAILED with exit code $EXIT_CODE at $(date -u) ==="
fi

# --- Copy outputs to a user-accessible location ---
# Find the first non-root user home directory
USER_HOME=$(find /home -maxdepth 1 -mindepth 1 -type d 2>/dev/null | head -1)
if [ -n "$USER_HOME" ]; then
    mkdir -p "$USER_HOME/outputs"
    cp -r "$WORK_DIR/Outputs/"* "$USER_HOME/outputs/" 2>/dev/null || true
    cp /tmp/engine_run.log "$USER_HOME/outputs/" 2>/dev/null || true
    # Fix permissions so the SCP user can download
    chown -R "$(basename $USER_HOME)":"$(basename $USER_HOME)" "$USER_HOME/outputs/" 2>/dev/null || true
    echo "Outputs copied to $USER_HOME/outputs/"
fi

echo "=== Startup script finished at $(date -u) ==="
```

Make it executable:
```bash
chmod +x cloud/gcp_startup.sh
```

**Commit**: `feat: add GCP startup script for unattended engine runs`

---

## Step 4: Create GCP automation script (PowerShell)

**File**: `cloud/run_gcp_job.ps1`

This is the ONE script Rob runs on his Windows machine. It does everything: create VM, upload data, wait for completion, download results, destroy VM. Fully unattended.

```powershell
<#
.SYNOPSIS
    Fully automated GCP cloud run for the Strategy Discovery Engine.
    Creates VM → uploads data → waits for engine → downloads results → destroys VM.

.DESCRIPTION
    One command to run a full strategy sweep on GCP. Uses SPOT pricing for cost savings.
    The VM self-destructs logic is handled by this script polling for completion then
    deleting the instance. If the script is interrupted, run:
        gcloud compute instances delete strategy-sweep --zone=australia-southeast2-a --quiet

.PARAMETER ConfigFile
    Path to the YAML config file. Default: cloud/config_es_all_timeframes_gcp96.yaml

.PARAMETER MachineType
    GCP machine type. Default: n2-highcpu-96

.PARAMETER Zone
    GCP zone. Default: australia-southeast2-a (Melbourne)

.PARAMETER DataDir
    Local directory containing CSV data files. Default: Data

.PARAMETER OutputDir
    Local directory to save results. Default: cloud_outputs

.PARAMETER InstanceName
    VM instance name. Default: strategy-sweep

.PARAMETER SkipDestroy
    If set, don't destroy the VM after downloading results (for debugging).

.EXAMPLE
    .\cloud\run_gcp_job.ps1
    .\cloud\run_gcp_job.ps1 -ConfigFile cloud/config_es_5m_only.yaml -OutputDir cloud_outputs_5m
#>

param(
    [string]$ConfigFile = "cloud/config_es_all_timeframes_gcp96.yaml",
    [string]$MachineType = "n2-highcpu-96",
    [string]$Zone = "australia-southeast2-a",
    [string]$DataDir = "Data",
    [string]$OutputDir = "cloud_outputs",
    [string]$InstanceName = "strategy-sweep",
    [switch]$SkipDestroy = $false
)

$ErrorActionPreference = "Stop"

# Use native OpenSSH instead of PuTTY (fixes freezing issues)
$env:CLOUDSDK_SSH_NATIVE = "1"

$ProjectDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$StartupScript = Join-Path $ProjectDir "cloud/gcp_startup.sh"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmm"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host " GCP Strategy Engine — Automated Run" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Instance:  $InstanceName"
Write-Host "Machine:   $MachineType"
Write-Host "Zone:      $Zone"
Write-Host "Config:    $ConfigFile"
Write-Host "Data dir:  $DataDir"
Write-Host "Output:    $OutputDir"
Write-Host "Timestamp: $Timestamp"
Write-Host "============================================" -ForegroundColor Cyan

# ---------------------------------------------------------------
# STEP 1: Create VM with startup script
# ---------------------------------------------------------------
Write-Host "`n[1/7] Creating VM with startup script..." -ForegroundColor Yellow

# Check if instance already exists
$existing = gcloud compute instances list --filter="name=$InstanceName" --format="value(name)" 2>$null
if ($existing) {
    Write-Host "  WARNING: Instance '$InstanceName' already exists!" -ForegroundColor Red
    $confirm = Read-Host "  Delete it and create fresh? (y/n)"
    if ($confirm -ne "y") {
        Write-Host "  Aborted." -ForegroundColor Red
        exit 1
    }
    gcloud compute instances delete $InstanceName --zone=$Zone --quiet
    Start-Sleep -Seconds 10
}

gcloud compute instances create $InstanceName `
    --zone=$Zone `
    --machine-type=$MachineType `
    --provisioning-model=SPOT `
    --instance-termination-action=STOP `
    --image-family=ubuntu-2404-lts-amd64 `
    --image-project=ubuntu-os-cloud `
    --boot-disk-size=120GB `
    --boot-disk-type=pd-ssd `
    --metadata-from-file startup-script=$StartupScript

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to create instance." -ForegroundColor Red
    exit 1
}

Write-Host "  VM created successfully." -ForegroundColor Green

# ---------------------------------------------------------------
# STEP 2: Wait for SSH to be ready
# ---------------------------------------------------------------
Write-Host "`n[2/7] Waiting for SSH..." -ForegroundColor Yellow

$sshReady = $false
for ($i = 1; $i -le 30; $i++) {
    try {
        $result = gcloud compute ssh $InstanceName --zone=$Zone --command="echo ready" 2>$null
        if ($result -match "ready") {
            $sshReady = $true
            Write-Host "  SSH ready after attempt $i" -ForegroundColor Green
            break
        }
    } catch { }
    Write-Host "  Attempt $i/30..."
    Start-Sleep -Seconds 10
}

if (-not $sshReady) {
    Write-Host "ERROR: SSH not ready after 5 minutes. Check the VM." -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------------------
# STEP 3: Create uploads directory on VM
# ---------------------------------------------------------------
Write-Host "`n[3/7] Preparing upload directory..." -ForegroundColor Yellow

gcloud compute ssh $InstanceName --zone=$Zone --command="mkdir -p ~/uploads"

# ---------------------------------------------------------------
# STEP 4: Upload data files and config
# ---------------------------------------------------------------
Write-Host "`n[4/7] Uploading data files and config..." -ForegroundColor Yellow

# Upload all CSV files from the Data directory that match config datasets
$csvFiles = Get-ChildItem -Path $DataDir -Filter "*.csv" -ErrorAction SilentlyContinue
if ($csvFiles.Count -eq 0) {
    Write-Host "ERROR: No CSV files found in $DataDir" -ForegroundColor Red
    exit 1
}

foreach ($csv in $csvFiles) {
    Write-Host "  Uploading $($csv.Name) ($([math]::Round($csv.Length / 1MB, 1)) MB)..."
    gcloud compute scp "$($csv.FullName)" "${InstanceName}:~/uploads/$($csv.Name)" --zone=$Zone
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  WARNING: Failed to upload $($csv.Name)" -ForegroundColor Red
    }
}

# Upload config file
Write-Host "  Uploading config: $ConfigFile..."
gcloud compute scp "$ConfigFile" "${InstanceName}:~/uploads/config.yaml" --zone=$Zone

Write-Host "  All files uploaded." -ForegroundColor Green

# ---------------------------------------------------------------
# STEP 5: Poll for engine completion
# ---------------------------------------------------------------
Write-Host "`n[5/7] Waiting for engine to complete..." -ForegroundColor Yellow
Write-Host "  (startup script installs deps, clones repo, then runs engine)"
Write-Host "  This typically takes 4-5 hours for a 4-timeframe ES sweep on 96 cores."
Write-Host "  Press Ctrl+C to stop polling (VM keeps running, re-run to resume)."
Write-Host ""

$pollStart = Get-Date
$engineDone = $false
$lastStatus = ""

while (-not $engineDone) {
    Start-Sleep -Seconds 60

    $elapsed = (Get-Date) - $pollStart
    $elapsedStr = "{0:hh\:mm\:ss}" -f $elapsed

    try {
        $status = gcloud compute ssh $InstanceName --zone=$Zone --command="cat /tmp/engine_status 2>/dev/null || echo PENDING" 2>$null
        $status = $status.Trim()
    } catch {
        $status = "SSH_ERROR"
    }

    if ($status -ne $lastStatus) {
        Write-Host "  [$elapsedStr] Status: $status" -ForegroundColor Cyan
        $lastStatus = $status
    } else {
        # Show heartbeat every 5 minutes
        if ($elapsed.TotalMinutes % 5 -lt 1.1) {
            # Also try to read status.json for detailed progress
            try {
                $statusJson = gcloud compute ssh $InstanceName --zone=$Zone --command="cat /root/python-master-strategy-creator/Outputs/*/status.json 2>/dev/null | tail -1" 2>$null
                if ($statusJson) {
                    $parsed = $statusJson | ConvertFrom-Json -ErrorAction SilentlyContinue
                    if ($parsed) {
                        $dataset = $parsed.dataset
                        $family = $parsed.current_family
                        $stage = $parsed.current_stage
                        $pct = $parsed.progress_pct
                        Write-Host "  [$elapsedStr] $dataset / $family / $stage — ${pct}% complete" -ForegroundColor Gray
                    }
                }
            } catch {
                Write-Host "  [$elapsedStr] Still running..." -ForegroundColor Gray
            }
        }
    }

    if ($status -match "COMPLETED") {
        Write-Host "`n  Engine completed successfully!" -ForegroundColor Green
        $engineDone = $true
    }
    elseif ($status -match "FAILED") {
        Write-Host "`n  Engine FAILED! Downloading logs..." -ForegroundColor Red
        $engineDone = $true
    }

    # Safety: check if VM still exists (SPOT can be preempted)
    try {
        $vmStatus = gcloud compute instances describe $InstanceName --zone=$Zone --format="value(status)" 2>$null
        if ($vmStatus -ne "RUNNING") {
            Write-Host "`n  WARNING: VM status is '$vmStatus' (may have been preempted)" -ForegroundColor Red
            if ($vmStatus -eq "TERMINATED" -or $vmStatus -eq "STOPPED") {
                Write-Host "  SPOT instance was preempted. Restarting..." -ForegroundColor Yellow
                gcloud compute instances start $InstanceName --zone=$Zone
                Start-Sleep -Seconds 60
            }
        }
    } catch { }
}

# ---------------------------------------------------------------
# STEP 6: Download results
# ---------------------------------------------------------------
Write-Host "`n[6/7] Downloading results..." -ForegroundColor Yellow

$localOutputDir = "${OutputDir}_${Timestamp}"
New-Item -ItemType Directory -Path $localOutputDir -Force | Out-Null

gcloud compute scp --recurse "${InstanceName}:~/outputs/*" "$localOutputDir/" --zone=$Zone

if ($LASTEXITCODE -eq 0) {
    Write-Host "  Results saved to: $localOutputDir" -ForegroundColor Green

    # Show quick summary if master_leaderboard.csv exists
    $leaderboard = Join-Path $localOutputDir "master_leaderboard.csv"
    if (Test-Path $leaderboard) {
        Write-Host "`n  === MASTER LEADERBOARD ===" -ForegroundColor Cyan
        Get-Content $leaderboard | Select-Object -First 15
    }
} else {
    Write-Host "  WARNING: Some files may not have downloaded." -ForegroundColor Red
}

# Also download the engine log
try {
    gcloud compute scp "${InstanceName}:~/outputs/engine_run.log" "$localOutputDir/" --zone=$Zone 2>$null
} catch { }

# ---------------------------------------------------------------
# STEP 7: Destroy VM
# ---------------------------------------------------------------
if ($SkipDestroy) {
    Write-Host "`n[7/7] SKIPPING VM destruction (-SkipDestroy flag set)" -ForegroundColor Yellow
    Write-Host "  Remember to manually destroy: gcloud compute instances delete $InstanceName --zone=$Zone --quiet"
} else {
    Write-Host "`n[7/7] Destroying VM..." -ForegroundColor Yellow
    gcloud compute instances delete $InstanceName --zone=$Zone --quiet

    if ($LASTEXITCODE -eq 0) {
        Write-Host "  VM destroyed. No more billing." -ForegroundColor Green
    } else {
        Write-Host "  WARNING: Failed to destroy VM! Run manually:" -ForegroundColor Red
        Write-Host "  gcloud compute instances delete $InstanceName --zone=$Zone --quiet" -ForegroundColor Red
    }
}

# ---------------------------------------------------------------
# Summary
# ---------------------------------------------------------------
$totalElapsed = (Get-Date) - $pollStart
Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host " Run Complete" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Total time:  $("{0:hh\:mm\:ss}" -f $totalElapsed)"
Write-Host "Results in:  $localOutputDir"
if (-not $SkipDestroy) {
    Write-Host "VM status:   DESTROYED (no ongoing charges)" -ForegroundColor Green
}
Write-Host "============================================" -ForegroundColor Cyan
```

**Commit**: `feat: add fully automated GCP run script (create → run → download → destroy)`

---

## Step 5: Create GCP convenience bash wrapper (for Linux/Mac if needed)

**File**: `cloud/run_gcp_job.sh`

A simpler bash version for non-Windows use. Same logic.

```bash
#!/bin/bash
# =============================================================
# GCP Automated Run — Strategy Discovery Engine
# Usage: bash cloud/run_gcp_job.sh [config_file]
# =============================================================
set -e

CONFIG_FILE="${1:-cloud/config_es_all_timeframes_gcp96.yaml}"
INSTANCE_NAME="strategy-sweep"
ZONE="australia-southeast2-a"
MACHINE_TYPE="n2-highcpu-96"
DATA_DIR="Data"
TIMESTAMP=$(date +%Y%m%d_%H%M)
OUTPUT_DIR="cloud_outputs_${TIMESTAMP}"
STARTUP_SCRIPT="cloud/gcp_startup.sh"

echo "============================================"
echo " GCP Strategy Engine — Automated Run"
echo "============================================"
echo "Config:  $CONFIG_FILE"
echo "Machine: $MACHINE_TYPE"
echo "Zone:    $ZONE"
echo "============================================"

# Step 1: Create VM
echo "[1/7] Creating VM..."
gcloud compute instances create "$INSTANCE_NAME" \
    --zone="$ZONE" \
    --machine-type="$MACHINE_TYPE" \
    --provisioning-model=SPOT \
    --instance-termination-action=STOP \
    --image-family=ubuntu-2404-lts-amd64 \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=120GB \
    --boot-disk-type=pd-ssd \
    --metadata-from-file startup-script="$STARTUP_SCRIPT"

# Step 2: Wait for SSH
echo "[2/7] Waiting for SSH..."
for i in $(seq 1 30); do
    if gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" --command="echo ready" 2>/dev/null; then
        echo "  SSH ready."
        break
    fi
    echo "  Attempt $i/30..."
    sleep 10
done

# Step 3: Create upload dir
echo "[3/7] Preparing upload directory..."
gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" --command="mkdir -p ~/uploads"

# Step 4: Upload data + config
echo "[4/7] Uploading data files..."
for csv in "$DATA_DIR"/*.csv; do
    [ -f "$csv" ] || continue
    echo "  Uploading $(basename "$csv")..."
    gcloud compute scp "$csv" "${INSTANCE_NAME}:~/uploads/" --zone="$ZONE"
done
echo "  Uploading config..."
gcloud compute scp "$CONFIG_FILE" "${INSTANCE_NAME}:~/uploads/config.yaml" --zone="$ZONE"

# Step 5: Poll for completion
echo "[5/7] Waiting for engine to complete..."
echo "  (This typically takes 4-5 hours for a 4-timeframe ES sweep)"
POLL_START=$(date +%s)

while true; do
    sleep 60
    ELAPSED=$(( ($(date +%s) - POLL_START) / 60 ))

    STATUS=$(gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" \
        --command="cat /tmp/engine_status 2>/dev/null || echo PENDING" 2>/dev/null || echo "SSH_ERROR")
    STATUS=$(echo "$STATUS" | tr -d '[:space:]')

    echo "  [${ELAPSED}m] Status: $STATUS"

    if [[ "$STATUS" == "COMPLETED" ]]; then
        echo "  Engine completed!"
        break
    elif [[ "$STATUS" == FAILED* ]]; then
        echo "  Engine FAILED!"
        break
    fi
done

# Step 6: Download results
echo "[6/7] Downloading results to $OUTPUT_DIR..."
mkdir -p "$OUTPUT_DIR"
gcloud compute scp --recurse "${INSTANCE_NAME}:~/outputs/*" "$OUTPUT_DIR/" --zone="$ZONE"
echo "  Results in: $OUTPUT_DIR"

# Step 7: DESTROY VM
echo "[7/7] Destroying VM..."
gcloud compute instances delete "$INSTANCE_NAME" --zone="$ZONE" --quiet
echo "  VM destroyed. No more billing."

echo ""
echo "============================================"
echo " Run Complete — $(( ($(date +%s) - POLL_START) / 60 )) minutes"
echo " Results in: $OUTPUT_DIR"
echo " VM: DESTROYED"
echo "============================================"
```

Make it executable:
```bash
chmod +x cloud/run_gcp_job.sh
```

**Commit**: `feat: add bash GCP automation script`

---

## Step 6: Update CLAUDE.md and CHANGELOG_DEV.md

### CLAUDE.md updates:
- Mark completed items in the issues list:
  - [x] Portfolio evaluator timeframe bug fixed
  - [x] GCP automation scripts (PowerShell + bash)
  - [x] GCP startup script for unattended runs
- Add `cloud/run_gcp_job.ps1`, `cloud/run_gcp_job.sh`, `cloud/gcp_startup.sh` to the repository structure section
- Update "Last updated" line to `2026-03-20 — Session 8`
- Add a new issue: `[ ] Re-run ES all timeframes with fixed portfolio evaluator to get correct MC/correlation/yearly stats`
- Update test count: was 17, now 19 (2 new tests)

### CHANGELOG_DEV.md:
Add new entry at the TOP:

```
## 2026-03-20 — Session 8: Portfolio evaluator bug fix + GCP automation

**What was done**:
- CRITICAL BUG FIX: portfolio_evaluator.py now passes `timeframe` to `get_required_sma_lengths()`, `get_required_avg_range_lookbacks()`, `get_required_momentum_lookbacks()`, and `build_candidate_specific_strategy()` during trade reconstruction
  - Bug caused: Daily MR showed 149 trades/$41K in portfolio eval vs 351 trades/$3M in engine (73x gap)
  - Bug caused: Daily Breakout showed -$27K (losing) vs +$245K in engine (sign flip!)
  - Bug caused: Daily Trend missing entirely from portfolio evaluation
  - Root: `_rebuild_strategy_from_leaderboard_row()` never passed timeframe, so all strategies reconstructed with 60m SMA/ATR/momentum defaults
- Created `cloud/gcp_startup.sh` — VM boot script: installs deps, clones repo, waits for data uploads, runs engine, copies outputs
- Created `cloud/run_gcp_job.ps1` — fully automated PowerShell script: create VM → upload data → poll completion → download results → destroy VM
- Created `cloud/run_gcp_job.sh` — bash equivalent for Linux/Mac
- Key GCP gotchas handled: PuTTY SCP issues (uses native SSH), permission model (uploads to ~/uploads, startup script copies to /root/), SPOT preemption detection and restart
- Added 2 new smoke tests for portfolio evaluator timeframe parameter

**Output changes vs Session 7**:
- Portfolio evaluator now produces correct trade reconstructions for all timeframes
- Previous run's portfolio_review_table.csv, correlation_matrix.csv, yearly_stats_breakdown.csv were WRONG for non-60m — need re-run
- 19 smoke tests pass (was 17)
- GCP runs now fully automated with one command

**Verified**:
- All 19 smoke tests pass
- Portfolio evaluator signature accepts timeframe parameter
- GCP scripts have correct path handling and VM cleanup

**Impact on previous results**:
- Master leaderboard strategy rankings (from engine) are still valid
- Portfolio evaluation outputs (MC drawdowns, correlations, yearly stats) need re-running
- The 9 accepted strategies are still real — but their validated performance metrics need recalculation

**Next session priorities**:
1. Re-run ES all timeframes on GCP with fixed code to get correct portfolio evaluation
2. Run prop firm simulator on corrected trade lists
3. Build portfolio of 3-6 uncorrelated strategies for The5ers Bootcamp
4. Run ES 5m, then CL/NQ/GC
```

**Commit**: `docs: update CLAUDE.md and CHANGELOG_DEV.md for Session 8`

---

## Final: Push to GitHub

```bash
git push origin main
```

---

## Summary of deliverables

| # | File | What |
|---|------|------|
| 1 | `modules/portfolio_evaluator.py` | CRITICAL FIX: pass timeframe through strategy reconstruction |
| 2 | `tests/test_smoke.py` | 2 new tests for timeframe parameter in portfolio evaluator |
| 3 | `cloud/gcp_startup.sh` | VM boot script: install, clone, wait for data, run, copy outputs |
| 4 | `cloud/run_gcp_job.ps1` | PowerShell: create VM → upload → poll → download → DESTROY VM |
| 5 | `cloud/run_gcp_job.sh` | Bash equivalent of above |
| 6 | `CLAUDE.md` | Updated issues, structure, test count |
| 7 | `CHANGELOG_DEV.md` | Session 8 entry at top |

---

## How to run this session

Copy-paste this into VS Code terminal:

```
claude --dangerously-skip-permissions "Read SESSION_8_TASKS.md in the repo root. Follow every step in order. Commit after each step with the specified commit message. Run the existing smoke tests after Step 2 to verify nothing is broken: python -m pytest tests/test_smoke.py -v. Push to GitHub at the end. Do not skip any steps."
```
