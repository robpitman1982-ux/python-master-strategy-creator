# SESSION 10 TASKS — Fix GCP Username Detection + Download Reliability
# Date: 2026-03-20

---

## Context

Session 9 fixed 10 automation bugs and added the Streamlit dashboard. The GCP run completed successfully (engine finished, automation script detected COMPLETED), but the download step produced an empty directory because the GCP username was wrong. The script guesses the username from the email address (`robpitman1982@gmail.com` → `robpitman1982`) but the actual GCP OS Login user was `Rob` (capital R). Every SCP and SSH path using `$RemoteHome` silently failed.

This session has ONE job: make the download actually work. Small, focused fixes.

Work through each step in order. Commit after each step. Push to GitHub when all done.

---

## Step 1: Fix PowerShell script — detect username dynamically via SSH

**File**: `cloud/run_gcp_job.ps1`

### The problem
The script tries to guess the GCP username from the email address:
```powershell
$GcpAccount = (& $Gcloud config get-value account 2>$null).Trim()
$GcpUser = ($GcpAccount -split "@")[0] -replace "\.", "_"
```
This produced `robpitman1982` but the actual OS Login user was `Rob`. All paths were wrong.

### The fix
Replace the static username detection with dynamic detection AFTER SSH is ready. 

**A) Remove the early static detection block.** Find and delete these lines (they're before STEP 1):
```powershell
# --- Detect GCP username (OS Login maps to lowercase email prefix) ---
$GcpAccount = (& $Gcloud config get-value account 2>$null).Trim()
$GcpUser = ($GcpAccount -split "@")[0] -replace "\.", "_"
if (-not $GcpUser) { $GcpUser = "rob" }
$RemoteHome = "/home/$GcpUser"
Write-Host "Detected GCP user: $GcpUser (home: $RemoteHome)" -ForegroundColor Gray
```

Replace with a placeholder:
```powershell
# --- GCP username detected dynamically after SSH is ready (Step 2b) ---
$GcpUser = "pending"
$RemoteHome = "pending"
```

Also remove `GCP user` from the info header (the `Write-Host "GCP user:  $GcpUser"` line) since we don't know it yet.

**B) Add dynamic detection right after SSH is confirmed ready (after the SSH loop, before Step 3).** Insert a new Step 2b:

```powershell
# ---------------------------------------------------------------
# STEP 2b: Detect actual remote username and home directory
# ---------------------------------------------------------------
Write-Host "`n[2b] Detecting remote username..." -ForegroundColor Yellow

$GcpUser = (& $Gcloud compute ssh $InstanceName --zone=$Zone --command="whoami" 2>$null | Out-String).Trim()
$RemoteHome = (& $Gcloud compute ssh $InstanceName --zone=$Zone --command="echo `$HOME" 2>$null | Out-String).Trim()

# Fallback if detection failed
if (-not $GcpUser -or $GcpUser -eq "") {
    $GcpAccount = (& $Gcloud config get-value account 2>$null).Trim()
    $GcpUser = ($GcpAccount -split "@")[0] -replace "\.", "_"
    if (-not $GcpUser) { $GcpUser = "rob" }
}
if (-not $RemoteHome -or $RemoteHome -eq "" -or $RemoteHome -eq "pending") {
    $RemoteHome = "/home/$GcpUser"
}

Write-Host "  Remote user: $GcpUser" -ForegroundColor Green
Write-Host "  Remote home: $RemoteHome" -ForegroundColor Green
```

**C) Add download verification after the SCP in Step 6.** After the `& $Gcloud compute scp --recurse ...` line, add a check:

```powershell
# Verify download actually got files
$downloadedFiles = Get-ChildItem -Path $localOutputDir -Recurse -File -ErrorAction SilentlyContinue
if ($downloadedFiles.Count -eq 0) {
    Write-Host "  WARNING: Download directory is empty! Trying alternative path..." -ForegroundColor Red
    # Try downloading from /root directly using sudo + tar
    & $Gcloud compute ssh $InstanceName --zone=$Zone --command="sudo tar czf /tmp/outputs.tar.gz -C /root/python-master-strategy-creator Outputs/ 2>/dev/null; sudo chmod 644 /tmp/outputs.tar.gz"
    & $Gcloud compute scp "${InstanceName}:/tmp/outputs.tar.gz" "$localOutputDir/outputs.tar.gz" --zone=$Zone
    if (Test-Path "$localOutputDir/outputs.tar.gz") {
        # Extract tar on Windows (requires tar, available in Win10+)
        tar -xzf "$localOutputDir/outputs.tar.gz" -C "$localOutputDir"
        Remove-Item "$localOutputDir/outputs.tar.gz" -ErrorAction SilentlyContinue
        $downloadedFiles = Get-ChildItem -Path $localOutputDir -Recurse -File -ErrorAction SilentlyContinue
        Write-Host "  Fallback download: got $($downloadedFiles.Count) files" -ForegroundColor Yellow
    }
}

if ($downloadedFiles.Count -eq 0) {
    Write-Host "  CRITICAL: Still no files downloaded. DO NOT destroy VM!" -ForegroundColor Red
    Write-Host "  Manually download with:" -ForegroundColor Red
    Write-Host "    gcloud compute ssh $InstanceName --zone=$Zone --command=`"sudo tar czf /tmp/out.tar.gz -C /root/python-master-strategy-creator Outputs/`"" -ForegroundColor Red
    Write-Host "    gcloud compute scp ${InstanceName}:/tmp/out.tar.gz . --zone=$Zone" -ForegroundColor Red
    $SkipDestroy = $true  # Override — don't destroy if we got nothing
}
```

**Commit**: `fix: detect GCP username dynamically via SSH, add download fallback with tar`

---

## Step 2: Fix bash script — same dynamic username detection

**File**: `cloud/run_gcp_job.sh`

Same fix: replace the static username detection with dynamic detection after SSH is ready.

**A) Replace the early static detection:**
```bash
# Detect GCP username (OS Login maps email prefix to Linux username)
GCP_ACCOUNT=$(gcloud config get-value account 2>/dev/null)
GCP_USER=$(echo "$GCP_ACCOUNT" | cut -d@ -f1 | tr '.' '_')
if [ -z "$GCP_USER" ]; then
    GCP_USER="rob"
fi
REMOTE_HOME="/home/${GCP_USER}"
```

With a placeholder:
```bash
# GCP username detected dynamically after SSH is ready (Step 2b)
GCP_USER="pending"
REMOTE_HOME="pending"
```

**B) After the SSH ready loop, add:**
```bash
# Step 2b: Detect actual remote username
echo "[2b] Detecting remote username..."
GCP_USER=$(gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" --command="whoami" 2>/dev/null | tr -d '[:space:]')
REMOTE_HOME=$(gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" --command='echo $HOME' 2>/dev/null | tr -d '[:space:]')

if [ -z "$GCP_USER" ]; then
    GCP_ACCOUNT=$(gcloud config get-value account 2>/dev/null)
    GCP_USER=$(echo "$GCP_ACCOUNT" | cut -d@ -f1 | tr '.' '_')
    [ -z "$GCP_USER" ] && GCP_USER="rob"
fi
[ -z "$REMOTE_HOME" ] && REMOTE_HOME="/home/${GCP_USER}"

echo "  Remote user: $GCP_USER"
echo "  Remote home: $REMOTE_HOME"
```

**C) Add the same tar fallback in the download step:**
```bash
# Verify download got files
FILE_COUNT=$(find "$OUTPUT_DIR" -type f 2>/dev/null | wc -l)
if [ "$FILE_COUNT" -eq 0 ]; then
    echo "  WARNING: Download empty! Trying tar fallback..."
    gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" \
        --command="sudo tar czf /tmp/outputs.tar.gz -C /root/python-master-strategy-creator Outputs/ 2>/dev/null; sudo chmod 644 /tmp/outputs.tar.gz"
    gcloud compute scp "${INSTANCE_NAME}:/tmp/outputs.tar.gz" "$OUTPUT_DIR/outputs.tar.gz" --zone="$ZONE"
    if [ -f "$OUTPUT_DIR/outputs.tar.gz" ]; then
        tar -xzf "$OUTPUT_DIR/outputs.tar.gz" -C "$OUTPUT_DIR"
        rm -f "$OUTPUT_DIR/outputs.tar.gz"
        FILE_COUNT=$(find "$OUTPUT_DIR" -type f 2>/dev/null | wc -l)
        echo "  Fallback: got $FILE_COUNT files"
    fi
fi

if [ "$FILE_COUNT" -eq 0 ]; then
    echo "  CRITICAL: No files downloaded. Skipping VM destroy."
    echo "  Manual download: gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command='sudo tar czf /tmp/out.tar.gz -C /root/python-master-strategy-creator Outputs/'"
    echo "  Then: gcloud compute scp ${INSTANCE_NAME}:/tmp/out.tar.gz . --zone=$ZONE"
    exit 1  # Don't destroy
fi
```

**Commit**: `fix: bash script — dynamic username detection, tar download fallback`

---

## Step 3: Fix startup script — also copy outputs to a known fixed path

**File**: `cloud/gcp_startup.sh`

Add a second output copy to a predictable path that doesn't depend on username:

At the end of the script, after the existing user-home copy, add:

```bash
# Also copy to /tmp/engine_outputs as a guaranteed fallback path
sudo mkdir -p /tmp/engine_outputs
sudo cp -r "$WORK_DIR/Outputs/"* /tmp/engine_outputs/ 2>/dev/null || true
sudo cp /tmp/engine_run.log /tmp/engine_outputs/ 2>/dev/null || true
sudo chmod -R 755 /tmp/engine_outputs
echo "Outputs also available at /tmp/engine_outputs/"
```

This gives the download script a guaranteed fallback path that works regardless of username issues.

**Commit**: `fix: startup script copies outputs to /tmp/engine_outputs as fallback`

---

## Step 4: Update CLAUDE.md and CHANGELOG_DEV.md

### CHANGELOG_DEV.md — add at TOP:

```
## 2026-03-20 — Session 10: GCP download reliability fix

**What was done**:
- Root cause of Session 8 empty download: GcpUser detected as "robpitman1982" but actual OS Login user was "Rob"
- All SCP/SSH paths using /home/robpitman1982/ silently failed, download got 0 files, then VM was destroyed
- Fix: detect username dynamically via `whoami` and `$HOME` after SSH is ready (not guessed from email)
- Added tar-based download fallback: if SCP download is empty, tar the outputs on VM and SCP the tarball
- Safety: if download is still empty after fallback, script refuses to destroy VM and prints manual commands
- Startup script now also copies outputs to /tmp/engine_outputs/ as a guaranteed fallback path
- Applied same fixes to both PowerShell and bash scripts

**Verified**:
- All 19 smoke tests still pass
- PowerShell script syntax validated

**Next session priorities**:
1. Run ES 4-timeframe sweep with fixed automation (should be fully unattended this time)
2. Analyze results with Streamlit dashboard
3. Run prop firm simulator
4. ES 5m, then CL/NQ/GC
```

### CLAUDE.md:
- Update "Last updated" to Session 10
- Mark: `[x] GCP download reliability — dynamic username, tar fallback, safety gate`

**Commit**: `docs: update CLAUDE.md and CHANGELOG_DEV.md for Session 10`

---

## Final: Push to GitHub

```bash
git push origin main
```

---

## Summary of deliverables

| # | File | What |
|---|------|------|
| 1 | `cloud/run_gcp_job.ps1` | Dynamic username via SSH whoami, tar download fallback, safety gate |
| 2 | `cloud/run_gcp_job.sh` | Same fixes for bash |
| 3 | `cloud/gcp_startup.sh` | Copy outputs to /tmp/engine_outputs/ as fallback |
| 4 | `CLAUDE.md` | Updated |
| 5 | `CHANGELOG_DEV.md` | Session 10 entry |

---

## How to run this session

Copy-paste into VS Code terminal:

```
claude --dangerously-skip-permissions "Read SESSION_10_TASKS.md in the repo root. Follow every step in order. Commit after each step with the specified commit message. Run smoke tests to verify nothing broke: python -m pytest tests/test_smoke.py -v. Push to GitHub at the end. Do not skip any steps."
```

## After Session 10: Launch the GCP run

```
claude --dangerously-skip-permissions "Run the GCP automation script for a full ES 4-timeframe sweep. Execute: powershell -File cloud/run_gcp_job.ps1 -ConfigFile cloud/config_es_all_timeframes_gcp96.yaml. Monitor it and report when it completes or fails."
```
