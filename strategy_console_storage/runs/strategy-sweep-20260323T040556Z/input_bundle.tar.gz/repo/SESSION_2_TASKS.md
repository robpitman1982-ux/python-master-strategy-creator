# OVERNIGHT AUTONOMOUS SETUP + SESSION 2 TASKS

## PART A: Setting up Claude Code for unattended overnight runs

### Option 1 (RECOMMENDED): Allowlist in settings.json + CLI

This lets Claude auto-approve file edits, python runs, and git commands —
but blocks dangerous things like `rm -rf`.

**Step 1**: Create the file `.claude/settings.json` in your project root:

```json
{
  "permissions": {
    "allow": [
      "Edit",
      "MultiEdit",
      "Read",
      "Write",
      "Bash(python *)",
      "Bash(python3 *)",
      "Bash(pip *)",
      "Bash(git add *)",
      "Bash(git commit *)",
      "Bash(git status *)",
      "Bash(git diff *)",
      "Bash(git log *)",
      "Bash(git push *)",
      "Bash(ls *)",
      "Bash(cat *)",
      "Bash(head *)",
      "Bash(tail *)",
      "Bash(grep *)",
      "Bash(find *)",
      "Bash(mkdir *)",
      "Bash(cd *)",
      "Bash(echo *)",
      "Bash(wc *)",
      "Bash(sort *)",
      "Bash(pwd)"
    ],
    "deny": [
      "Bash(rm -rf *)",
      "Bash(del /s *)",
      "Bash(format *)",
      "Bash(shutdown *)"
    ]
  }
}
```

**Step 2**: Open a terminal (PowerShell or cmd) in your project folder.

**Step 3**: Git commit everything first (your safety net):
```
cd "c:\Users\Rob\Documents\GIT Repos\python-master-strategy-creator"
git add -A
git commit -m "checkpoint before overnight session"
```

**Step 4**: Launch Claude Code from the CLI with your task:
```
claude -p "Read CLAUDE.md and CHANGELOG_DEV.md first. Then read SESSION_2_TASKS.md and work through all steps in order. Commit after each step. When all steps are done, update CLAUDE.md and CHANGELOG_DEV.md and do a final commit."
```

The `-p` flag passes the prompt directly and runs headless (no interactive UI).
Combined with the allowlist, it should run through without stopping.

**If it still prompts** (known bug on Windows), use Option 2 instead.


### Option 2: The nuclear flag (safe with precautions)

Same git checkpoint first, then:

```
cd "c:\Users\Rob\Documents\GIT Repos\python-master-strategy-creator"
git add -A
git commit -m "checkpoint before overnight session"
claude --dangerously-skip-permissions -p "Read CLAUDE.md and CHANGELOG_DEV.md first. Then read SESSION_2_TASKS.md and work through all steps in order. Commit after each step. When all steps are done, update CLAUDE.md and CHANGELOG_DEV.md and do a final commit."
```

This auto-approves EVERYTHING. It is safe here because:
- You've git committed, so `git reset --hard HEAD~N` undoes anything
- The task is well-scoped (code edits + python runs + git commits)
- No production systems, no secrets, no network access needed
- Your Data/ and Outputs/ are gitignored so worst case you re-run

**Why the scary name is fine for your case**: Anthropic named it to scare people
running it on production servers. You're running it on a local dev repo with
git as your undo button. That's exactly the use case even Anthropic engineers use it for.


### Option 3: Auto Mode (newest, research preview)

If you have Claude Code v2.0+:
```
claude --enable-auto-mode -p "Read CLAUDE.md... [same prompt]"
```

This is a middle ground — Claude makes judgment calls about what to auto-approve.
It's newer and less battle-tested but designed for exactly this scenario.


### IMPORTANT: VS Code extension vs CLI

The VS Code extension panel ("Claude Code" sidebar) has known bugs where
permission settings get ignored. For overnight unattended work, always use
the CLI in a terminal window instead. You can still have VS Code open —
just run `claude` from the VS Code integrated terminal or a separate PowerShell window.

To verify Claude Code CLI is installed, run:
```
claude --version
```

If it's not installed, install via npm:
```
npm install -g @anthropic-ai/claude-code
```

---
---

## PART B: What to work on next (Session 2)

The goal is to make the pipeline structure bulletproof before cloud deployment.
Session 1 hardened the scoring and gating. Session 2 makes it configurable,
adds consistency checks, and preps for multi-dataset expansion.

---

## STEP 1: Move hardcoded config to a YAML file

The pipeline currently has constants scattered across master_strategy_engine.py
and each strategy type class. Before cloud deployment, everything configurable
needs to live in one place.

### 1a. Install PyYAML

```bash
pip install pyyaml
```

### 1b. Create `config.yaml` in the project root

```yaml
# ============================================================
# Master Strategy Engine Configuration
# ============================================================

# --- Data source ---
datasets:
  - path: "Data/ES_60m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "60m"

# Which strategy families to run ("all" or list specific names)
strategy_types: "all"

# --- Engine defaults ---
engine:
  initial_capital: 250000.0
  risk_per_trade: 0.01
  commission_per_contract: 2.00
  slippage_ticks: 4
  tick_value: 12.50
  dollars_per_point: 50.0

# --- Pipeline controls ---
pipeline:
  max_workers_sweep: 10
  max_workers_refinement: 10
  max_candidates_to_refine: 3
  oos_split_date: "2019-01-01"

# --- Promotion gate (global defaults, strategy types can override) ---
promotion_gate:
  min_profit_factor: 1.00
  min_average_trade: 0.00
  require_positive_net_pnl: false
  min_trades: 50
  min_trades_per_year: 3.0
  max_promoted_candidates: 20

# --- Final leaderboard acceptance ---
leaderboard:
  min_net_pnl: 0.0
  min_pf: 1.00
  min_oos_pf: 1.00
  min_total_trades: 60

# --- Output ---
output_dir: "Outputs"
```

### 1c. Create `modules/config_loader.py`

```python
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


_DEFAULT_CONFIG_PATH = Path("config.yaml")


def load_config(path: Path | str | None = None) -> dict[str, Any]:
    """Load config from YAML file. Falls back to defaults if file missing."""
    config_path = Path(path) if path else _DEFAULT_CONFIG_PATH

    if not config_path.exists():
        print(f"⚠ Config file not found at {config_path}, using hardcoded defaults.")
        return {}

    with open(config_path, "r") as f:
        config = yaml.safe_load(f) or {}

    print(f"✅ Loaded config from {config_path}")
    return config


def get_nested(config: dict, *keys, default: Any = None) -> Any:
    """Safely get a nested config value. Example: get_nested(cfg, 'engine', 'initial_capital')"""
    current = config
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key, default)
        if current is default:
            return default
    return current
```

### 1d. Update `master_strategy_engine.py` to load from config

At the top of the file, after imports, replace the hardcoded constants block with:

```python
from modules.config_loader import load_config, get_nested

# Load configuration
_cfg = load_config()

CSV_PATH = Path(get_nested(_cfg, "datasets", default=[{}])[0].get("path", "Data/ES_60m_2008_2026_tradestation.csv"))
STRATEGY_TYPE_NAME = get_nested(_cfg, "strategy_types", default="all")
OUTPUTS_DIR = Path(get_nested(_cfg, "output_dir", default="Outputs"))

MAX_WORKERS_SWEEP = get_nested(_cfg, "pipeline", "max_workers_sweep", default=10)
MAX_WORKERS_REFINEMENT = get_nested(_cfg, "pipeline", "max_workers_refinement", default=10)
MAX_CANDIDATES_TO_REFINE = get_nested(_cfg, "pipeline", "max_candidates_to_refine", default=3)

FINAL_MIN_NET_PNL = get_nested(_cfg, "leaderboard", "min_net_pnl", default=0.0)
FINAL_MIN_PF = get_nested(_cfg, "leaderboard", "min_pf", default=1.00)
FINAL_MIN_OOS_PF = get_nested(_cfg, "leaderboard", "min_oos_pf", default=1.00)
FINAL_MIN_TOTAL_TRADES = get_nested(_cfg, "leaderboard", "min_total_trades", default=60)
```

Keep the old hardcoded values as the defaults so the pipeline still works if config.yaml is missing.

### 1e. Update EngineConfig construction in run_single_family()

In `run_single_family()`, where `EngineConfig` is created, pull values from config:

```python
    cfg = EngineConfig(
        initial_capital=get_nested(_cfg, "engine", "initial_capital", default=250_000.0),
        risk_per_trade=get_nested(_cfg, "engine", "risk_per_trade", default=0.01),
        symbol=market_symbol,
        commission_per_contract=get_nested(_cfg, "engine", "commission_per_contract", default=2.00),
        slippage_ticks=get_nested(_cfg, "engine", "slippage_ticks", default=4),
        tick_value=get_nested(_cfg, "engine", "tick_value", default=12.50),
        dollars_per_point=get_nested(_cfg, "engine", "dollars_per_point", default=50.0),
    )
```

**Git commit**: `feat: move hardcoded config to config.yaml with loader`

---

## STEP 2: Add yearly consistency check

The trend strategy lost money in 9 out of 11 years (2009-2018) before having
two big winning years. The engine should automatically flag this pattern.

### 2a. Add a consistency analysis function to engine.py

Add this as a standalone function (not a method) near the bottom of engine.py,
or in a new file `modules/consistency.py`:

```python
from __future__ import annotations

import pandas as pd


def analyse_yearly_consistency(
    trades: list,
    min_years: int = 5,
) -> dict[str, float | str]:
    """
    Analyse year-by-year PnL consistency from a list of Trade objects.

    Returns:
        pct_profitable_years: fraction of years with positive PnL
        max_consecutive_losing_years: longest streak of losing years
        consistency_flag: "CONSISTENT", "INCONSISTENT", or "INSUFFICIENT_DATA"
        yearly_pnls: dict of year -> total PnL
    """
    if not trades:
        return {
            "pct_profitable_years": 0.0,
            "max_consecutive_losing_years": 0,
            "consistency_flag": "INSUFFICIENT_DATA",
            "yearly_pnls": {},
        }

    yearly_pnl: dict[int, float] = {}
    for t in trades:
        year = t.exit_time.year
        yearly_pnl[year] = yearly_pnl.get(year, 0.0) + t.pnl

    years_sorted = sorted(yearly_pnl.keys())

    if len(years_sorted) < min_years:
        return {
            "pct_profitable_years": 0.0,
            "max_consecutive_losing_years": 0,
            "consistency_flag": "INSUFFICIENT_DATA",
            "yearly_pnls": yearly_pnl,
        }

    profitable_years = sum(1 for y in years_sorted if yearly_pnl[y] > 0)
    pct_profitable = profitable_years / len(years_sorted)

    # Max consecutive losing years
    max_losing_streak = 0
    current_streak = 0
    for y in years_sorted:
        if yearly_pnl[y] <= 0:
            current_streak += 1
            max_losing_streak = max(max_losing_streak, current_streak)
        else:
            current_streak = 0

    # Flag logic
    if pct_profitable < 0.40 or max_losing_streak >= 5:
        flag = "INCONSISTENT"
    elif pct_profitable >= 0.60 and max_losing_streak <= 2:
        flag = "CONSISTENT"
    else:
        flag = "MIXED"

    return {
        "pct_profitable_years": round(pct_profitable, 4),
        "max_consecutive_losing_years": max_losing_streak,
        "consistency_flag": flag,
        "yearly_pnls": yearly_pnl,
    }
```

### 2b. Integrate into the results() method of MasterStrategyEngine

At the end of the `results()` method, before the return statement, add:

```python
        # Yearly consistency analysis
        consistency = analyse_yearly_consistency(self.trades)
```

Add these to the return dict:

```python
            "Pct Profitable Years": f"{consistency['pct_profitable_years']:.4f}",
            "Max Consecutive Losing Years": consistency["max_consecutive_losing_years"],
            "Consistency Flag": consistency["consistency_flag"],
```

### 2c. Propagate through sweep and refiner outputs

Same pattern as quality_score — add `consistency_flag` and
`pct_profitable_years` to the sweep result dicts in all three strategy types,
and to `RefinementResult` in refiner.py. Parse them the same way
(string for flag, float for percentage).

### 2d. Factor consistency into quality_score

In `calculate_quality_score()`, add a 6th component for consistency.
Adjust the weights to keep them summing to 1.0:

```python
    # Updated weights (add consistency, slightly reduce others):
    # pf_strength: 0.25, balance: 0.20, trade_confidence: 0.15,
    # recent: 0.15, oos_penalty: 0.10, consistency: 0.15
```

Add a consistency component:
```python
    # Component 6: Yearly consistency (if available, else neutral 0.5)
    consistency_val = pct_profitable_years if pct_profitable_years is not None else 0.5
    consistency_component = consistency_val  # Already 0-1 range
```

This means `calculate_quality_score` needs two new parameters:
`pct_profitable_years: float | None = None` and
`max_consecutive_losing_years: int = 0`.

Update all call sites to pass these values.

**Git commit**: `feat: add yearly consistency analysis and flag`

---

## STEP 3: Make the OOS split date configurable

Currently "2019-01-01" is hardcoded in engine.py. It needs to come from config.

### 3a. Add oos_split_date to EngineConfig

In the `EngineConfig` dataclass in engine.py, add:

```python
    oos_split_date: str = "2019-01-01"
```

### 3b. Replace the hardcoded date in engine.py

Find `oos_split_date = pd.to_datetime("2019-01-01")` in the `results()` method
and replace with:

```python
        oos_split_date = pd.to_datetime(self.config.oos_split_date)
```

### 3c. Also replace in portfolio_evaluator.py

Find the `OOS_SPLIT_DATE = "2019-01-01"` constant at the top of
`portfolio_evaluator.py`. This should also come from the config. Either:
- Pass it through as a parameter, or
- Import from config_loader

The cleanest approach: make `evaluate_portfolio()` accept an `oos_split_date`
parameter, and pass it from `master_strategy_engine.py` where the config is loaded.

### 3d. Update run_single_family() to pass the date

When constructing `EngineConfig`:
```python
    cfg = EngineConfig(
        ...
        oos_split_date=get_nested(_cfg, "pipeline", "oos_split_date", default="2019-01-01"),
    )
```

**Git commit**: `feat: make OOS split date configurable via config.yaml`

---

## STEP 4: Add multi-dataset loop support

The config.yaml already supports a list of datasets. Wire up the main loop.

### 4a. Update the __main__ block in master_strategy_engine.py

Replace the current single-dataset logic with a loop:

```python
if __name__ == "__main__":
    total_start = time.perf_counter()
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)

    datasets = get_nested(_cfg, "datasets", default=[])
    if not datasets:
        # Fallback: single dataset from CSV_PATH
        datasets = [{"path": str(CSV_PATH), "market": "ES", "timeframe": "60m"}]

    all_run_summaries: list[dict[str, Any]] = []

    for ds_idx, ds in enumerate(datasets):
        ds_path = Path(ds.get("path", str(CSV_PATH)))
        ds_market = ds.get("market", "UNKNOWN")
        ds_timeframe = ds.get("timeframe", "UNKNOWN")

        print(f"\n{'='*72}")
        print(f"📂 DATASET {ds_idx + 1}/{len(datasets)}: {ds_market} {ds_timeframe}")
        print(f"   Path: {ds_path}")
        print(f"{'='*72}")

        # Create dataset-specific output directory
        ds_output_dir = OUTPUTS_DIR / f"{ds_market}_{ds_timeframe}"
        ds_output_dir.mkdir(parents=True, exist_ok=True)

        family_names = list_strategy_types() if STRATEGY_TYPE_NAME == "all" else [STRATEGY_TYPE_NAME]
        dataset_summaries: list[dict[str, Any]] = []

        for family_name in family_names:
            summary_row = run_single_family(
                strategy_type_name=family_name,
                dataset_path=ds_path,
                outputs_dir=ds_output_dir,
                max_workers_sweep=MAX_WORKERS_SWEEP,
                max_workers_refinement=MAX_WORKERS_REFINEMENT,
                market_symbol=ds_market,
            )
            dataset_summaries.append(summary_row)

        # Save per-dataset results
        ds_summary_df = pd.DataFrame(dataset_summaries)
        ds_summary_df.to_csv(ds_output_dir / "family_summary_results.csv", index=False)

        leaderboard_df = build_family_leaderboard(ds_summary_df)
        if not leaderboard_df.empty:
            leaderboard_df.to_csv(ds_output_dir / "family_leaderboard_results.csv", index=False)

        all_run_summaries.extend(dataset_summaries)

    # Save combined results across all datasets
    if len(datasets) > 1:
        combined_df = pd.DataFrame(all_run_summaries)
        combined_df.to_csv(OUTPUTS_DIR / "all_datasets_summary.csv", index=False)

    total_elapsed = time.perf_counter() - total_start
    print(f"\n⏱ Total runtime: {total_elapsed:.2f} seconds")
```

### 4b. Also make sure the portfolio evaluator runs per dataset

The `evaluate_portfolio()` call happens after the leaderboard is built.
Make sure it also uses the dataset-specific output directory. Find where
it's called and update the output path.

**IMPORTANT**: Do NOT add extra datasets to config.yaml yet — keep it
as just ES 60m for now. This step is about making the code ready for
expansion. We'll add more datasets when we have the data files.

**Git commit**: `feat: add multi-dataset loop support`

---

## STEP 5: Test everything end-to-end

```bash
python master_strategy_engine.py
```

### Verify:
1. Config loads from config.yaml (look for "✅ Loaded config from config.yaml")
2. Compute budget prints before each stage
3. Promoted candidates are capped at 20
4. Consistency flags appear in output
5. Output goes to Outputs/ES_60m/ subdirectory (new structure)
6. No errors, no broken imports

### If the pipeline run is too slow to wait for (it will be ~45 minutes):
You can test with a single fast family first:
- Edit config.yaml: change `strategy_types: "all"` to `strategy_types: "mean_reversion"`
- MR has only 792 combos × 27 promoted × 192 refinements — much faster than trend

---

## STEP 6: Update docs and commit

### Update CLAUDE.md:
- Check off completed items in the issues list
- Add any new issues discovered
- Update the "Last updated" line
- Update the repo structure section if new files were added (config.yaml, config_loader.py, consistency.py)

### Update CHANGELOG_DEV.md:
Add new entry at the TOP with:
- What was done
- Output changes
- Next session priorities (cloud deployment prep: Dockerfile, run scripts, cost estimation)

### Final commit:
```bash
git add -A
git commit -m "Session 2: config.yaml, consistency check, OOS date config, multi-dataset loop"
git push origin main
```
