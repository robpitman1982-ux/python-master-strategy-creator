# SESSION 6 TASKS — Multi-Timeframe ES Expansion (48-Core Cloud Run)
# Date: 2026-03-18
# Depends on: Session 5 completed (smoke tests, master leaderboard, timeframe grids)

---

## Context

Session 5 added smoke tests, the master leaderboard aggregator, and timeframe-aware refinement grids. The engine can now scale hold_bars/momentum_lookback automatically based on dataset timeframe.

**This session's goal**: Prepare and launch a full 4-timeframe ES sweep (Daily, 60m, 30m, 15m) on a 48-core DigitalOcean droplet. All 3 strategy families (trend, MR, breakout) on each timeframe.

**Estimated runtime**: ~7 hours on 48 cores.
**Estimated cost**: ~$15 (48-core dedicated at ~$2.14/hr).

**Filter approach**: Hybrid — scale lookback-based parameters (SMA lengths, ATR lookbacks, momentum lookbacks) per timeframe. Keep pattern filters (TwoBarDown, ReversalUpBar, HigherLow, etc.) as-is and let the sweep decide if they're useful on each timeframe.

---

## Step 1: Implement hybrid filter parameter scaling

Session 5 added `get_timeframe_multiplier()` and scaled hold_bars in the refinement grids. This step extends the hybrid approach to **SMA lengths and ATR/avg_range lookbacks** used during the sweep phase (not just refinement).

### A) Add timeframe-aware feature precomputation

In `master_strategy_engine.py`, the `get_required_sma_lengths()` / `get_required_avg_range_lookbacks()` / `get_required_momentum_lookbacks()` calls feed into `add_precomputed_features()`. These determine which SMA/ATR/momentum columns exist in the data.

Update each strategy type to return **timeframe-scaled lookback lists** when a timeframe is provided:

**In `modules/strategy_types/base_strategy_type.py`**, add an optional `timeframe` parameter to:
- `get_required_sma_lengths(timeframe: str = "60m") -> list[int]`
- `get_required_avg_range_lookbacks(timeframe: str = "60m") -> list[int]`
- `get_required_momentum_lookbacks(timeframe: str = "60m") -> list[int]`

Each concrete strategy type overrides these. The base implementation should use `get_timeframe_multiplier()` to scale the values.

**Example for MeanReversionStrategyType**:

Current SMA lengths: `[20, 50, 200]` (calibrated for 60m)
On 15m (multiplier=4): `[80, 200, 800]`
On 30m (multiplier=2): `[40, 100, 400]`
On daily (multiplier=0.154): `[3, 8, 31]` → clamp minimums → `[5, 10, 31]`

The scaling rule:
```python
def scale_lookbacks(base_values: list[int], multiplier: float, min_val: int = 5) -> list[int]:
    """Scale lookback values by timeframe multiplier, deduplicate, enforce minimum."""
    scaled = sorted(set(max(min_val, round(v * multiplier)) for v in base_values))
    return scaled
```

Apply this to SMA lengths, avg_range lookbacks, and momentum lookbacks. Do NOT scale pattern filter parameters (number of bars in TwoBarDown etc.) — those stay as-is.

### B) Thread timeframe into feature precomputation

In `run_single_family()` in `master_strategy_engine.py`, pass `cfg.timeframe` to the `get_required_*` calls:

```python
data = add_precomputed_features(
    data,
    sma_lengths=get_required_sma_lengths(strategy_type, timeframe=cfg.timeframe),
    avg_range_lookbacks=get_required_avg_range_lookbacks(strategy_type, timeframe=cfg.timeframe),
    momentum_lookbacks=get_required_momentum_lookbacks(strategy_type, timeframe=cfg.timeframe),
)
```

Update the helper wrappers (`get_required_sma_lengths()` etc.) to pass through the timeframe parameter.

### C) Update filter constructors to use scaled SMA lengths

The filters that reference specific SMA lengths (e.g. `DistanceBelowSMAFilter(fast_length=20)`, `TrendDirectionFilter(fast_length=50, slow_length=200)`) need to use the scaled values.

**Approach**: Each strategy type's `_build_combo_strategy()` and `_build_refined_strategy()` methods should accept a `timeframe` parameter and scale their default SMA lengths accordingly. The actual filter classes don't change — they already accept `fast_length`/`slow_length` as constructor arguments. We just pass scaled values.

For example, `MeanReversionStrategyType._build_inline_strategy()`:
```python
# Current:
DistanceBelowSMAFilter(fast_length=20, min_distance_points=distance_points)

# With timeframe scaling:
scaled_fast = round(20 * get_timeframe_multiplier(timeframe))
DistanceBelowSMAFilter(fast_length=max(5, scaled_fast), min_distance_points=distance_points)
```

Similarly for trend's `TrendDirectionFilter(fast_length=50, slow_length=200)`:
```python
mult = get_timeframe_multiplier(timeframe)
fast = max(10, round(50 * mult))
slow = max(50, round(200 * mult))
TrendDirectionFilter(fast_length=fast, slow_length=slow)
```

**Important**: The `min_distance_points` parameter in DistanceBelowSMAFilter should NOT be scaled here — that's already handled in the refinement grid. Same for `min_avg_range` in VolatilityFilter.

### D) Add smoke test

Add `test_hybrid_filter_scaling` to `tests/test_smoke.py`:
- Verify that MR `get_required_sma_lengths(timeframe="15m")` returns values ~4x the 60m values
- Verify that trend `get_required_sma_lengths(timeframe="daily")` returns values smaller than 60m
- Verify `scale_lookbacks()` correctly handles edge cases (multiplier < 1, deduplication, min clamp)

**Commit**: `feat: implement hybrid filter parameter scaling for multi-timeframe support`

---

## Step 2: Create 48-core cloud config

**File**: `cloud/config_es_all_timeframes_48core.yaml`

```yaml
# Full ES sweep — 4 timeframes × 3 families on 48-core dedicated CPU
# Estimated runtime: ~7 hours
# Estimated cost: ~$15 ($2.14/hr × 7hr)
# Droplet: dedicated-cpu-48x96gb in syd1

datasets:
  - path: "Data/ES_daily_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "daily"
  - path: "Data/ES_60m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "60m"
  - path: "Data/ES_30m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "30m"
  - path: "Data/ES_15m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "15m"

strategy_types: "all"

engine:
  initial_capital: 250000.0
  risk_per_trade: 0.01
  commission_per_contract: 2.00
  slippage_ticks: 4
  tick_value: 12.50
  dollars_per_point: 50.0

pipeline:
  max_workers_sweep: 46       # Leave 2 cores free for OS on 48-core
  max_workers_refinement: 46
  max_candidates_to_refine: 5  # More candidates — we have the compute
  oos_split_date: "2019-01-01"

promotion_gate:
  min_profit_factor: 1.00
  min_average_trade: 0.00
  require_positive_net_pnl: false
  min_trades: 50
  min_trades_per_year: 3.0
  max_promoted_candidates: 20

leaderboard:
  min_net_pnl: 0.0
  min_pf: 1.00
  min_oos_pf: 1.00
  min_total_trades: 60

output_dir: "Outputs"
```

### Also update `run_cloud_job.py` defaults

Update `DEFAULT_SIZE` to support a `--size` CLI argument so you can specify the 48-core droplet:

```python
# Add to argparse:
parser.add_argument("--size", default="s-2vcpu-4gb-intel",
                    help="DigitalOcean droplet size slug (default: s-2vcpu-4gb-intel)")
```

And update the cloud-init script to read `max_workers` from the config file rather than hardcoding `sed` replacements to 2.

### Update CLOUD_DEPLOYMENT_RUNBOOK.md

Add a section for 48-core runs:

```markdown
## 48-Core Dedicated CPU Run

For multi-timeframe sweeps, use the dedicated-cpu-48x96gb droplet:

### Create the droplet
1. Region: Sydney (SYD1)
2. Image: Ubuntu 24.04 LTS
3. Plan: Dedicated CPU → General Purpose → $2.14/hr (48 vCPUs / 96 GB RAM)
4. Or via CLI: `doctl compute droplet create strategy-48core --region syd1 --size gd-48vcpu-192gb --image ubuntu-24-04-x64 --ssh-keys <KEY_ID>`

### Upload ALL data files
```bash
scp Data/ES_daily_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
scp Data/ES_60m_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
scp Data/ES_30m_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
scp Data/ES_15m_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
```

### Run with 48-core config
```bash
bash run_engine.sh --config cloud/config_es_all_timeframes_48core.yaml
```

### Monitor
```bash
# Per-dataset progress
cat Outputs/ES_daily/status.json
cat Outputs/ES_60m/status.json
cat Outputs/ES_30m/status.json
cat Outputs/ES_15m/status.json

# Follow log
tail -f Outputs/logs/run_*.log
```

### Download and destroy
```bash
# From local machine
scp -r root@<IP>:/root/python-master-strategy-creator/Outputs cloud_outputs_48core
# Then destroy the droplet immediately
```
```

**Commit**: `feat: add 48-core cloud config for multi-timeframe ES sweep`

---

## Step 3: TradeStation data export guide

**File**: `docs/TRADESTATION_EXPORT_GUIDE.md`

Create a step-by-step guide for Rob to export each timeframe from TradeStation. The data loader expects columns: `Date, Time, Open, High, Low, Close, Volume` (or `Up, Down` for tick volume).

```markdown
# TradeStation Data Export Guide

## Required exports for ES multi-timeframe sweep

Export these 4 datasets from TradeStation:

| File name | Symbol | Interval | Date range |
|-----------|--------|----------|------------|
| ES_daily_2008_2026_tradestation.csv | @ES (continuous) | Daily | 01/01/2008 — today |
| ES_60m_2008_2026_tradestation.csv | @ES (continuous) | 60 min | 01/01/2008 — today |
| ES_30m_2008_2026_tradestation.csv | @ES (continuous) | 30 min | 01/01/2008 — today |
| ES_15m_2008_2026_tradestation.csv | @ES (continuous) | 15 min | 01/01/2008 — today |

## Export steps (TradeStation)

1. Open a chart for @ES with the desired interval
2. Set the date range to start from 01/01/2008
3. File → Save As → select "Text/CSV" format
4. Ensure columns include: Date, Time, Open, High, Low, Close, Volume
5. Save to your local `Data/` folder with the naming convention above

## Naming convention

`{MARKET}_{TIMEFRAME}_{START_YEAR}_{END_YEAR}_tradestation.csv`

Examples:
- `ES_daily_2008_2026_tradestation.csv`
- `ES_15m_2008_2026_tradestation.csv`
- `NQ_60m_2008_2026_tradestation.csv`
- `CL_daily_2008_2026_tradestation.csv`

## Expected file sizes (approximate)

| Timeframe | Bars (18 years) | File size |
|-----------|----------------|-----------|
| Daily | ~4,500 | ~300 KB |
| 60m | ~107,000 | ~7 MB |
| 30m | ~214,000 | ~14 MB |
| 15m | ~428,000 | ~28 MB |
| 5m | ~1,300,000 | ~85 MB |

## Verification

After export, verify each file loads correctly:
```bash
python -c "from modules.data_loader import load_tradestation_csv; df = load_tradestation_csv('Data/ES_daily_2008_2026_tradestation.csv'); print(f'{len(df):,} bars, {df.index.min()} to {df.index.max()}')"
```

## Notes

- The data loader auto-detects date format (day-first vs month-first)
- Volume column is optional (falls back to Up+Down or zeros)
- Data before 2008-01-01 is automatically filtered out by the loader
- Make sure TradeStation exports the continuous contract (@ES), not individual months
```

**Commit**: `docs: add TradeStation data export guide for multi-timeframe`

---

## Step 4: Add master leaderboard auto-run at end of pipeline

After all datasets complete in `master_strategy_engine.py`, automatically run the master leaderboard aggregator and print the consolidated results.

In the `__main__` block, after the multi-dataset loop:

```python
if len(datasets) > 1:
    from modules.master_leaderboard import aggregate_master_leaderboard
    
    master_lb = aggregate_master_leaderboard(outputs_root=OUTPUTS_DIR)
    if not master_lb.empty:
        print(f"\n{'='*72}")
        print(f"🏆 MASTER LEADERBOARD — {len(master_lb)} accepted strategies across all datasets")
        print(f"{'='*72}")
        preview_cols = ["rank", "market", "timeframe", "strategy_type", 
                       "leader_strategy_name", "quality_flag", "leader_pf",
                       "leader_net_pnl", "is_pf", "oos_pf", "recent_12m_pf"]
        print(master_lb[[c for c in preview_cols if c in master_lb.columns]].to_string(index=False))
        
        master_path = OUTPUTS_DIR / "master_leaderboard.csv"
        master_lb.to_csv(master_path, index=False)
        print(f"\nSaved to {master_path}")
```

This means after the 48-core run finishes, you'll immediately see a ranked table of every accepted strategy across all four timeframes — the "strategy menu" for portfolio assembly.

**Commit**: `feat: auto-run master leaderboard aggregator after multi-dataset pipeline`

---

## Step 5: Memory-efficient data loading for large timeframes

The 15m dataset (~428K bars) is 4x larger than 60m. With 46 parallel workers, each holding a copy of the dataframe via multiprocessing, memory usage could spike.

### Add memory estimation and warning

In `run_single_family()`, after loading data, print a memory estimate:

```python
data_mb = data.memory_usage(deep=True).sum() / 1_048_576
est_parallel_mb = data_mb * max_workers_sweep
print(f"📊 Data: {len(data):,} bars, {data_mb:.1f} MB per copy")
print(f"   Parallel estimate: {est_parallel_mb:.0f} MB for {max_workers_sweep} workers")
if est_parallel_mb > 60_000:  # 60 GB warning threshold
    print(f"   ⚠ WARNING: Estimated memory usage ({est_parallel_mb:.0f} MB) is high!")
    print(f"   Consider reducing max_workers or switching to chunked processing.")
```

### Optional: Add a `max_memory_gb` config setting

In `config.yaml`:
```yaml
pipeline:
  max_memory_gb: 80  # Auto-reduce workers if estimated memory exceeds this
```

In the sweep, if estimated memory exceeds the limit, automatically reduce `max_workers`:
```python
if est_parallel_mb > max_memory_gb * 1024:
    adjusted_workers = max(2, int(max_memory_gb * 1024 / data_mb))
    print(f"   Auto-reducing workers from {max_workers} to {adjusted_workers} to fit memory budget")
    max_workers = adjusted_workers
```

This is a safety net — on 96 GB RAM with 428K-bar data it won't trigger, but it protects against accidentally running 5m data (1.3M bars) with too many workers.

**Commit**: `feat: add memory estimation and auto-throttle for large datasets`

---

## Step 6: Update docs

### CLAUDE.md updates:
- Mark completed items:
  - [x] Hybrid filter parameter scaling for multi-timeframe
  - [x] 48-core cloud config
  - [x] Master leaderboard auto-run in pipeline
  - [x] Memory estimation for large datasets
- Add `docs/TRADESTATION_EXPORT_GUIDE.md` to repo structure
- Add `cloud/config_es_all_timeframes_48core.yaml` to repo structure
- Update "Last updated" line

### CHANGELOG_DEV.md:
Add new entry at the TOP:

```
## 2026-03-18 — Session 6: Multi-timeframe expansion prep

**What was done**:
- Implemented hybrid filter parameter scaling: SMA lengths, ATR lookbacks, momentum lookbacks scale with timeframe multiplier; pattern filters (TwoBarDown, etc.) stay as-is
- Created cloud/config_es_all_timeframes_48core.yaml — 4 datasets (daily, 60m, 30m, 15m), 46 workers, all 3 families
- Created docs/TRADESTATION_EXPORT_GUIDE.md — step-by-step data export instructions with file naming and verification
- Added master leaderboard auto-run at end of multi-dataset pipeline
- Added memory estimation and auto-throttle (reduces workers if parallel memory estimate exceeds budget)
- Updated CLOUD_DEPLOYMENT_RUNBOOK.md with 48-core instructions
- Added --size CLI argument to run_cloud_job.py

**Output changes vs Session 5**:
- Feature precomputation now uses timeframe-scaled SMA/ATR/momentum lookbacks
- Filter constructors receive scaled SMA lengths based on dataset timeframe
- Refinement grids already scaled (Session 5) — now sweep-phase filters also scale
- Master leaderboard printed automatically after multi-dataset runs
- Memory estimate printed before each family sweep

**Verified**:
- All smoke tests pass (including new hybrid scaling test)
- Config validates correctly for 4-dataset setup
- Memory estimation logic tested with synthetic data

**Next session priorities**:
1. Export ES daily/30m/15m data from TradeStation
2. Destroy old 2-core droplets after downloading results
3. Create 48-core droplet, upload 4 data files, launch full sweep
4. Download master leaderboard results
5. Begin portfolio assembly from cross-timeframe candidates
```

**Commit**: `docs: update CLAUDE.md and CHANGELOG_DEV.md for Session 6`

---

## Final: Push to GitHub

```bash
git push origin main
```

---

## Post-Session: Manual Steps (Rob does these)

These are NOT for Claude Code — they require TradeStation and DigitalOcean access:

### 1. Export data from TradeStation
Follow `docs/TRADESTATION_EXPORT_GUIDE.md` to export:
- `ES_daily_2008_2026_tradestation.csv`
- `ES_30m_2008_2026_tradestation.csv`
- `ES_15m_2008_2026_tradestation.csv`

Place them in your local `Data/` folder.

### 2. Verify each file loads
```bash
python -c "from modules.data_loader import load_tradestation_csv; df = load_tradestation_csv('Data/ES_daily_2008_2026_tradestation.csv'); print(f'{len(df):,} bars')"
python -c "from modules.data_loader import load_tradestation_csv; df = load_tradestation_csv('Data/ES_30m_2008_2026_tradestation.csv'); print(f'{len(df):,} bars')"
python -c "from modules.data_loader import load_tradestation_csv; df = load_tradestation_csv('Data/ES_15m_2008_2026_tradestation.csv'); print(f'{len(df):,} bars')"
```

### 3. Download results from old droplets (if finished) and destroy them
```bash
scp -r root@209.38.86.189:/root/python-master-strategy-creator/Outputs/ES_60m cloud_outputs_droplet1
scp -r root@170.64.193.166:/root/python-master-strategy-creator/Outputs/ES_60m cloud_outputs_droplet2
# Then destroy both droplets in DigitalOcean dashboard
```

### 4. Create 48-core droplet and run
```bash
# Create droplet (via dashboard or CLI)
# SSH in:
ssh root@<NEW_IP>

# Clone latest code (has Session 5 + 6 changes)
cd /root
git clone https://github.com/robpitman1982-ux/python-master-strategy-creator.git
cd python-master-strategy-creator
bash setup_server.sh

# Upload all 4 data files
# (from local machine)
scp Data/ES_daily_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
scp Data/ES_60m_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
scp Data/ES_30m_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/
scp Data/ES_15m_2008_2026_tradestation.csv root@<IP>:/root/python-master-strategy-creator/Data/

# Run with 48-core config
bash run_engine.sh --config cloud/config_es_all_timeframes_48core.yaml

# Disconnect — it runs under nohup
# Check back in ~7 hours
```

### 5. Download results and destroy
```bash
scp -r root@<IP>:/root/python-master-strategy-creator/Outputs cloud_outputs_48core
# Check Outputs/master_leaderboard.csv — this is the money file
# Destroy the droplet
```

---

## Summary of deliverables

| # | File | What |
|---|------|------|
| 1 | Strategy type modules (all 3) | Hybrid filter scaling — scaled SMA/lookback params |
| 2 | `base_strategy_type.py` | Timeframe-aware `get_required_*` methods |
| 3 | `master_strategy_engine.py` | Thread timeframe into feature precomputation + auto master leaderboard |
| 4 | `config_loader.py` | `scale_lookbacks()` utility |
| 5 | `cloud/config_es_all_timeframes_48core.yaml` | 4-dataset, 46-worker config |
| 6 | `docs/TRADESTATION_EXPORT_GUIDE.md` | Data export instructions |
| 7 | `CLOUD_DEPLOYMENT_RUNBOOK.md` | Updated with 48-core section |
| 8 | `run_cloud_job.py` | `--size` CLI argument |
| 9 | `master_strategy_engine.py` | Memory estimation + auto-throttle |
| 10 | `tests/test_smoke.py` | New hybrid scaling test |
| 11 | `CLAUDE.md` | Updated issues + structure |
| 12 | `CHANGELOG_DEV.md` | Session 6 entry |
