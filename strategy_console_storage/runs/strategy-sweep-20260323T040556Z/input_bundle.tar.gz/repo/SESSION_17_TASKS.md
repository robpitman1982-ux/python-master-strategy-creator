Session 17 – Restore strategy-console service infrastructure

The following files were intended to be added in Session 16 but are not present in the repository:

strategy-dashboard.service
scripts/start_dashboard.sh
scripts/update_console.sh

Tasks:

1. Recreate the missing files.

scripts/start_dashboard.sh
Purpose:
Start the Streamlit dashboard in the repo venv.

Contents:

#!/usr/bin/env bash
set -e
cd ~/python-master-strategy-creator
source venv/bin/activate
streamlit run dashboard.py --server.port 8501

scripts/update_console.sh
Purpose:
Update repo and restart dashboard service.

Contents:

#!/usr/bin/env bash
set -e
cd ~/python-master-strategy-creator
git pull origin main
sudo systemctl restart strategy-dashboard

strategy-dashboard.service

[Unit]
Description=Strategy Engine Dashboard
After=network.target

[Service]
User=robpitman1982
WorkingDirectory=/home/robpitman1982/python-master-strategy-creator
ExecStart=/home/robpitman1982/python-master-strategy-creator/scripts/start_dashboard.sh
Restart=always

[Install]
WantedBy=multi-user.target

2. Ensure these files are tracked by git.

3. Commit them with message:

feat: add strategy-console dashboard system service and deploy scripts

4. Push to main.

Do not modify other files.


Task 1 — Strengthen Terminal Run State Model

Audit and simplify the final run outcome model in:

cloud/launch_gcp_run.py

Ensure the launcher ends with a single authoritative final state.

Make terminal states obvious and mutually exclusive.

Suggested categories:

run_completed_verified
run_completed_unverified
artifact_download_failed
artifact_verification_failed
remote_run_failed
remote_monitor_failed
vm_missing_before_retrieval
unexpected_launcher_failure
dry_run_complete

And VM outcomes:

vm_destroyed
vm_preserved_for_inspection
vm_already_gone
not_created

Acceptance criteria:

There must be no terminal run where:

run_outcome is missing
vm_outcome is missing
destroy status is unclear
Task 2 — Add Explicit Destroy Decision Report

Create a structured helper function in launcher:

build_destroy_decision(...)

It should return:

destroy_allowed
destroy_reason
instance_exists_at_end
billing_should_be_stopped
operator_action

Examples:

Verified success
destroy_allowed = True
destroy_reason = "verified success with local artifacts present"
billing_should_be_stopped = True
operator_action = "none"
Unverified artifacts
destroy_allowed = False
destroy_reason = "artifact verification did not pass"
billing_should_be_stopped = False
operator_action = "inspect VM and download artifacts manually"
VM already missing
destroy_allowed = False
destroy_reason = "instance already gone"
billing_should_be_stopped = True
operator_action = "check local artifacts only"

Print this clearly at the end.

Task 3 — Add Final Retrieval Attempt Before Preserve

Before deciding to preserve a VM after a completed or failed run, add one final best-effort retrieval attempt.

Use case:

Sometimes the first download/verification path may fail transiently even though the artifact tarball exists remotely.

Add logic:

if run finished
and artifact tarball exists remotely
and local verification failed
then retry one final download + extraction + verification
before preserving VM

This should reduce unnecessary preserved VMs.

Acceptance criteria:

Launcher attempts one explicit final artifact retrieval before preserve decision.

Task 4 — Add Manual Recovery Instructions to Final Summary

At the end of the launcher, if VM is preserved, print exact next-step commands.

Examples:

If VM preserved and artifact tarball exists
Recovery options:
1. SSH into VM
2. Inspect remote status file
3. Pull preserved artifact tarball
4. Delete VM when safe
Print command templates

Examples should include:

gcloud compute ssh ...
gcloud compute scp ...
gcloud compute instances delete ...

These should be generated dynamically using:

instance name
zone
remote tarball path
local results dir

This makes failed runs recoverable without guesswork.

Task 5 — Add “Billing Stopped” Logic To Dashboard

Update dashboard so it shows a more accurate billing state.

Current dashboard logic is too simple.

Add a clearer derived field:

Billing Status:
- stopped
- maybe_stopped
- still_running
- unknown

Suggested logic:

stopped
vm_outcome == vm_destroyed
OR instance_exists_at_end == False
still_running
vm_outcome == vm_preserved_for_inspection
AND instance_exists_at_end == True
maybe_stopped
launcher says already gone but artifact verification incomplete

Display prominently.

Task 6 — Add Dashboard “Operator Actions” Panel

In dashboard.py, add a visible section:

Operator Actions

Show dynamic suggestions based on latest run state.

Examples:

Verified run
Latest run is verified.
No manual action required.
VM preserved
VM is still running.
Download artifacts or inspect remotely, then delete the instance.
Artifact failure
Artifacts are incomplete locally.
Use recovery commands below.

If possible, show the exact command strings generated by launcher.

Task 7 — Persist Recovery Metadata In launcher_status.json

Add fields to launcher status JSON:

destroy_reason
billing_should_be_stopped
operator_action
recovery_commands
remote_artifact_exists
final_retrieval_attempted
final_retrieval_success

This ensures the dashboard can surface them cleanly.

Task 8 — Improve Logging Around Cleanup Phase

The cleanup phase should be visibly staged.

Add explicit stages like:

artifact_download
artifact_verification
destroy_guard_check
destroy
destroy_skipped
destroy_failed
destroyed

This will make it much easier to understand exactly where teardown failed.

Task 9 — Add Tests For Destroy Guard / Final Outcomes

Add targeted tests for the cleanup decision model.

Suggested tests:

verified success → destroy allowed
verified success + keep-vm → preserve
artifacts missing → preserve
instance already gone → vm_already_gone
remote completed but first retrieval failed and second succeeded → destroy allowed
remote failed with artifact tarball present → preserve with recovery commands

These do not need to be huge end-to-end tests.
Unit tests for the decision logic are enough.

Files Likely To Change

Primary:

cloud/launch_gcp_run.py
dashboard.py

Possibly:

dashboard_utils.py
tests/
Acceptance Criteria

After Session 17:

1️⃣ Every run ends with explicit run_outcome and vm_outcome
2️⃣ Final summary states whether billing is likely stopped
3️⃣ Launcher retries one final artifact retrieval before preserve decision
4️⃣ Preserved VMs include exact recovery commands
5️⃣ Dashboard shows billing status and operator actions
6️⃣ Destroy guard logic has focused tests

Out of Scope

Not for Session 17:

• multi-worker sharding
• queue system
• controller-triggered fleet orchestration
• auto region hunting

Those are later sessions.

Operator Goal After Session 17

At the end of any cloud run, the user should be able to answer instantly:

Did the run succeed?
Are the outputs safe locally?
Is the VM gone?
If not, exactly what should I do next?

without reading raw logs.

End of Session 17 Tasks