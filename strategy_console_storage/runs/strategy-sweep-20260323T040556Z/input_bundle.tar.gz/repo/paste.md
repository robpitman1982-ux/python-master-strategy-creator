## File Tree @ 3/13/2026, 1:03:30 PM
```
└── modules/
    ├── data_loader.py
    ├── engine.py
    ├── feature_builder.py
    ├── filter_combinator.py
    ├── filters.py
    ├── heatmap.py
    ├── optimizer.py
    ├── plateau_analyzer.py
    ├── portfolio_evaluator.py
    ├── refiner.py
    ├── strategies.py
    └── strategy_types/
        ├── __init__.py
        ├── base_strategy_type.py
        ├── breakout_strategy_type.py
        ├── mean_reversion_strategy_type.py
        ├── strategy_factory.py
        └── trend_strategy_type.py
```

## File Analysis @ 3/13/2026, 1:03:30 PM
- Total files: 17
- .py: 17


---
#### modules/strategy_types/__init__.py @ 3/13/2026, 1:03:30 PM
```python
from modules.strategy_types.base_strategy_type import BaseStrategyType
from modules.strategy_types.breakout_strategy_type import BreakoutStrategyType
from modules.strategy_types.mean_reversion_strategy_type import MeanReversionStrategyType
from modules.strategy_types.strategy_factory import get_strategy_type, list_strategy_types
from modules.strategy_types.trend_strategy_type import TrendStrategyType

__all__ = [
    "BaseStrategyType",
    "TrendStrategyType",
    "BreakoutStrategyType",
    "MeanReversionStrategyType",
    "get_strategy_type",
    "list_strategy_types",
]
```

---
#### modules/strategy_types/trend_strategy_type.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

import pandas as pd

from modules.engine import EngineConfig, MasterStrategyEngine
from modules.filter_combinator import build_filter_combo_name, generate_filter_combinations
from modules.filters import (
    BaseFilter,
    AboveFastSMAFilter,
    AboveLongTermSMAFilter,
    UpCloseFilter,
    TwoBarUpFilter,
    HighVolatilityRegimeFilter,
    MomentumFilter
)
from modules.plateau_analyzer import PlateauAnalyzer
from modules.refiner import StrategyParameterRefiner
from modules.strategy_types.base_strategy_type import BaseStrategyType

# =============================================================================
# INLINE TREND STRATEGY
# =============================================================================
class _InlineTrendStrategy:
    direction = "LONG_ONLY"

    def __init__(
        self,
        filters: list[BaseFilter],
        hold_bars: int = 10,
        stop_distance_points: float = 10.0,
        name: str | None = None,
    ):
        self.filters = filters
        self.hold_bars = hold_bars
        self.stop_distance_points = stop_distance_points
        self.name = name or f"ComboTrend_{build_filter_combo_name(filters)}"

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        for filter_obj in self.filters:
            if not filter_obj.passes(data, i):
                return 0
        return 1

# =============================================================================
# RUNNER HELPERS FOR MULTIPROCESSING
# =============================================================================
def _run_trend_combo_case(task: tuple[pd.DataFrame, EngineConfig, list[type]]) -> dict[str, Any]:
    data, cfg, combo_classes = task

    strategy_type = TrendStrategyType()
    filter_objects = strategy_type.build_filter_objects_from_classes(combo_classes)
    
    strategy = strategy_type.build_combinable_strategy(
        filters=filter_objects,
        hold_bars=strategy_type.default_hold_bars,
        stop_distance_points=strategy_type.default_stop_distance_points,
    )

    engine = MasterStrategyEngine(data=data, config=cfg)
    engine.run(strategy=strategy)
    summary = engine.results()

    total_trades = int(str(summary.get("Total Trades", 0)).replace(",", ""))
    years_in_sample = (data.index.max() - data.index.min()).days / 365.25
    trades_per_year = total_trades / years_in_sample if years_in_sample > 0 else 0.0

    thresholds = strategy_type.get_trade_filter_thresholds()
    passes_trade_filter = (
        total_trades >= thresholds["min_trades"]
        and trades_per_year >= thresholds["min_trades_per_year"]
    )

    def _parse_float(val: Any) -> float:
        return float(str(val).replace("$", "").replace(",", "").replace("%", "").strip() or 0.0)

    return {
        "strategy_name": str(summary.get("Strategy", "UnknownStrategy")),
        "filter_count": len(filter_objects),
        "filters": ",".join([f.name for f in filter_objects]),
        "total_trades": total_trades,
        "trades_per_year": round(trades_per_year, 2),
        "passes_trade_filter": passes_trade_filter,
        "net_pnl": _parse_float(summary.get("Net PnL", 0.0)),
        "gross_profit": _parse_float(summary.get("Gross Profit", 0.0)),
        "gross_loss": _parse_float(summary.get("Gross Loss", 0.0)),
        "average_trade": _parse_float(summary.get("Average Trade", 0.0)),
        "profit_factor": _parse_float(summary.get("Profit Factor", 0.0)),
        "max_drawdown": _parse_float(summary.get("Max Drawdown", 0.0)),
        "win_rate": _parse_float(summary.get("Win Rate", 0.0)),
        "avg_mae_pts": _parse_float(summary.get("Average MAE (pts)", 0.0)),
        "avg_mfe_pts": _parse_float(summary.get("Average MFE (pts)", 0.0)),
    }

class _TrendRefinementFactory:
    def __init__(self, strategy_type_instance, promoted_combo_classes):
        self.strategy_type_instance = strategy_type_instance
        self.promoted_combo_classes = promoted_combo_classes

    def __call__(
        self,
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ):
        return self.strategy_type_instance.build_candidate_specific_strategy(
            promoted_combo_classes=self.promoted_combo_classes,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
            min_avg_range=min_avg_range,
            momentum_lookback=momentum_lookback,
        )

# =============================================================================
# TREND STRATEGY TYPE
# =============================================================================
class TrendStrategyType(BaseStrategyType):
    name = "trend"

    min_filters_per_combo = 3
    max_filters_per_combo = 5 # Reduced slightly from 7 for faster discovery

    default_hold_bars = 10
    default_stop_distance_points = 10.0

    def get_required_sma_lengths(self) -> list[int]:
        return [20, 50, 200]

    def get_required_avg_range_lookbacks(self) -> list[int]:
        return [20]

    def get_required_momentum_lookbacks(self) -> list[int]:
        return [14]

    def build_default_sanity_filters(self) -> list[BaseFilter]:
        return [
            AboveLongTermSMAFilter(slow_length=200),
            UpCloseFilter(),
            AboveFastSMAFilter(fast_length=20)
        ]

    def build_default_strategy(self) -> _InlineTrendStrategy:
        return _InlineTrendStrategy(
            filters=self.build_default_sanity_filters(),
            hold_bars=self.default_hold_bars,
            stop_distance_points=self.default_stop_distance_points,
            name="FilterBasedTrendStrategy",
        )

    def build_sanity_check_strategy(self) -> _InlineTrendStrategy:
        return self.build_default_strategy()

    def get_filter_classes(self) -> list[type]:
        # Explicit list ensures combinations are generated correctly
        return [
            AboveFastSMAFilter,
            AboveLongTermSMAFilter,
            UpCloseFilter,
            TwoBarUpFilter,
            HighVolatilityRegimeFilter,
            MomentumFilter
        ]

    def build_filter_objects_from_classes(self, combo_classes: list[type]) -> list[BaseFilter]:
        filter_objects: list[BaseFilter] = []
        for cls in combo_classes:
            if cls is AboveFastSMAFilter:
                filter_objects.append(cls(fast_length=20))
            elif cls is AboveLongTermSMAFilter:
                filter_objects.append(cls(slow_length=200))
            elif cls is HighVolatilityRegimeFilter:
                filter_objects.append(cls(lookback=20, min_avg_range=8.0))
            elif cls is MomentumFilter:
                filter_objects.append(cls(lookback=14))
            else:
                filter_objects.append(cls())
        return filter_objects

    def build_combinable_strategy(
        self,
        filters: list[BaseFilter],
        hold_bars: int,
        stop_distance_points: float,
    ) -> _InlineTrendStrategy:
        return _InlineTrendStrategy(
            filters=filters,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
        )

    def build_candidate_specific_strategy(
        self,
        promoted_combo_classes: list[type],
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ) -> _InlineTrendStrategy:
        
        filters: list[BaseFilter] = []
        for cls in promoted_combo_classes:
            if cls is AboveFastSMAFilter:
                filters.append(cls(fast_length=20))
            elif cls is AboveLongTermSMAFilter:
                filters.append(cls(slow_length=200))
            elif cls is HighVolatilityRegimeFilter:
                range_val = float(min_avg_range) if min_avg_range > 0 else 8.0
                filters.append(cls(lookback=20, min_avg_range=range_val))
            elif cls is MomentumFilter:
                mom_val = int(momentum_lookback) if momentum_lookback > 0 else 14
                filters.append(cls(lookback=mom_val))
            else:
                filters.append(cls())

        return _InlineTrendStrategy(
            filters=filters,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
            name=(
                f"RefinedTrendStrategy_"
                f"HB{hold_bars}_STOP{stop_distance_points}_"
                f"RANGE{min_avg_range}_MOM{momentum_lookback}"
            ),
        )

    def get_promotion_thresholds(self) -> dict[str, float | bool]:
        return {
            "min_profit_factor": 1.00,
            "min_average_trade": 0.0,
            "require_positive_net_pnl": False,
            "min_trades": 75,
            "min_trades_per_year": 4.0,   
        }

    def get_promotion_gate_config(self) -> dict[str, float | bool]:
        return self.get_promotion_thresholds()

    def get_trade_filter_thresholds(self) -> dict[str, float]:
        return {
            "min_trades": 120,            # Slightly lowered from 150 to allow more trend winners
            "min_trades_per_year": 6.0,
        }

    def get_trade_filter_config(self) -> dict[str, float]:
        return self.get_trade_filter_thresholds()

    def get_active_refinement_grid_for_combo(
        self,
        promoted_combo_classes: list[type],
    ) -> dict[str, list]:
        grid: dict[str, list] = {
            "hold_bars": [4, 6, 8, 10, 12],
            "stop_distance_points": [8.0, 10.0, 12.0, 14.0],
        }

        has_vol = any(cls is HighVolatilityRegimeFilter for cls in promoted_combo_classes)
        grid["min_avg_range"] = [8.0, 10.0, 12.0, 14.0] if has_vol else [0.0]

        has_mom = any(cls is MomentumFilter for cls in promoted_combo_classes)
        grid["momentum_lookback"] = [10, 14, 20] if has_mom else [0]
        
        return grid

    def get_refinement_grid_for_candidate(
        self, 
        candidate_row: dict[str, Any]
    ) -> dict[str, list]:
        promoted_combo_classes = candidate_row.get("filter_classes", [])
        return self.get_active_refinement_grid_for_combo(promoted_combo_classes)

    def run_family_filter_combination_sweep(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        max_workers: int = 10,
    ) -> pd.DataFrame:
        filter_classes = self.get_filter_classes()
        combinations = generate_filter_combinations(
            filter_classes=filter_classes,
            min_filters=self.min_filters_per_combo,
            max_filters=self.max_filters_per_combo,
        )

        print(f"\n Running {self.name} filter combination sweep...")
        print(f"Total filter combinations: {len(combinations)}")
        print(f"Parallel mode: ON | max_workers={max_workers}")

        tasks = [(data, cfg, combo_classes) for combo_classes in combinations]
        results: list[dict[str, Any]] = []

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            for idx, result in enumerate(executor.map(_run_trend_combo_case, tasks), start=1):
                print(f"  Combo {idx}/{len(combinations)} | {result['strategy_name']}")
                result["filter_classes"] = combinations[idx - 1]
                results.append(result)

        results_df = pd.DataFrame(results)
        if not results_df.empty:
            results_df = results_df.sort_values(
                by=["passes_trade_filter", "net_pnl", "profit_factor", "total_trades"],
                ascending=[False, False, False, False],
            ).reset_index(drop=True)

        return results_df

    def run_top_combo_refinement(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        candidate_row: dict[str, Any],
        output_dir: str | Path = "Outputs",
        max_workers: int = 10,
    ) -> pd.DataFrame:
        promoted_combo_classes = candidate_row.get("filter_classes", [])
        grid = self.get_active_refinement_grid_for_combo(promoted_combo_classes)
        trade_filters = self.get_trade_filter_thresholds()

        strategy_factory = _TrendRefinementFactory(self, promoted_combo_classes)

        refiner = StrategyParameterRefiner(
            engine_class=MasterStrategyEngine,
            data=data,
            strategy_factory=strategy_factory,
            config=cfg,
        )

        print("\n Running top-combo parameter refinement...")
        refinement_df = refiner.run_refinement(
            hold_bars=grid["hold_bars"],
            stop_distance_points=grid["stop_distance_points"],
            min_avg_range=grid["min_avg_range"],
            momentum_lookback=grid["momentum_lookback"],
            min_trades=trade_filters["min_trades"],
            min_trades_per_year=trade_filters["min_trades_per_year"],
            parallel=True,
            max_workers=max_workers,
        )

        if not refinement_df.empty:
            print(f"\n Top {self.name} Refinement Results:")
            print(refiner.top_results(10))
            refiner.print_summary_report(top_n=10)

            plateau = PlateauAnalyzer(refinement_df)
            plateau.print_report(top_n=10)

            output_path = Path(output_dir) / f"{self.name}_top_combo_refinement_results_narrow.csv"
            saved_path = refiner.save_results_csv(output_path)
            print(f"\n Narrow top-combo refinement saved to: {saved_path}")
        else:
            print("\nNo refinement results met the trade filters.")

        return refinement_df
```

---
#### modules/strategy_types/strategy_factory.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from modules.strategy_types.base_strategy_type import BaseStrategyType
from modules.strategy_types.breakout_strategy_type import BreakoutStrategyType
from modules.strategy_types.mean_reversion_strategy_type import MeanReversionStrategyType
from modules.strategy_types.trend_strategy_type import TrendStrategyType


def get_strategy_type(name: str) -> BaseStrategyType:
    """
    Factory function returning a strategy type instance by name.

    Current supported strategy types:
    - trend
    - breakout
    - mean_reversion
    """

    normalized = name.strip().lower()

    if normalized == "trend":
        return TrendStrategyType()

    if normalized == "breakout":
        return BreakoutStrategyType()

    if normalized == "mean_reversion":
        return MeanReversionStrategyType()

    raise ValueError(
        f"Unknown strategy type: '{name}'. "
        f"Supported types: ['trend', 'breakout', 'mean_reversion']"
    )


def list_strategy_types() -> list[str]:
    """
    Returns the currently available strategy type names.
    """
    return ["trend", "breakout", "mean_reversion"]
```

---
#### modules/strategy_types/mean_reversion_strategy_type.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

import pandas as pd

from modules.engine import EngineConfig, MasterStrategyEngine
from modules.filter_combinator import build_filter_combo_name, generate_filter_combinations
from modules.filters import (
    AboveLongTermSMAFilter,
    BaseFilter,
    BelowFastSMAFilter,
    DistanceBelowSMAFilter,
    DownCloseFilter,
    LowVolatilityRegimeFilter,
    ReversalUpBarFilter,
    TwoBarDownFilter,
)
from modules.plateau_analyzer import PlateauAnalyzer
from modules.refiner import StrategyParameterRefiner
from modules.strategy_types.base_strategy_type import BaseStrategyType

# =============================================================================
# INLINE MEAN REVERSION STRATEGY
# =============================================================================
class _InlineMeanReversionStrategy:
    direction = "LONG_ONLY"

    def __init__(
        self,
        filters: list[BaseFilter],
        hold_bars: int = 4,
        stop_distance_points: float = 8.0,
        name: str | None = None,
    ):
        self.filters = filters
        self.hold_bars = hold_bars
        self.stop_distance_points = stop_distance_points
        self.name = name or f"ComboMeanReversion_{build_filter_combo_name(filters)}"

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        for filter_obj in self.filters:
            if not filter_obj.passes(data, i):
                return 0
        return 1

# =============================================================================
# RUNNER HELPERS FOR MULTIPROCESSING
# =============================================================================
def _run_mean_reversion_combo_case(task: tuple[pd.DataFrame, EngineConfig, list[type]]) -> dict[str, Any]:
    data, cfg, combo_classes = task

    strategy_type = MeanReversionStrategyType()
    filter_objects = strategy_type.build_filter_objects_from_classes(combo_classes)
    
    strategy = strategy_type.build_combinable_strategy(
        filters=filter_objects,
        hold_bars=strategy_type.default_hold_bars,
        stop_distance_points=strategy_type.default_stop_distance_points,
    )

    engine = MasterStrategyEngine(data=data, config=cfg)
    engine.run(strategy=strategy)
    summary = engine.results()

    total_trades = int(str(summary.get("Total Trades", 0)).replace(",", ""))
    years_in_sample = (data.index.max() - data.index.min()).days / 365.25
    trades_per_year = total_trades / years_in_sample if years_in_sample > 0 else 0.0

    thresholds = strategy_type.get_trade_filter_thresholds()
    passes_trade_filter = (
        total_trades >= thresholds["min_trades"]
        and trades_per_year >= thresholds["min_trades_per_year"]
    )

    def _parse_float(val: Any) -> float:
        return float(str(val).replace("$", "").replace(",", "").replace("%", "").strip() or 0.0)

    return {
        "strategy_name": str(summary.get("Strategy", "UnknownStrategy")),
        "filter_count": len(filter_objects),
        "filters": ",".join([f.name for f in filter_objects]),
        "total_trades": total_trades,
        "trades_per_year": round(trades_per_year, 2),
        "passes_trade_filter": passes_trade_filter,
        "net_pnl": _parse_float(summary.get("Net PnL", 0.0)),
        "gross_profit": _parse_float(summary.get("Gross Profit", 0.0)),
        "gross_loss": _parse_float(summary.get("Gross Loss", 0.0)),
        "average_trade": _parse_float(summary.get("Average Trade", 0.0)),
        "profit_factor": _parse_float(summary.get("Profit Factor", 0.0)),
        "max_drawdown": _parse_float(summary.get("Max Drawdown", 0.0)),
        "win_rate": _parse_float(summary.get("Win Rate", 0.0)),
        "avg_mae_pts": _parse_float(summary.get("Average MAE (pts)", 0.0)),
        "avg_mfe_pts": _parse_float(summary.get("Average MFE (pts)", 0.0)),
    }

class _MeanReversionRefinementFactory:
    """Top-level picklable factory for the ProcessPoolExecutor."""
    def __init__(self, strategy_type_instance, promoted_combo_classes):
        self.strategy_type_instance = strategy_type_instance
        self.promoted_combo_classes = promoted_combo_classes

    def __call__(
        self,
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ):
        return self.strategy_type_instance.build_candidate_specific_strategy(
            promoted_combo_classes=self.promoted_combo_classes,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
            min_avg_range=min_avg_range,
            momentum_lookback=momentum_lookback,
        )

# =============================================================================
# MEAN REVERSION STRATEGY TYPE
# =============================================================================
class MeanReversionStrategyType(BaseStrategyType):
    name = "mean_reversion"

    min_filters_per_combo = 3
    max_filters_per_combo = 7

    default_hold_bars = 4
    default_stop_distance_points = 8.0

    def get_required_sma_lengths(self) -> list[int]:
        return [20, 200]

    def get_required_avg_range_lookbacks(self) -> list[int]:
        return [20]

    def get_required_momentum_lookbacks(self) -> list[int]:
        return []

    def build_default_sanity_filters(self) -> list[BaseFilter]:
        return [
            BelowFastSMAFilter(fast_length=20),
            DistanceBelowSMAFilter(fast_length=20, min_distance_points=8.0),
            DownCloseFilter(),
            TwoBarDownFilter(),
            ReversalUpBarFilter(),
            LowVolatilityRegimeFilter(lookback=20, max_avg_range=12.0),
            AboveLongTermSMAFilter(slow_length=200),
        ]

    def build_default_strategy(self) -> _InlineMeanReversionStrategy:
        return _InlineMeanReversionStrategy(
            filters=self.build_default_sanity_filters(),
            hold_bars=self.default_hold_bars,
            stop_distance_points=self.default_stop_distance_points,
            name="FilterBasedMeanReversionStrategy",
        )

    def build_sanity_check_strategy(self) -> _InlineMeanReversionStrategy:
        return self.build_default_strategy()

    def get_filter_classes(self) -> list[type]:
        return [
            BelowFastSMAFilter,
            DistanceBelowSMAFilter,
            DownCloseFilter,
            TwoBarDownFilter,
            ReversalUpBarFilter,
            LowVolatilityRegimeFilter,
            AboveLongTermSMAFilter,
        ]

    def build_filter_objects_from_classes(self, combo_classes: list[type]) -> list[BaseFilter]:
        filter_objects: list[BaseFilter] = []
        for cls in combo_classes:
            if cls is BelowFastSMAFilter:
                filter_objects.append(cls(fast_length=20))
            elif cls is DistanceBelowSMAFilter:
                filter_objects.append(cls(fast_length=20, min_distance_points=8.0))
            elif cls is DownCloseFilter:
                filter_objects.append(cls())
            elif cls is TwoBarDownFilter:
                filter_objects.append(cls())
            elif cls is ReversalUpBarFilter:
                filter_objects.append(cls())
            elif cls is LowVolatilityRegimeFilter:
                filter_objects.append(cls(lookback=20, max_avg_range=12.0))
            elif cls is AboveLongTermSMAFilter:
                filter_objects.append(cls(slow_length=200))
            else:
                filter_objects.append(cls())
        return filter_objects

    def build_combinable_strategy(
        self,
        filters: list[BaseFilter],
        hold_bars: int,
        stop_distance_points: float,
    ) -> _InlineMeanReversionStrategy:
        return _InlineMeanReversionStrategy(
            filters=filters,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
        )

    def build_candidate_specific_strategy(
        self,
        promoted_combo_classes: list[type],
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ) -> _InlineMeanReversionStrategy:
        
        filters: list[BaseFilter] = []
        for cls in promoted_combo_classes:
            if cls is BelowFastSMAFilter:
                filters.append(BelowFastSMAFilter(fast_length=20))
            elif cls is DistanceBelowSMAFilter:
                distance_points = float(min_avg_range) if min_avg_range > 0 else 8.0
                filters.append(DistanceBelowSMAFilter(fast_length=20, min_distance_points=distance_points))
            elif cls is DownCloseFilter:
                filters.append(DownCloseFilter())
            elif cls is TwoBarDownFilter:
                filters.append(TwoBarDownFilter())
            elif cls is ReversalUpBarFilter:
                filters.append(ReversalUpBarFilter())
            elif cls is LowVolatilityRegimeFilter:
                max_range_val = float(min_avg_range) if min_avg_range > 0 else 12.0
                filters.append(LowVolatilityRegimeFilter(lookback=20, max_avg_range=max_range_val))
            elif cls is AboveLongTermSMAFilter:
                filters.append(AboveLongTermSMAFilter(slow_length=200))
            else:
                filters.append(cls())

        return _InlineMeanReversionStrategy(
            filters=filters,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
            name=(
                f"RefinedMeanReversionStrategy_"
                f"HB{hold_bars}_STOP{stop_distance_points}_"
                f"RANGE{min_avg_range}_MOM{momentum_lookback}"
            ),
        )

    def get_promotion_thresholds(self) -> dict[str, float | bool]:
        return {
            "min_profit_factor": 1.00,
            "min_average_trade": 0.0,
            "require_positive_net_pnl": False,
            "min_trades": 100,            # Set to 100 for the Sweep
            "min_trades_per_year": 5.0,   # Adjusted for 100 trades over ~18 years
        }

    def get_promotion_gate_config(self) -> dict[str, float | bool]:
        return self.get_promotion_thresholds()

    def get_trade_filter_thresholds(self) -> dict[str, float]:
        return {
            "min_trades": 100,            # Set to 100 for the Refinement Engine
            "min_trades_per_year": 5.0,
        }

    def get_trade_filter_config(self) -> dict[str, float]:
        return self.get_trade_filter_thresholds()

    def get_active_refinement_grid_for_combo(
        self,
        promoted_combo_classes: list[type],
    ) -> dict[str, list]:
        grid: dict[str, list] = {
            "hold_bars": [2, 3, 4, 5, 6],
            "stop_distance_points": [6.0, 8.0, 10.0, 12.0],
        }

        if (
            DistanceBelowSMAFilter in promoted_combo_classes
            or LowVolatilityRegimeFilter in promoted_combo_classes
        ):
            grid["min_avg_range"] = [8.0, 10.0, 12.0, 14.0]
        else:
            grid["min_avg_range"] = [0.0]

        grid["momentum_lookback"] = [0]
        return grid

    def get_refinement_grid_for_candidate(
        self, 
        candidate_row: dict[str, Any]
    ) -> dict[str, list]:
        promoted_combo_classes = candidate_row.get("filter_classes", [])
        return self.get_active_refinement_grid_for_combo(promoted_combo_classes)

    def run_family_filter_combination_sweep(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        max_workers: int = 10,
    ) -> pd.DataFrame:
        filter_classes = self.get_filter_classes()
        combinations = generate_filter_combinations(
            filter_classes=filter_classes,
            min_filters=self.min_filters_per_combo,
            max_filters=self.max_filters_per_combo,
        )

        print(f"\n Running {self.name} filter combination sweep...")
        print(f"Total filter combinations: {len(combinations)}")
        print(f"Parallel mode: ON | max_workers={max_workers}")

        tasks = [(data, cfg, combo_classes) for combo_classes in combinations]
        results: list[dict[str, Any]] = []

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            for idx, result in enumerate(executor.map(_run_mean_reversion_combo_case, tasks), start=1):
                print(f"  Combo {idx}/{len(combinations)} | {result['strategy_name']}")
                result["filter_classes"] = combinations[idx - 1]
                results.append(result)

        results_df = pd.DataFrame(results)
        if not results_df.empty:
            results_df = results_df.sort_values(
                by=["passes_trade_filter", "net_pnl", "profit_factor", "total_trades"],
                ascending=[False, False, False, False],
            ).reset_index(drop=True)

        return results_df

    def run_top_combo_refinement(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        candidate_row: dict[str, Any],
        output_dir: str | Path = "Outputs",
        max_workers: int = 10,
    ) -> pd.DataFrame:
        promoted_combo_classes = candidate_row.get("filter_classes", [])
        grid = self.get_active_refinement_grid_for_combo(promoted_combo_classes)
        trade_filters = self.get_trade_filter_thresholds()

        # Instantiate the picklable factory instead of a local function
        strategy_factory = _MeanReversionRefinementFactory(self, promoted_combo_classes)

        refiner = StrategyParameterRefiner(
            engine_class=MasterStrategyEngine,
            data=data,
            strategy_factory=strategy_factory,
            config=cfg,
        )

        print("\n Running top-combo parameter refinement...")
        refinement_df = refiner.run_refinement(
            hold_bars=grid["hold_bars"],
            stop_distance_points=grid["stop_distance_points"],
            min_avg_range=grid["min_avg_range"],
            momentum_lookback=grid["momentum_lookback"],
            min_trades=trade_filters["min_trades"],
            min_trades_per_year=trade_filters["min_trades_per_year"],
            parallel=True,
            max_workers=max_workers,
        )

        if not refinement_df.empty:
            print(f"\n Top {self.name} Refinement Results:")
            print(refiner.top_results(10))
            refiner.print_summary_report(top_n=10)

            plateau = PlateauAnalyzer(refinement_df)
            plateau.print_report(top_n=10)

            output_path = Path(output_dir) / f"{self.name}_top_combo_refinement_results_narrow.csv"
            saved_path = refiner.save_results_csv(output_path)
            print(f"\n Narrow top-combo refinement saved to: {saved_path}")
        else:
            print("\nNo refinement results met the trade filters.")

        return refinement_df
```

---
#### modules/strategy_types/breakout_strategy_type.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

import pandas as pd

from modules.engine import EngineConfig, MasterStrategyEngine
from modules.filter_combinator import build_filter_combo_name, generate_filter_combinations
from modules.filters import (
    BaseFilter,
    NewHighFilter,
    HighVolatilityRegimeFilter,
    AboveFastSMAFilter,
    UpCloseFilter,
    MomentumFilter,
    AboveLongTermSMAFilter
)
from modules.plateau_analyzer import PlateauAnalyzer
from modules.refiner import StrategyParameterRefiner
from modules.strategy_types.base_strategy_type import BaseStrategyType

# =============================================================================
# INLINE BREAKOUT STRATEGY
# =============================================================================
class _InlineBreakoutStrategy:
    direction = "LONG_ONLY"

    def __init__(
        self,
        filters: list[BaseFilter],
        hold_bars: int = 6,
        stop_distance_points: float = 12.0,
        name: str | None = None,
    ):
        self.filters = filters
        self.hold_bars = hold_bars
        self.stop_distance_points = stop_distance_points
        self.name = name or f"ComboBreakout_{build_filter_combo_name(filters)}"

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        for filter_obj in self.filters:
            if not filter_obj.passes(data, i):
                return 0
        return 1

# =============================================================================
# RUNNER HELPERS FOR MULTIPROCESSING
# =============================================================================
def _run_breakout_combo_case(task: tuple[pd.DataFrame, EngineConfig, list[type]]) -> dict[str, Any]:
    data, cfg, combo_classes = task

    strategy_type = BreakoutStrategyType()
    filter_objects = strategy_type.build_filter_objects_from_classes(combo_classes)
    
    strategy = strategy_type.build_combinable_strategy(
        filters=filter_objects,
        hold_bars=strategy_type.default_hold_bars,
        stop_distance_points=strategy_type.default_stop_distance_points,
    )

    engine = MasterStrategyEngine(data=data, config=cfg)
    engine.run(strategy=strategy)
    summary = engine.results()

    total_trades = int(str(summary.get("Total Trades", 0)).replace(",", ""))
    years_in_sample = (data.index.max() - data.index.min()).days / 365.25
    trades_per_year = total_trades / years_in_sample if years_in_sample > 0 else 0.0

    thresholds = strategy_type.get_trade_filter_thresholds()
    passes_trade_filter = (
        total_trades >= thresholds["min_trades"]
        and trades_per_year >= thresholds["min_trades_per_year"]
    )

    def _parse_float(val: Any) -> float:
        return float(str(val).replace("$", "").replace(",", "").replace("%", "").strip() or 0.0)

    return {
        "strategy_name": str(summary.get("Strategy", "UnknownStrategy")),
        "filter_count": len(filter_objects),
        "filters": ",".join([f.name for f in filter_objects]),
        "total_trades": total_trades,
        "trades_per_year": round(trades_per_year, 2),
        "passes_trade_filter": passes_trade_filter,
        "net_pnl": _parse_float(summary.get("Net PnL", 0.0)),
        "gross_profit": _parse_float(summary.get("Gross Profit", 0.0)),
        "gross_loss": _parse_float(summary.get("Gross Loss", 0.0)),
        "average_trade": _parse_float(summary.get("Average Trade", 0.0)),
        "profit_factor": _parse_float(summary.get("Profit Factor", 0.0)),
        "max_drawdown": _parse_float(summary.get("Max Drawdown", 0.0)),
        "win_rate": _parse_float(summary.get("Win Rate", 0.0)),
        "avg_mae_pts": _parse_float(summary.get("Average MAE (pts)", 0.0)),
        "avg_mfe_pts": _parse_float(summary.get("Average MFE (pts)", 0.0)),
    }

class _BreakoutRefinementFactory:
    def __init__(self, strategy_type_instance, promoted_combo_classes):
        self.strategy_type_instance = strategy_type_instance
        self.promoted_combo_classes = promoted_combo_classes

    def __call__(
        self,
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ):
        return self.strategy_type_instance.build_candidate_specific_strategy(
            promoted_combo_classes=self.promoted_combo_classes,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
            min_avg_range=min_avg_range,
            momentum_lookback=momentum_lookback,
        )

# =============================================================================
# BREAKOUT STRATEGY TYPE
# =============================================================================
class BreakoutStrategyType(BaseStrategyType):
    name = "breakout"

    min_filters_per_combo = 3
    max_filters_per_combo = 5 # Optimized for faster discovery

    default_hold_bars = 6
    default_stop_distance_points = 12.0

    def get_required_sma_lengths(self) -> list[int]:
        return [20, 200]

    def get_required_avg_range_lookbacks(self) -> list[int]:
        return [20]

    def get_required_momentum_lookbacks(self) -> list[int]:
        return [14]

    def build_default_sanity_filters(self) -> list[BaseFilter]:
        return [
            AboveLongTermSMAFilter(slow_length=200),
            NewHighFilter(lookback=20),
            AboveFastSMAFilter(fast_length=20)
        ]

    def build_default_strategy(self) -> _InlineBreakoutStrategy:
        return _InlineBreakoutStrategy(
            filters=self.build_default_sanity_filters(),
            hold_bars=self.default_hold_bars,
            stop_distance_points=self.default_stop_distance_points,
            name="FilterBasedBreakoutStrategy",
        )

    def build_sanity_check_strategy(self) -> _InlineBreakoutStrategy:
        return self.build_default_strategy()

    def get_filter_classes(self) -> list[type]:
        return [
            NewHighFilter,
            HighVolatilityRegimeFilter,
            AboveFastSMAFilter,
            AboveLongTermSMAFilter,
            UpCloseFilter,
            MomentumFilter
        ]

    def build_filter_objects_from_classes(self, combo_classes: list[type]) -> list[BaseFilter]:
        filter_objects: list[BaseFilter] = []
        for cls in combo_classes:
            if cls is AboveFastSMAFilter:
                filter_objects.append(cls(fast_length=20))
            elif cls is AboveLongTermSMAFilter:
                filter_objects.append(cls(slow_length=200))
            elif cls is HighVolatilityRegimeFilter:
                filter_objects.append(cls(lookback=20, min_avg_range=10.0))
            elif cls is NewHighFilter:
                filter_objects.append(cls(lookback=20))
            elif cls is MomentumFilter:
                filter_objects.append(cls(lookback=14))
            else:
                filter_objects.append(cls())
        return filter_objects

    def build_combinable_strategy(
        self,
        filters: list[BaseFilter],
        hold_bars: int,
        stop_distance_points: float,
    ) -> _InlineBreakoutStrategy:
        return _InlineBreakoutStrategy(
            filters=filters,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
        )

    def build_candidate_specific_strategy(
        self,
        promoted_combo_classes: list[type],
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ) -> _InlineBreakoutStrategy:
        
        filters: list[BaseFilter] = []
        for cls in promoted_combo_classes:
            if cls is AboveFastSMAFilter:
                filters.append(cls(fast_length=20))
            elif cls is AboveLongTermSMAFilter:
                filters.append(cls(slow_length=200))
            elif cls is HighVolatilityRegimeFilter:
                range_val = float(min_avg_range) if min_avg_range > 0 else 10.0
                filters.append(cls(lookback=20, min_avg_range=range_val))
            elif cls is NewHighFilter:
                filters.append(cls(lookback=20))
            elif cls is MomentumFilter:
                mom_val = int(momentum_lookback) if momentum_lookback > 0 else 14
                filters.append(cls(lookback=mom_val))
            else:
                filters.append(cls())

        return _InlineBreakoutStrategy(
            filters=filters,
            hold_bars=hold_bars,
            stop_distance_points=stop_distance_points,
            name=(
                f"RefinedBreakoutStrategy_"
                f"HB{hold_bars}_STOP{stop_distance_points}_"
                f"RANGE{min_avg_range}_MOM{momentum_lookback}"
            ),
        )

    def get_promotion_thresholds(self) -> dict[str, float | bool]:
        return {
            "min_profit_factor": 1.00,
            "min_average_trade": 0.0,
            "require_positive_net_pnl": False,
            "min_trades": 75,
            "min_trades_per_year": 4.0,   
        }

    def get_promotion_gate_config(self) -> dict[str, float | bool]:
        return self.get_promotion_thresholds()

    def get_trade_filter_thresholds(self) -> dict[str, float]:
        return {
            "min_trades": 120, # Set to 120 for consistency with Trend
            "min_trades_per_year": 6.0,
        }

    def get_trade_filter_config(self) -> dict[str, float]:
        return self.get_trade_filter_thresholds()

    def get_active_refinement_grid_for_combo(
        self,
        promoted_combo_classes: list[type],
    ) -> dict[str, list]:
        grid: dict[str, list] = {
            "hold_bars": [2, 4, 6, 8, 10],
            "stop_distance_points": [10.0, 12.0, 14.0, 16.0],
        }

        has_vol = any(cls is HighVolatilityRegimeFilter for cls in promoted_combo_classes)
        grid["min_avg_range"] = [10.0, 12.0, 14.0, 16.0] if has_vol else [0.0]

        has_mom = any(cls is MomentumFilter for cls in promoted_combo_classes)
        grid["momentum_lookback"] = [10, 14, 20] if has_mom else [0]
        
        return grid

    def get_refinement_grid_for_candidate(
        self, 
        candidate_row: dict[str, Any]
    ) -> dict[str, list]:
        promoted_combo_classes = candidate_row.get("filter_classes", [])
        return self.get_active_refinement_grid_for_combo(promoted_combo_classes)

    def run_family_filter_combination_sweep(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        max_workers: int = 10,
    ) -> pd.DataFrame:
        filter_classes = self.get_filter_classes()
        combinations = generate_filter_combinations(
            filter_classes=filter_classes,
            min_filters=self.min_filters_per_combo,
            max_filters=self.max_filters_per_combo,
        )

        print(f"\n Running {self.name} filter combination sweep...")
        print(f"Total filter combinations: {len(combinations)}")
        print(f"Parallel mode: ON | max_workers={max_workers}")

        tasks = [(data, cfg, combo_classes) for combo_classes in combinations]
        results: list[dict[str, Any]] = []

        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            for idx, result in enumerate(executor.map(_run_breakout_combo_case, tasks), start=1):
                print(f"  Combo {idx}/{len(combinations)} | {result['strategy_name']}")
                result["filter_classes"] = combinations[idx - 1]
                results.append(result)

        results_df = pd.DataFrame(results)
        if not results_df.empty:
            results_df = results_df.sort_values(
                by=["passes_trade_filter", "net_pnl", "profit_factor", "total_trades"],
                ascending=[False, False, False, False],
            ).reset_index(drop=True)

        return results_df

    def run_top_combo_refinement(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        candidate_row: dict[str, Any],
        output_dir: str | Path = "Outputs",
        max_workers: int = 10,
    ) -> pd.DataFrame:
        promoted_combo_classes = candidate_row.get("filter_classes", [])
        grid = self.get_active_refinement_grid_for_combo(promoted_combo_classes)
        trade_filters = self.get_trade_filter_thresholds()

        strategy_factory = _BreakoutRefinementFactory(self, promoted_combo_classes)

        refiner = StrategyParameterRefiner(
            engine_class=MasterStrategyEngine,
            data=data,
            strategy_factory=strategy_factory,
            config=cfg,
        )

        print("\n Running top-combo parameter refinement...")
        refinement_df = refiner.run_refinement(
            hold_bars=grid["hold_bars"],
            stop_distance_points=grid["stop_distance_points"],
            min_avg_range=grid["min_avg_range"],
            momentum_lookback=grid["momentum_lookback"],
            min_trades=trade_filters["min_trades"],
            min_trades_per_year=trade_filters["min_trades_per_year"],
            parallel=True,
            max_workers=max_workers,
        )

        if not refinement_df.empty:
            print(f"\n Top {self.name} Refinement Results:")
            print(refiner.top_results(10))
            refiner.print_summary_report(top_n=10)

            plateau = PlateauAnalyzer(refinement_df)
            plateau.print_report(top_n=10)

            output_path = Path(output_dir) / f"{self.name}_top_combo_refinement_results_narrow.csv"
            saved_path = refiner.save_results_csv(output_path)
            print(f"\n Narrow top-combo refinement saved to: {saved_path}")
        else:
            print("\nNo refinement results met the trade filters.")

        return refinement_df
```

---
#### modules/strategy_types/base_strategy_type.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import pandas as pd
from modules.engine import EngineConfig


class BaseStrategyType(ABC):
    """
    Base interface for all strategy families.
    Every strategy type must implement these methods so the master engine 
    can generically orchestrate sweeps and refinements across any family.
    """

    name: str = "base"

    min_filters_per_combo: int = 3
    max_filters_per_combo: int = 5

    default_hold_bars: int = 3
    default_stop_distance_points: float = 10.0

    @abstractmethod
    def get_filter_classes(self) -> list[type]:
        raise NotImplementedError

    @abstractmethod
    def build_filter_objects_from_classes(self, combo_classes: list[type]) -> list:
        raise NotImplementedError

    @abstractmethod
    def build_combinable_strategy(
        self,
        filters: list,
        hold_bars: int,
        stop_distance_points: float,
    ):
        raise NotImplementedError

    @abstractmethod
    def build_default_sanity_filters(self) -> list:
        raise NotImplementedError

    @abstractmethod
    def build_candidate_specific_strategy(
        self,
        promoted_combo_classes: list[type],
        hold_bars: int,
        stop_distance_points: float,
        min_avg_range: float,
        momentum_lookback: int,
    ):
        raise NotImplementedError

    @abstractmethod
    def get_active_refinement_grid_for_combo(
        self,
        promoted_combo_classes: list[type],
    ) -> dict[str, list]:
        raise NotImplementedError

    @abstractmethod
    def get_refinement_grid_for_candidate(
        self, 
        candidate_row: dict[str, Any]
    ) -> dict[str, list]:
        raise NotImplementedError

    @abstractmethod
    def get_trade_filter_thresholds(self) -> dict[str, float]:
        raise NotImplementedError

    @abstractmethod
    def get_trade_filter_config(self) -> dict[str, float]:
        raise NotImplementedError

    @abstractmethod
    def get_promotion_thresholds(self) -> dict[str, float | bool]:
        raise NotImplementedError

    @abstractmethod
    def get_promotion_gate_config(self) -> dict[str, float | bool]:
        raise NotImplementedError

    @abstractmethod
    def get_required_sma_lengths(self) -> list[int]:
        raise NotImplementedError

    @abstractmethod
    def get_required_avg_range_lookbacks(self) -> list[int]:
        raise NotImplementedError

    @abstractmethod
    def get_required_momentum_lookbacks(self) -> list[int]:
        raise NotImplementedError

    @abstractmethod
    def run_family_filter_combination_sweep(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        max_workers: int = 10,
    ) -> pd.DataFrame:
        raise NotImplementedError

    @abstractmethod
    def run_top_combo_refinement(
        self,
        data: pd.DataFrame,
        cfg: EngineConfig,
        candidate_row: dict[str, Any],
        output_dir: str | Path = "Outputs",
        max_workers: int = 10,
    ) -> pd.DataFrame:
        raise NotImplementedError
```

---
#### modules/strategies.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

import pandas as pd

from modules.filter_combinator import build_filter_combo_name
from modules.filters import (
    BaseFilter,
    MomentumFilter,
    PullbackFilter,
    RecoveryTriggerFilter,
    TrendDirectionFilter,
    VolatilityFilter,
)


class BaseStrategy(ABC):
    """
    Base class for all strategies.
    """

    name: str = "BaseStrategy"
    direction: str = "LONG_ONLY"
    hold_bars: int = 3
    stop_distance_points: float = 10.0

    @abstractmethod
    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        raise NotImplementedError


class TestStrategy(BaseStrategy):
    name = "TestStrategy"
    direction = "LONG_ONLY"
    hold_bars = 3
    stop_distance_points = 10.0

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        if i < 1:
            return 0

        current_close = data["close"].iloc[i]
        previous_close = data["close"].iloc[i - 1]

        if current_close > previous_close:
            return 1

        return 0


class FilterBasedTrendStrategy(BaseStrategy):
    """
    Fixed 5-filter trend strategy baseline.
    """

    name = "FilterBasedTrendStrategy"
    direction = "LONG_ONLY"
    hold_bars = 8
    stop_distance_points = 12.0

    def __init__(self):
        self.filters = [
            TrendDirectionFilter(fast_length=50, slow_length=200),
            PullbackFilter(fast_length=50),
            RecoveryTriggerFilter(fast_length=50),
            VolatilityFilter(lookback=20, min_avg_range=8.0),
            MomentumFilter(lookback=10),
        ]

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        for filter_obj in self.filters:
            if not filter_obj.passes(data, i):
                return 0
        return 1


class CombinableFilterTrendStrategy(BaseStrategy):
    """
    Trend strategy assembled from a chosen set of filters.
    """

    direction = "LONG_ONLY"
    hold_bars = 8
    stop_distance_points = 12.0

    def __init__(
        self,
        filters: list[BaseFilter],
        hold_bars: Optional[int] = None,
        stop_distance_points: Optional[float] = None,
    ):
        self.filters = filters

        if hold_bars is not None:
            self.hold_bars = hold_bars

        if stop_distance_points is not None:
            self.stop_distance_points = stop_distance_points

        self.name = f"ComboTrend_{build_filter_combo_name(filters)}"

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        for filter_obj in self.filters:
            if not filter_obj.passes(data, i):
                return 0
        return 1


class RefinedFiveFilterTrendStrategy(BaseStrategy):
    """
    Parameter-refinable version of the current best 5-filter trend stack.
    """

    direction = "LONG_ONLY"

    def __init__(
        self,
        hold_bars: int = 8,
        stop_distance_points: float = 12.0,
        fast_length: int = 50,
        slow_length: int = 200,
        volatility_lookback: int = 20,
        min_avg_range: float = 8.0,
        momentum_lookback: int = 10,
    ):
        self.hold_bars = hold_bars
        self.stop_distance_points = stop_distance_points
        self.fast_length = fast_length
        self.slow_length = slow_length
        self.volatility_lookback = volatility_lookback
        self.min_avg_range = min_avg_range
        self.momentum_lookback = momentum_lookback

        self.filters = [
            TrendDirectionFilter(fast_length=self.fast_length, slow_length=self.slow_length),
            PullbackFilter(fast_length=self.fast_length),
            RecoveryTriggerFilter(fast_length=self.fast_length),
            VolatilityFilter(
                lookback=self.volatility_lookback,
                min_avg_range=self.min_avg_range,
            ),
            MomentumFilter(lookback=self.momentum_lookback),
        ]

        self.name = (
            "RefinedFiveFilterTrendStrategy"
            f"_HB{self.hold_bars}"
            f"_STOP{self.stop_distance_points}"
            f"_RANGE{self.min_avg_range}"
            f"_MOM{self.momentum_lookback}"
        )

    def generate_signal(self, data: pd.DataFrame, i: int) -> int:
        for filter_obj in self.filters:
            if not filter_obj.passes(data, i):
                return 0
        return 1
```

---
#### modules/refiner.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

import os
import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any, Callable

import pandas as pd

from modules.engine import EngineConfig


# -------------------------------------------------------------------
# Worker globals for parallel processing
# -------------------------------------------------------------------
_WORKER_ENGINE_CLASS = None
_WORKER_DATA = None
_WORKER_STRATEGY_FACTORY = None
_WORKER_CONFIG = None


def _parse_money(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).replace("$", "").replace(",", "").strip()
    return float(text)


def _parse_percent(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).replace("%", "").strip()
    return float(text)


def _calculate_years_in_sample(data: pd.DataFrame) -> float:
    if data.empty:
        return 0.0

    start = data.index.min()
    end = data.index.max()
    total_days = (end - start).days

    if total_days <= 0:
        return 0.0

    return total_days / 365.25


def _init_refinement_worker(
    engine_class: type,
    data: pd.DataFrame,
    strategy_factory: Callable[..., Any],
    config: EngineConfig,
) -> None:
    global _WORKER_ENGINE_CLASS, _WORKER_DATA, _WORKER_STRATEGY_FACTORY, _WORKER_CONFIG

    _WORKER_ENGINE_CLASS = engine_class
    _WORKER_DATA = data
    _WORKER_STRATEGY_FACTORY = strategy_factory
    _WORKER_CONFIG = config


def _run_refinement_case(task: dict[str, Any]) -> dict[str, Any]:
    strategy = _WORKER_STRATEGY_FACTORY(
        hold_bars=task["hold_bars"],
        stop_distance_points=task["stop_distance_points"],
        min_avg_range=task["min_avg_range"],
        momentum_lookback=task["momentum_lookback"],
    )

    engine = _WORKER_ENGINE_CLASS(data=_WORKER_DATA, config=_WORKER_CONFIG)
    engine.run(strategy=strategy)
    summary = engine.results()

    total_trades = int(summary["Total Trades"])
    years_in_sample = float(task["years_in_sample"])
    trades_per_year = total_trades / years_in_sample if years_in_sample > 0 else 0.0

    passes_trade_filter = (
        total_trades >= task["min_trades"]
        and trades_per_year >= task["min_trades_per_year"]
    )

    return {
        "strategy_name": str(summary["Strategy"]),
        "hold_bars": int(task["hold_bars"]),
        "stop_distance_points": float(task["stop_distance_points"]),
        "min_avg_range": float(task["min_avg_range"]),
        "momentum_lookback": int(task["momentum_lookback"]),
        "total_trades": total_trades,
        "trades_per_year": trades_per_year,
        "passes_trade_filter": passes_trade_filter,
        "net_pnl": _parse_money(summary["Net PnL"]),
        "gross_profit": _parse_money(summary["Gross Profit"]),
        "gross_loss": _parse_money(summary["Gross Loss"]),
        "average_trade": _parse_money(summary["Average Trade"]),
        "profit_factor": float(summary["Profit Factor"]),
        "max_drawdown": _parse_money(summary["Max Drawdown"]),
        "win_rate": _parse_percent(summary["Win Rate"]),
        "average_mae_points": float(summary["Average MAE (pts)"]),
        "average_mfe_points": float(summary["Average MFE (pts)"]),
    }


@dataclass
class RefinementResult:
    strategy_name: str
    hold_bars: int
    stop_distance_points: float
    min_avg_range: float
    momentum_lookback: int
    total_trades: int
    trades_per_year: float
    passes_trade_filter: bool
    net_pnl: float
    gross_profit: float
    gross_loss: float
    average_trade: float
    profit_factor: float
    max_drawdown: float
    win_rate: float
    average_mae_points: float
    average_mfe_points: float


class StrategyParameterRefiner:
    """
    Refines a chosen promising strategy/filter stack by sweeping a manageable
    grid of internal parameter values.
    """

    def __init__(
        self,
        engine_class: type,
        data: pd.DataFrame,
        strategy_factory: Callable[..., Any],
        config: EngineConfig | None = None,
    ):
        self.engine_class = engine_class
        self.data = data
        self.strategy_factory = strategy_factory
        self.config = config or EngineConfig()
        self.results: list[RefinementResult] = []

    def _default_max_workers(self) -> int:
        cpu_count = os.cpu_count() or 4
        return max(1, min(6, cpu_count - 2))

    def run_refinement(
        self,
        hold_bars: list[int],
        stop_distance_points: list[float],
        min_avg_range: list[float],
        momentum_lookback: list[int],
        min_trades: int = 150,
        min_trades_per_year: float = 8.0,
        parallel: bool = True,
        max_workers: int | None = None,
    ) -> pd.DataFrame:
        self.results = []

        years_in_sample = _calculate_years_in_sample(self.data)
        combinations = list(
            product(
                hold_bars,
                stop_distance_points,
                min_avg_range,
                momentum_lookback,
            )
        )

        total_runs = len(combinations)
        accepted_count = 0
        rejected_count = 0
        start_time = time.perf_counter()

        if max_workers is None:
            max_workers = self._default_max_workers()

        print("\n🎯 Running top-combo parameter refinement...")
        print(f"Total combinations: {total_runs}")
        print(f"Years in sample: {years_in_sample:.2f}")
        print(
            f"Trade filters: min_trades={min_trades}, "
            f"min_trades_per_year={min_trades_per_year:.2f}"
        )
        print(
            f"Parallel mode: {'ON' if parallel else 'OFF'} | "
            f"max_workers={max_workers if parallel else 1}"
        )

        tasks = [
            {
                "hold_bars": hb,
                "stop_distance_points": float(stop_pts),
                "min_avg_range": float(min_range),
                "momentum_lookback": int(mom_lb),
                "years_in_sample": years_in_sample,
                "min_trades": min_trades,
                "min_trades_per_year": min_trades_per_year,
            }
            for hb, stop_pts, min_range, mom_lb in combinations
        ]

        if parallel and total_runs > 1:
            with ProcessPoolExecutor(
                max_workers=max_workers,
                initializer=_init_refinement_worker,
                initargs=(
                    self.engine_class,
                    self.data,
                    self.strategy_factory,
                    self.config,
                ),
            ) as executor:
                for idx, result in enumerate(executor.map(_run_refinement_case, tasks), start=1):
                    if result["passes_trade_filter"]:
                        accepted_count += 1
                        self.results.append(RefinementResult(**result))
                    else:
                        rejected_count += 1

                    print(
                        f"  Done {idx}/{total_runs} | "
                        f"hb={result['hold_bars']}, "
                        f"stop={result['stop_distance_points']}, "
                        f"range={result['min_avg_range']}, "
                        f"mom={result['momentum_lookback']} | "
                        f"PF={result['profit_factor']:.2f} | "
                        f"{'ACCEPT' if result['passes_trade_filter'] else 'REJECT'}"
                    )
        else:
            _init_refinement_worker(
                self.engine_class,
                self.data,
                self.strategy_factory,
                self.config,
            )

            for idx, task in enumerate(tasks, start=1):
                result = _run_refinement_case(task)

                if result["passes_trade_filter"]:
                    accepted_count += 1
                    self.results.append(RefinementResult(**result))
                else:
                    rejected_count += 1

                print(
                    f"  Done {idx}/{total_runs} | "
                    f"hb={result['hold_bars']}, "
                    f"stop={result['stop_distance_points']}, "
                    f"range={result['min_avg_range']}, "
                    f"mom={result['momentum_lookback']} | "
                    f"PF={result['profit_factor']:.2f} | "
                    f"{'ACCEPT' if result['passes_trade_filter'] else 'REJECT'}"
                )

        elapsed = time.perf_counter() - start_time

        print(f"\n✅ Accepted refinement sets: {accepted_count}")
        print(f"❌ Rejected refinement sets: {rejected_count}")
        print(f"⏱ Refinement runtime: {elapsed:.2f} seconds")

        return self.results_dataframe()

    def results_dataframe(self) -> pd.DataFrame:
        if not self.results:
            return pd.DataFrame()

        df = pd.DataFrame([r.__dict__ for r in self.results])
        df = df.sort_values(
            by=["profit_factor", "average_trade", "net_pnl"],
            ascending=[False, False, False],
        ).reset_index(drop=True)

        return df

    def display_dataframe(self) -> pd.DataFrame:
        df = self.results_dataframe()
        if df.empty:
            return df

        display_columns = [
            "hold_bars",
            "stop_distance_points",
            "min_avg_range",
            "momentum_lookback",
            "total_trades",
            "trades_per_year",
            "profit_factor",
            "average_trade",
            "net_pnl",
            "max_drawdown",
            "win_rate",
            "average_mae_points",
            "average_mfe_points",
        ]

        available_columns = [c for c in display_columns if c in df.columns]
        out = df[available_columns].copy()

        round_cols = [
            "stop_distance_points",
            "min_avg_range",
            "trades_per_year",
            "profit_factor",
            "average_trade",
            "net_pnl",
            "max_drawdown",
            "win_rate",
            "average_mae_points",
            "average_mfe_points",
        ]
        for col in round_cols:
            if col in out.columns:
                out[col] = out[col].round(2)

        return out

    def top_results(self, n: int = 10) -> pd.DataFrame:
        df = self.display_dataframe()
        if df.empty:
            return df
        return df.head(n)

    def summary_report(self, top_n: int = 10) -> dict[str, Any]:
        df = self.results_dataframe()
        if df.empty:
            return {}

        top_df = df.head(top_n)

        best_pf = df.sort_values(by="profit_factor", ascending=False).iloc[0].to_dict()
        best_avg_trade = df.sort_values(by="average_trade", ascending=False).iloc[0].to_dict()
        best_net_pnl = df.sort_values(by="net_pnl", ascending=False).iloc[0].to_dict()

        hold_counter = Counter(top_df["hold_bars"].tolist())
        stop_counter = Counter(top_df["stop_distance_points"].tolist())
        range_counter = Counter(top_df["min_avg_range"].tolist())
        mom_counter = Counter(top_df["momentum_lookback"].tolist())

        return {
            "best_pf": best_pf,
            "best_average_trade": best_avg_trade,
            "best_net_pnl": best_net_pnl,
            "top_n": top_n,
            "common_hold_bars": hold_counter.most_common(),
            "common_stop_distance_points": stop_counter.most_common(),
            "common_min_avg_range": range_counter.most_common(),
            "common_momentum_lookback": mom_counter.most_common(),
        }

    def print_summary_report(self, top_n: int = 10) -> None:
        report = self.summary_report(top_n=top_n)
        if not report:
            print("\nNo refinement summary available.")
            return

        print("\n🧠 Refinement Summary Report")

        best_pf = report["best_pf"]
        print("\nBest Profit Factor setting:")
        print(
            f"  hold_bars={best_pf['hold_bars']}, "
            f"stop={best_pf['stop_distance_points']}, "
            f"min_avg_range={best_pf['min_avg_range']}, "
            f"momentum_lookback={best_pf['momentum_lookback']} | "
            f"PF={best_pf['profit_factor']:.2f}, "
            f"avg_trade={best_pf['average_trade']:.2f}, "
            f"net_pnl={best_pf['net_pnl']:.2f}"
        )

        best_avg_trade = report["best_average_trade"]
        print("\nBest Average Trade setting:")
        print(
            f"  hold_bars={best_avg_trade['hold_bars']}, "
            f"stop={best_avg_trade['stop_distance_points']}, "
            f"min_avg_range={best_avg_trade['min_avg_range']}, "
            f"momentum_lookback={best_avg_trade['momentum_lookback']} | "
            f"avg_trade={best_avg_trade['average_trade']:.2f}, "
            f"PF={best_avg_trade['profit_factor']:.2f}, "
            f"net_pnl={best_avg_trade['net_pnl']:.2f}"
        )

        best_net_pnl = report["best_net_pnl"]
        print("\nBest Net PnL setting:")
        print(
            f"  hold_bars={best_net_pnl['hold_bars']}, "
            f"stop={best_net_pnl['stop_distance_points']}, "
            f"min_avg_range={best_net_pnl['min_avg_range']}, "
            f"momentum_lookback={best_net_pnl['momentum_lookback']} | "
            f"net_pnl={best_net_pnl['net_pnl']:.2f}, "
            f"PF={best_net_pnl['profit_factor']:.2f}, "
            f"avg_trade={best_net_pnl['average_trade']:.2f}"
        )

        print(f"\nMost common values in top {report['top_n']} results:")
        print(f"  hold_bars: {report['common_hold_bars']}")
        print(f"  stop_distance_points: {report['common_stop_distance_points']}")
        print(f"  min_avg_range: {report['common_min_avg_range']}")
        print(f"  momentum_lookback: {report['common_momentum_lookback']}")

    def save_results_csv(self, filepath: str | Path) -> Path:
        df = self.results_dataframe()
        if df.empty:
            raise ValueError("No refinement results to save.")

        output_path = Path(filepath)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        return output_path
```

---
#### modules/portfolio_evaluator.py @ 3/13/2026, 1:03:30 PM
```python
"""
Portfolio Evaluator
Reads the family leaderboard, reconstructs the winning strategies, 
runs 30/70 weighted historical scores, calculates Monte Carlo metrics,
and generates separate Review, Returns, and Correlation tables.
"""

import re
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

from modules.data_loader import load_tradestation_csv
from modules.engine import EngineConfig, MasterStrategyEngine
from modules.feature_builder import add_precomputed_features
from modules.strategy_types import get_strategy_type
import modules.filters as filters_module


def generate_run_id(market: str, timeframe: str) -> tuple[str, str]:
    """Generates a unique Run ID and returns the timestamp."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    run_id = f"{timestamp}_{market}_{timeframe}"
    return run_id, timestamp


def run_monte_carlo_stats(trades_series: pd.Series, iterations: int = 10000) -> dict[str, float]:
    """Runs a bootstrap Monte Carlo simulation to find drawdown and PnL percentiles."""
    if len(trades_series) == 0:
        return {"mc_dd_95": 0.0, "mc_dd_99": 0.0, "mc_pnl_50": 0.0, "mc_pnl_10": 0.0}

    trades_arr = trades_series.values
    n_trades = len(trades_arr)
    max_drawdowns = np.zeros(iterations)
    net_pnls = np.zeros(iterations)

    for i in range(iterations):
        # Randomly sample trades with replacement
        simulated_trades = np.random.choice(trades_arr, size=n_trades, replace=True)
        cum_equity = np.cumsum(simulated_trades)
        
        running_max = np.maximum.accumulate(cum_equity)
        drawdowns = running_max - cum_equity
        
        max_drawdowns[i] = np.max(drawdowns) if len(drawdowns) > 0 else 0.0
        net_pnls[i] = cum_equity[-1]

    return {
        "mc_dd_95": float(np.percentile(max_drawdowns, 95)),
        "mc_dd_99": float(np.percentile(max_drawdowns, 99)),
        "mc_pnl_50": float(np.percentile(net_pnls, 50)),
        "mc_pnl_10": float(np.percentile(net_pnls, 10)),
    }


def calculate_metrics_split(trades_df: pd.DataFrame) -> dict[str, float]:
    """Calculates Full vs Recent (Last 365 Days) metrics."""
    if trades_df.empty or "exit_time" not in trades_df.columns:
        return {
            "full_pf": 0.0, "full_avg": 0.0, "full_net": 0.0, "max_dd": 0.0,
            "recent_pf": 0.0, "recent_avg": 0.0
        }

    trades_df["exit_time"] = pd.to_datetime(trades_df["exit_time"])
    
    # Full Metrics
    gross_prof_full = trades_df[trades_df["net_pnl"] > 0]["net_pnl"].sum()
    gross_loss_full = abs(trades_df[trades_df["net_pnl"] < 0]["net_pnl"].sum())
    full_pf = gross_prof_full / gross_loss_full if gross_loss_full > 0 else float(gross_prof_full)
    full_avg = trades_df["net_pnl"].mean()
    full_net = trades_df["net_pnl"].sum()
    
    cum_pnl = trades_df["net_pnl"].cumsum()
    max_dd = float((cum_pnl.cummax() - cum_pnl).max()) if not cum_pnl.empty else 0.0

    # Recent 12 Month Metrics
    max_date = trades_df["exit_time"].max()
    cutoff_date = max_date - timedelta(days=365)
    recent_trades = trades_df[trades_df["exit_time"] >= cutoff_date]

    if recent_trades.empty:
        recent_pf, recent_avg = 1.0, 0.0
    else:
        g_prof_rec = recent_trades[recent_trades["net_pnl"] > 0]["net_pnl"].sum()
        g_loss_rec = abs(recent_trades[recent_trades["net_pnl"] < 0]["net_pnl"].sum())
        recent_pf = g_prof_rec / g_loss_rec if g_loss_rec > 0 else float(g_prof_rec)
        recent_avg = recent_trades["net_pnl"].mean()

    return {
        "full_pf": float(full_pf),
        "full_avg": float(full_avg),
        "full_net": float(full_net),
        "max_dd": float(max_dd),
        "recent_pf": float(recent_pf),
        "recent_avg": float(recent_avg),
    }


def evaluate_portfolio(
    leaderboard_csv: Path,
    data_csv: Path,
    market_name: str = "ES",
    timeframe: str = "60m",
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Returns (Review_Table_DF, Daily_Returns_DF, Correlation_Matrix_DF)"""
    
    if not leaderboard_csv.exists():
        print(f"Leaderboard file not found: {leaderboard_csv}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    leaderboard_df = pd.read_csv(leaderboard_csv)
    if leaderboard_df.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    print(f"\nLoading market data from: {data_csv} for evaluation...")
    data = load_tradestation_csv(data_csv)
    
    run_id, timestamp = generate_run_id(market_name, timeframe)
    results_list = []
    daily_returns_dict = {}

    print(f"\nEvaluating {len(leaderboard_df)} strategies from Leaderboard...")

    for _, row in leaderboard_df.iterrows():
        strategy_type_name = row["strategy_type"]
        
        if row["promotion_status"] == "NO_PROMOTED_CANDIDATES":
            continue

        is_refined = row["leader_source"] == "refined"
        strategy_name = row["best_refined_strategy_name"] if is_refined else row["best_combo_strategy_name"]
        combo_name = row["best_combo_strategy_name"]
        strategy_id = f"{run_id}_{strategy_name}"
        
        print(f"\n  Evaluating: {strategy_type_name} -> {strategy_name}")

        # Baseline metrics from leaderboard
        full_pf = float(row["leader_pf"])
        full_net = float(row["leader_net_pnl"])
        full_avg_trade = float(row["leader_avg_trade"])
        
        years_in_sample = (data.index.max() - data.index.min()).days / 365.25
        trades_per_year = float(row["leader_trades"]) / years_in_sample if years_in_sample > 0 else 0

        trades_df = pd.DataFrame()
        filters_str = "UNKNOWN"
        try:
            promoted_csv = Path("Outputs") / f"{strategy_type_name}_promoted_candidates.csv"
            promoted_df = pd.read_csv(promoted_csv)
            combo_row = promoted_df[promoted_df["strategy_name"] == combo_name].iloc[0]
            filters_str = combo_row["filters"]
            filter_names = [f.strip() for f in filters_str.split(",")]
            
            combo_classes = [getattr(filters_module, fname, None) for fname in filter_names if getattr(filters_module, fname, None)]

            match = re.search(r'_HB(\d+)_STOP([\d.]+)_RANGE([\d.]+)_MOM(\d+)', strategy_name)
            if match and is_refined:
                hb, stop, rng, mom = int(match.group(1)), float(match.group(2)), float(match.group(3)), int(match.group(4))
            else:
                hb, stop, rng, mom = 4, 10.0, 0.0, 0
                
            strategy_type_inst = get_strategy_type(strategy_type_name)
            eval_data = add_precomputed_features(
                data.copy(),
                sma_lengths=strategy_type_inst.get_required_sma_lengths(),
                avg_range_lookbacks=strategy_type_inst.get_required_avg_range_lookbacks(),
                momentum_lookbacks=strategy_type_inst.get_required_momentum_lookbacks(),
            )
            
            strategy = strategy_type_inst.build_candidate_specific_strategy(combo_classes, hb, stop, rng, mom)
            
            cfg = EngineConfig(initial_capital=250000.0, risk_per_trade=0.01, symbol=market_name)
            engine = MasterStrategyEngine(data=eval_data, config=cfg)
            engine.run(strategy=strategy)
            trades_df = engine.trades_dataframe()
            print(f"    [OK] Engine Re-run complete. Total Trades Found: {len(trades_df)}")

            # --- COLUMN NORMALIZER ---
            col_map = {}
            for col in trades_df.columns:
                if col.lower() in ["pnl", "net_pnl", "net pnl"]:
                    col_map[col] = "net_pnl"
                if col.lower() in ["exit_time", "exit time", "exit date"]:
                    col_map[col] = "exit_time"
            trades_df = trades_df.rename(columns=col_map)

        except Exception as e:
            print(f"    [Warning] Could not reconstruct trade history for {strategy_name}: {e}")

        # --- EXTRACT METRICS & DAILY RETURNS ---
        if not trades_df.empty and "net_pnl" in trades_df.columns:
            print("    Running 10,000 iteration Monte Carlo simulation...")
            
            daily_pnl = trades_df.resample('D', on='exit_time')["net_pnl"].sum().fillna(0)
            daily_returns_dict[strategy_id] = daily_pnl

            split_stats = calculate_metrics_split(trades_df)
            mc_stats = run_monte_carlo_stats(trades_df["net_pnl"], iterations=10000)
            
            weighted_pf = (split_stats["recent_pf"] * 0.3) + (split_stats["full_pf"] * 0.7)
            weighted_avg = (split_stats["recent_avg"] * 0.3) + (split_stats["full_avg"] * 0.7)
            total_trades = len(trades_df)
        else:
            print("    [Warning] Normalized Trade history empty or missing 'net_pnl'. Using baseline Leaderboard metrics.")
            split_stats = {"full_pf": full_pf, "full_avg": full_avg_trade, "full_net": full_net, "max_dd": 0.0, "recent_pf": full_pf, "recent_avg": full_avg_trade}
            mc_stats = {"mc_dd_95": 0.0, "mc_dd_99": 0.0, "mc_pnl_50": full_net, "mc_pnl_10": 0.0}
            weighted_pf = full_pf
            weighted_avg = full_avg_trade
            total_trades = int(row["leader_trades"])

        results_list.append({
            "run_id": run_id,
            "run_timestamp": timestamp,
            "market": market_name,
            "timeframe": timeframe,
            "strategy_family": strategy_type_name,
            "strategy_name": strategy_name,
            "strategy_id": strategy_id,
            "filters": filters_str,
            "total_trades": total_trades,
            "trades_per_year": round(trades_per_year, 1),
            "profit_factor": round(split_stats["full_pf"], 2),
            "average_trade": round(split_stats["full_avg"], 2),
            "net_pnl": round(split_stats["full_net"], 2),
            "max_drawdown": round(split_stats["max_dd"], 2),
            "recent_12m_pf": round(split_stats["recent_pf"], 2),
            "recent_12m_avg_trade": round(split_stats["recent_avg"], 2),
            "weighted_pf_score": round(weighted_pf, 2),
            "weighted_avg_trade_score": round(weighted_avg, 2),
            "mc_max_dd_95": round(mc_stats["mc_dd_95"], 2),
            "mc_max_dd_99": round(mc_stats["mc_dd_99"], 2),
            "mc_net_pnl_50": round(mc_stats["mc_pnl_50"], 2),
            "mc_net_pnl_10": round(mc_stats["mc_pnl_10"], 2),
        })

    review_df = pd.DataFrame(results_list)
    
    # --- BUILD CORRELATION MATRIX ---
    returns_df = pd.DataFrame(daily_returns_dict).fillna(0)
    corr_df = returns_df.corr() if not returns_df.empty else pd.DataFrame()

    return review_df, returns_df, corr_df
```

---
#### modules/plateau_analyzer.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd


@dataclass
class PlateauSummary:
    top_n: int
    hold_bars_values: list[int]
    stop_distance_values: list[float]
    min_avg_range_values: list[float]
    momentum_lookback_values: list[int]
    hold_bars_range: str
    stop_distance_range: str
    min_avg_range_range: str
    momentum_lookback_range: str
    best_pf_row: dict[str, Any]
    best_avg_trade_row: dict[str, Any]
    best_net_pnl_row: dict[str, Any]


class PlateauAnalyzer:
    """
    Examines the top refinement rows and summarizes repeated value zones.

    This is not yet a sophisticated plateau detector, but it provides a
    strong first-pass "candidate zone" view of where good results cluster.
    """

    def __init__(self, results_df: pd.DataFrame):
        self.results_df = results_df.copy()

    @staticmethod
    def _format_range(values: list[Any]) -> str:
        if not values:
            return "N/A"

        unique_vals = sorted(set(values))
        if len(unique_vals) == 1:
            return str(unique_vals[0])

        return f"{unique_vals[0]} to {unique_vals[-1]}"

    def analyze(self, top_n: int = 10) -> PlateauSummary | None:
        if self.results_df.empty:
            return None

        top_df = self.results_df.head(top_n).copy()

        hold_vals = sorted(top_df["hold_bars"].tolist())
        stop_vals = sorted(top_df["stop_distance_points"].tolist())
        range_vals = sorted(top_df["min_avg_range"].tolist())
        mom_vals = sorted(top_df["momentum_lookback"].tolist())

        best_pf_row = (
            self.results_df.sort_values(by="profit_factor", ascending=False)
            .iloc[0]
            .to_dict()
        )
        best_avg_trade_row = (
            self.results_df.sort_values(by="average_trade", ascending=False)
            .iloc[0]
            .to_dict()
        )
        best_net_pnl_row = (
            self.results_df.sort_values(by="net_pnl", ascending=False)
            .iloc[0]
            .to_dict()
        )

        return PlateauSummary(
            top_n=top_n,
            hold_bars_values=hold_vals,
            stop_distance_values=stop_vals,
            min_avg_range_values=range_vals,
            momentum_lookback_values=mom_vals,
            hold_bars_range=self._format_range(hold_vals),
            stop_distance_range=self._format_range(stop_vals),
            min_avg_range_range=self._format_range(range_vals),
            momentum_lookback_range=self._format_range(mom_vals),
            best_pf_row=best_pf_row,
            best_avg_trade_row=best_avg_trade_row,
            best_net_pnl_row=best_net_pnl_row,
        )

    def print_report(self, top_n: int = 10) -> None:
        summary = self.analyze(top_n=top_n)
        if summary is None:
            print("\nNo plateau summary available.")
            return

        print("\n📍 Candidate Zone Report")
        print(f"Top rows analyzed: {summary.top_n}")

        print("\nCandidate parameter zones from top results:")
        print(f"  hold_bars: {summary.hold_bars_range} | values={sorted(set(summary.hold_bars_values))}")
        print(
            f"  stop_distance_points: {summary.stop_distance_range} | "
            f"values={sorted(set(summary.stop_distance_values))}"
        )
        print(
            f"  min_avg_range: {summary.min_avg_range_range} | "
            f"values={sorted(set(summary.min_avg_range_values))}"
        )
        print(
            f"  momentum_lookback: {summary.momentum_lookback_range} | "
            f"values={sorted(set(summary.momentum_lookback_values))}"
        )

        pf_row = summary.best_pf_row
        print("\nAnchor best-PF point inside candidate zone:")
        print(
            f"  hold_bars={pf_row['hold_bars']}, "
            f"stop={pf_row['stop_distance_points']}, "
            f"min_avg_range={pf_row['min_avg_range']}, "
            f"momentum_lookback={pf_row['momentum_lookback']} | "
            f"PF={pf_row['profit_factor']:.2f}, "
            f"avg_trade={pf_row['average_trade']:.2f}, "
            f"net_pnl={pf_row['net_pnl']:.2f}"
        )
```

---
#### modules/optimizer.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any, Type

import pandas as pd

from modules.engine import EngineConfig


@dataclass
class OptimizationResult:
    strategy_name: str
    hold_bars: int
    stop_distance_points: float
    total_trades: int
    years_in_sample: float
    trades_per_year: float
    passes_trade_filter: bool
    net_pnl: float
    gross_profit: float
    gross_loss: float
    average_trade: float
    profit_factor: float
    max_drawdown: float
    win_rate: float
    average_mae_points: float
    average_mfe_points: float


class StrategyOptimizer:
    """
    Runs simple grid-search optimization over strategy parameters.
    Applies trade-frequency filters to reject statistically weak parameter sets.
    """

    def __init__(
        self,
        engine_class: Type,
        data: pd.DataFrame,
        strategy_class: Type,
        config: EngineConfig | None = None,
    ):
        self.engine_class = engine_class
        self.data = data
        self.strategy_class = strategy_class
        self.config = config or EngineConfig()
        self.results: list[OptimizationResult] = []

    @staticmethod
    def _parse_money(value: Any) -> float:
        """
        Converts strings like '$-200,201.50' into float.
        """
        if isinstance(value, (int, float)):
            return float(value)

        text = str(value).replace("$", "").replace(",", "").strip()
        return float(text)

    @staticmethod
    def _parse_percent(value: Any) -> float:
        """
        Converts strings like '34.84%' into float.
        """
        if isinstance(value, (int, float)):
            return float(value)

        text = str(value).replace("%", "").strip()
        return float(text)

    def _calculate_years_in_sample(self) -> float:
        """
        Estimate years covered by the dataset using the datetime index.
        """
        if self.data.empty:
            return 0.0

        start = self.data.index.min()
        end = self.data.index.max()

        total_days = (end - start).days
        if total_days <= 0:
            return 0.0

        return total_days / 365.25

    def run_grid_search(
        self,
        hold_bars: list[int],
        stop_distance_points: list[float],
        min_trades: int = 0,
        min_trades_per_year: float = 0.0,
    ) -> pd.DataFrame:
        """
        Runs all combinations of hold_bars and stop_distance_points.
        Returns a dataframe of accepted optimization results only.
        """
        self.results = []

        combinations = list(product(hold_bars, stop_distance_points))
        total_runs = len(combinations)
        years_in_sample = self._calculate_years_in_sample()

        print("\n🔍 Running optimization grid search...")
        print(f"Total combinations: {total_runs}")
        print(f"Years in sample: {years_in_sample:.2f}")
        print(f"Trade filters: min_trades={min_trades}, min_trades_per_year={min_trades_per_year:.2f}")

        accepted_count = 0
        rejected_count = 0

        for run_number, (hb, stop_pts) in enumerate(combinations, start=1):
            print(
                f"  Run {run_number}/{total_runs} | "
                f"hold_bars={hb}, stop_distance_points={stop_pts}"
            )

            strategy = self.strategy_class()
            strategy.hold_bars = hb
            strategy.stop_distance_points = float(stop_pts)

            engine = self.engine_class(data=self.data, config=self.config)
            engine.run(strategy=strategy)

            summary = engine.results()
            total_trades = int(summary["Total Trades"])

            trades_per_year = (
                total_trades / years_in_sample if years_in_sample > 0 else 0.0
            )

            passes_trade_filter = (
                total_trades >= min_trades
                and trades_per_year >= min_trades_per_year
            )

            if not passes_trade_filter:
                rejected_count += 1
                print(
                    f"    ↳ Rejected by trade filter "
                    f"(trades={total_trades}, trades/year={trades_per_year:.2f})"
                )
                continue

            result = OptimizationResult(
                strategy_name=str(summary["Strategy"]),
                hold_bars=hb,
                stop_distance_points=float(stop_pts),
                total_trades=total_trades,
                years_in_sample=years_in_sample,
                trades_per_year=trades_per_year,
                passes_trade_filter=passes_trade_filter,
                net_pnl=self._parse_money(summary["Net PnL"]),
                gross_profit=self._parse_money(summary["Gross Profit"]),
                gross_loss=self._parse_money(summary["Gross Loss"]),
                average_trade=self._parse_money(summary["Average Trade"]),
                profit_factor=float(summary["Profit Factor"]),
                max_drawdown=self._parse_money(summary["Max Drawdown"]),
                win_rate=self._parse_percent(summary["Win Rate"]),
                average_mae_points=float(summary["Average MAE (pts)"]),
                average_mfe_points=float(summary["Average MFE (pts)"]),
            )
            self.results.append(result)
            accepted_count += 1

        print(f"\n✅ Accepted parameter sets: {accepted_count}")
        print(f"❌ Rejected parameter sets: {rejected_count}")

        return self.results_dataframe()

    def results_dataframe(self) -> pd.DataFrame:
        if not self.results:
            return pd.DataFrame()

        df = pd.DataFrame([r.__dict__ for r in self.results])

        sort_columns = ["profit_factor", "average_trade", "net_pnl"]
        existing_sort_columns = [col for col in sort_columns if col in df.columns]

        if existing_sort_columns:
            df = df.sort_values(
                by=existing_sort_columns,
                ascending=[False] * len(existing_sort_columns),
            ).reset_index(drop=True)

        return df

    def display_dataframe(self) -> pd.DataFrame:
        """
        Returns a cleaner dataframe for terminal display.
        """
        df = self.results_dataframe()
        if df.empty:
            return df

        display_columns = [
            "hold_bars",
            "stop_distance_points",
            "total_trades",
            "trades_per_year",
            "profit_factor",
            "average_trade",
            "net_pnl",
            "max_drawdown",
            "win_rate",
            "average_mae_points",
            "average_mfe_points",
        ]

        available_columns = [col for col in display_columns if col in df.columns]
        display_df = df[available_columns].copy()

        money_columns = ["average_trade", "net_pnl", "max_drawdown"]
        for col in money_columns:
            if col in display_df.columns:
                display_df[col] = display_df[col].round(2)

        float_columns = [
            "stop_distance_points",
            "trades_per_year",
            "profit_factor",
            "win_rate",
            "average_mae_points",
            "average_mfe_points",
        ]
        for col in float_columns:
            if col in display_df.columns:
                display_df[col] = display_df[col].round(2)

        return display_df

    def top_results(self, n: int = 10) -> pd.DataFrame:
        df = self.display_dataframe()
        if df.empty:
            return df
        return df.head(n)

    def save_results_csv(self, filepath: str | Path) -> Path:
        """
        Saves the full optimization results dataframe to CSV.
        """
        df = self.results_dataframe()
        if df.empty:
            raise ValueError("No optimization results to save.")

        output_path = Path(filepath)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        df.to_csv(output_path, index=False)
        return output_path
```

---
#### modules/heatmap.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

import pandas as pd


class OptimizationHeatmap:
    """
    Generates pivot-table heatmaps from optimizer results.
    Used to visualize parameter plateaus.
    """

    def __init__(self, optimization_df: pd.DataFrame):
        if optimization_df is None or optimization_df.empty:
            raise ValueError("Optimization dataframe is empty.")

        self.df = optimization_df.copy()

    def create_heatmap(
        self,
        metric: str,
        index_param: str = "hold_bars",
        column_param: str = "stop_distance_points",
    ) -> pd.DataFrame:
        """
        Creates pivot heatmap for chosen metric.
        """

        if metric not in self.df.columns:
            raise ValueError(f"Metric '{metric}' not found in optimization results.")

        heatmap = self.df.pivot_table(
            values=metric,
            index=index_param,
            columns=column_param,
            aggfunc="mean"
        )

        return heatmap.round(3)

    def print_heatmap(
        self,
        metric: str,
        title: str,
        index_param: str = "hold_bars",
        column_param: str = "stop_distance_points",
    ):
        """
        Prints formatted heatmap to terminal.
        """

        heatmap = self.create_heatmap(metric, index_param, column_param)

        print(f"\n📊 {title}")
        print(heatmap)
```

---
#### modules/filter_combinator.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from itertools import combinations
from typing import List, Type


def generate_filter_combinations(
    filter_classes: list[Type],
    min_filters: int = 3,
    max_filters: int = 5,
) -> list[list[Type]]:
    """
    Generate combinations of filter classes.

    Example:
        [Trend, Pullback, Recovery, Volatility, Momentum]
    ->
        [
            [Trend, Pullback, Recovery],
            [Trend, Pullback, Recovery, Volatility],
            ...
        ]
    """
    if not filter_classes:
        return []

    combos: list[list[Type]] = []

    max_filters = min(max_filters, len(filter_classes))

    for r in range(min_filters, max_filters + 1):
        for combo in combinations(filter_classes, r):
            combos.append(list(combo))

    return combos


def build_filter_combo_name(filter_objects: list) -> str:
    """
    Create a readable short name for a filter set.
    """
    if not filter_objects:
        return "NoFilters"

    parts: List[str] = []
    for filter_obj in filter_objects:
        name = getattr(filter_obj, "name", filter_obj.__class__.__name__)
        short_name = name.replace("Filter", "")
        parts.append(short_name)

    return "_".join(parts)
```

---
#### modules/filters.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from abc import ABC, abstractmethod

import pandas as pd


class BaseFilter(ABC):
    """
    Base class for reusable strategy filters.
    """

    name: str = "BaseFilter"

    @abstractmethod
    def passes(self, data: pd.DataFrame, i: int) -> bool:
        raise NotImplementedError


# ============================================================
# Trend-family filters
# ============================================================

class TrendDirectionFilter(BaseFilter):
    """
    Bull trend when fast SMA > slow SMA.
    """

    name = "TrendDirectionFilter"

    def __init__(self, fast_length: int = 50, slow_length: int = 200):
        self.fast_length = fast_length
        self.slow_length = slow_length

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        required_bars = max(self.fast_length, self.slow_length)
        if i < required_bars:
            return False

        fast_col = f"sma_{self.fast_length}"
        slow_col = f"sma_{self.slow_length}"

        if fast_col in data.columns and slow_col in data.columns:
            fast_sma = data.iloc[i][fast_col]
            slow_sma = data.iloc[i][slow_col]
        else:
            close_series = data["close"]
            fast_sma = close_series.iloc[i - self.fast_length + 1 : i + 1].mean()
            slow_sma = close_series.iloc[i - self.slow_length + 1 : i + 1].mean()

        if pd.isna(fast_sma) or pd.isna(slow_sma):
            return False

        return bool(fast_sma > slow_sma)


class PullbackFilter(BaseFilter):
    """
    Previous close is at or below the fast SMA.
    """

    name = "PullbackFilter"

    def __init__(self, fast_length: int = 50):
        self.fast_length = fast_length

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.fast_length:
            return False

        fast_col = f"sma_{self.fast_length}"

        if fast_col in data.columns and "prev_close" in data.columns:
            prev_fast_sma = data.iloc[i - 1][fast_col]
            previous_close = data.iloc[i]["prev_close"]
        else:
            close_series = data["close"]
            prev_fast_sma = close_series.iloc[i - self.fast_length : i].mean()
            previous_close = close_series.iloc[i - 1]

        if pd.isna(prev_fast_sma) or pd.isna(previous_close):
            return False

        return bool(previous_close <= prev_fast_sma)


class RecoveryTriggerFilter(BaseFilter):
    """
    Current close is back above the fast SMA.
    """

    name = "RecoveryTriggerFilter"

    def __init__(self, fast_length: int = 50):
        self.fast_length = fast_length

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.fast_length:
            return False

        fast_col = f"sma_{self.fast_length}"

        if fast_col in data.columns:
            fast_sma = data.iloc[i][fast_col]
            current_close = data.iloc[i]["close"]
        else:
            close_series = data["close"]
            fast_sma = close_series.iloc[i - self.fast_length + 1 : i + 1].mean()
            current_close = close_series.iloc[i]

        if pd.isna(fast_sma) or pd.isna(current_close):
            return False

        return bool(current_close > fast_sma)


class VolatilityFilter(BaseFilter):
    """
    Average bar range over lookback must exceed a minimum threshold.
    """

    name = "VolatilityFilter"

    def __init__(self, lookback: int = 20, min_avg_range: float = 8.0):
        self.lookback = lookback
        self.min_avg_range = min_avg_range

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        avg_range_col = f"avg_range_{self.lookback}"

        if avg_range_col in data.columns:
            avg_range = data.iloc[i][avg_range_col]
        else:
            window = data.iloc[i - self.lookback + 1 : i + 1]
            avg_range = (window["high"] - window["low"]).mean()

        if pd.isna(avg_range):
            return False

        return bool(avg_range >= self.min_avg_range)


class MomentumFilter(BaseFilter):
    """
    Current close must be above close N bars ago.
    """

    name = "MomentumFilter"

    def __init__(self, lookback: int = 10):
        self.lookback = lookback

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        diff_col = f"mom_diff_{self.lookback}"

        if diff_col in data.columns:
            mom_value = data.iloc[i][diff_col]
            if pd.isna(mom_value):
                return False
            return bool(mom_value > 0)

        close_series = data["close"]
        current_close = close_series.iloc[i]
        past_close = close_series.iloc[i - self.lookback]

        return bool(current_close > past_close)


# ============================================================
# Breakout-family filters
# ============================================================

class CompressionFilter(BaseFilter):
    """
    Recent average range must be below a defined compression threshold.
    """

    name = "CompressionFilter"

    def __init__(self, lookback: int = 20, max_avg_range: float = 6.0):
        self.lookback = lookback
        self.max_avg_range = max_avg_range

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        avg_range_col = f"avg_range_{self.lookback}"

        if avg_range_col in data.columns:
            avg_range = data.iloc[i][avg_range_col]
        else:
            window = data.iloc[i - self.lookback + 1 : i + 1]
            avg_range = (window["high"] - window["low"]).mean()

        if pd.isna(avg_range):
            return False

        return bool(avg_range <= self.max_avg_range)


class RangeBreakoutFilter(BaseFilter):
    """
    Current close must break above the highest high of the prior N bars.
    """

    name = "RangeBreakoutFilter"

    def __init__(self, lookback: int = 20):
        self.lookback = lookback

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        prior_window = data.iloc[i - self.lookback : i]
        if prior_window.empty:
            return False

        prior_high = prior_window["high"].max()
        current_close = data.iloc[i]["close"]

        if pd.isna(prior_high) or pd.isna(current_close):
            return False

        return bool(current_close > prior_high)


class ExpansionBarFilter(BaseFilter):
    """
    Current bar range must exceed recent average range by a multiplier.
    """

    name = "ExpansionBarFilter"

    def __init__(self, lookback: int = 20, expansion_multiplier: float = 1.5):
        self.lookback = lookback
        self.expansion_multiplier = expansion_multiplier

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        current_bar_range = data.iloc[i]["high"] - data.iloc[i]["low"]
        avg_range_col = f"avg_range_{self.lookback}"

        if avg_range_col in data.columns:
            avg_range = data.iloc[i][avg_range_col]
        else:
            window = data.iloc[i - self.lookback + 1 : i + 1]
            avg_range = (window["high"] - window["low"]).mean()

        if pd.isna(current_bar_range) or pd.isna(avg_range) or avg_range <= 0:
            return False

        return bool(current_bar_range >= avg_range * self.expansion_multiplier)


class BreakoutRetestFilter(BaseFilter):
    """
    Current close must be above the prior breakout level by at least a buffer.
    """

    name = "BreakoutRetestFilter"

    def __init__(self, lookback: int = 20, breakout_buffer_points: float = 0.0):
        self.lookback = lookback
        self.breakout_buffer_points = breakout_buffer_points

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        prior_window = data.iloc[i - self.lookback : i]
        if prior_window.empty:
            return False

        prior_high = prior_window["high"].max()
        current_close = data.iloc[i]["close"]

        if pd.isna(prior_high) or pd.isna(current_close):
            return False

        breakout_level = prior_high + self.breakout_buffer_points
        return bool(current_close > breakout_level)


class BreakoutTrendFilter(BaseFilter):
    """
    Optional trend-alignment filter for breakout systems.
    """

    name = "BreakoutTrendFilter"

    def __init__(self, fast_length: int = 50, slow_length: int = 200):
        self.fast_length = fast_length
        self.slow_length = slow_length

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        required_bars = max(self.fast_length, self.slow_length)
        if i < required_bars:
            return False

        fast_col = f"sma_{self.fast_length}"
        slow_col = f"sma_{self.slow_length}"

        if fast_col in data.columns and slow_col in data.columns:
            fast_sma = data.iloc[i][fast_col]
            slow_sma = data.iloc[i][slow_col]
        else:
            close_series = data["close"]
            fast_sma = close_series.iloc[i - self.fast_length + 1 : i + 1].mean()
            slow_sma = close_series.iloc[i - self.slow_length + 1 : i + 1].mean()

        if pd.isna(fast_sma) or pd.isna(slow_sma):
            return False

        return bool(fast_sma > slow_sma)


class BreakoutCloseStrengthFilter(BaseFilter):
    """
    Require the close to finish near the high of the breakout bar.
    """

    name = "BreakoutCloseStrengthFilter"

    def __init__(self, close_position_threshold: float = 0.70):
        self.close_position_threshold = close_position_threshold

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        current_high = data.iloc[i]["high"]
        current_low = data.iloc[i]["low"]
        current_close = data.iloc[i]["close"]

        if pd.isna(current_high) or pd.isna(current_low) or pd.isna(current_close):
            return False

        bar_range = current_high - current_low
        if bar_range <= 0:
            return False

        close_position = (current_close - current_low) / bar_range
        return bool(close_position >= self.close_position_threshold)


class PriorRangePositionFilter(BaseFilter):
    """
    Require the prior close to already be positioned near the top of the
    recent range before the breakout.
    """

    name = "PriorRangePositionFilter"

    def __init__(self, lookback: int = 20, min_position_in_range: float = 0.65):
        self.lookback = lookback
        self.min_position_in_range = min_position_in_range

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback or i < 1:
            return False

        prior_window = data.iloc[i - self.lookback : i]
        if prior_window.empty:
            return False

        range_low = prior_window["low"].min()
        range_high = prior_window["high"].max()
        prior_close = data.iloc[i - 1]["close"]

        if pd.isna(range_low) or pd.isna(range_high) or pd.isna(prior_close):
            return False

        full_range = range_high - range_low
        if full_range <= 0:
            return False

        position_in_range = (prior_close - range_low) / full_range
        return bool(position_in_range >= self.min_position_in_range)


class MinimumBreakDistanceFilter(BaseFilter):
    """
    Require the breakout to clear the prior high by a minimum distance.
    """

    name = "MinimumBreakDistanceFilter"

    def __init__(self, lookback: int = 20, min_break_distance_points: float = 1.0):
        self.lookback = lookback
        self.min_break_distance_points = min_break_distance_points

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        prior_window = data.iloc[i - self.lookback : i]
        if prior_window.empty:
            return False

        prior_high = prior_window["high"].max()
        current_close = data.iloc[i]["close"]

        if pd.isna(prior_high) or pd.isna(current_close):
            return False

        break_distance = current_close - prior_high
        return bool(break_distance >= self.min_break_distance_points)


# ============================================================
# Mean-reversion-family filters
# ============================================================

class BelowFastSMAFilter(BaseFilter):
    """
    Current close must be below the fast SMA.

    Used as a simple 'price stretched below mean' condition for long-only
    mean reversion research.
    """

    name = "BelowFastSMAFilter"

    def __init__(self, fast_length: int = 20):
        self.fast_length = fast_length

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.fast_length:
            return False

        fast_col = f"sma_{self.fast_length}"

        if fast_col in data.columns:
            fast_sma = data.iloc[i][fast_col]
        else:
            close_series = data["close"]
            fast_sma = close_series.iloc[i - self.fast_length + 1 : i + 1].mean()

        current_close = data.iloc[i]["close"]

        if pd.isna(fast_sma) or pd.isna(current_close):
            return False

        return bool(current_close < fast_sma)


class DistanceBelowSMAFilter(BaseFilter):
    """
    Current close must be below the fast SMA by at least a minimum distance
    measured in points.

    This helps require a meaningful stretch rather than a tiny dip.
    """

    name = "DistanceBelowSMAFilter"

    def __init__(self, fast_length: int = 20, min_distance_points: float = 4.0):
        self.fast_length = fast_length
        self.min_distance_points = min_distance_points

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.fast_length:
            return False

        fast_col = f"sma_{self.fast_length}"

        if fast_col in data.columns:
            fast_sma = data.iloc[i][fast_col]
        else:
            close_series = data["close"]
            fast_sma = close_series.iloc[i - self.fast_length + 1 : i + 1].mean()

        current_close = data.iloc[i]["close"]

        if pd.isna(fast_sma) or pd.isna(current_close):
            return False

        distance_below = fast_sma - current_close
        return bool(distance_below >= self.min_distance_points)


class DownCloseFilter(BaseFilter):
    """
    Current close must be below previous close.

    This helps identify short-term downward pressure / weakness before
    mean reversion attempts.
    """

    name = "DownCloseFilter"

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < 1:
            return False

        current_close = data.iloc[i]["close"]
        previous_close = data.iloc[i - 1]["close"]

        if pd.isna(current_close) or pd.isna(previous_close):
            return False

        return bool(current_close < previous_close)


class TwoBarDownFilter(BaseFilter):
    """
    Require two consecutive down closes.

    This is a slightly stronger short-term exhaustion / weakness filter.
    """

    name = "TwoBarDownFilter"

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < 2:
            return False

        close_0 = data.iloc[i]["close"]
        close_1 = data.iloc[i - 1]["close"]
        close_2 = data.iloc[i - 2]["close"]

        if pd.isna(close_0) or pd.isna(close_1) or pd.isna(close_2):
            return False

        return bool(close_0 < close_1 and close_1 < close_2)


class ReversalUpBarFilter(BaseFilter):
    """
    Current close must be above the current open.

    Used as a simple reversal / snapback trigger for long-only
    mean reversion research.
    """

    name = "ReversalUpBarFilter"

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        current_open = data.iloc[i]["open"]
        current_close = data.iloc[i]["close"]

        if pd.isna(current_open) or pd.isna(current_close):
            return False

        return bool(current_close > current_open)


class LowVolatilityRegimeFilter(BaseFilter):
    """
    Average bar range must be below a maximum threshold.

    This can help identify calmer / more mean-reverting environments
    instead of high-volatility expansion environments.
    """

    name = "LowVolatilityRegimeFilter"

    def __init__(self, lookback: int = 20, max_avg_range: float = 12.0):
        self.lookback = lookback
        self.max_avg_range = max_avg_range

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.lookback:
            return False

        avg_range_col = f"avg_range_{self.lookback}"

        if avg_range_col in data.columns:
            avg_range = data.iloc[i][avg_range_col]
        else:
            window = data.iloc[i - self.lookback + 1 : i + 1]
            avg_range = (window["high"] - window["low"]).mean()

        if pd.isna(avg_range):
            return False

        return bool(avg_range <= self.max_avg_range)


class AboveLongTermSMAFilter(BaseFilter):
    """
    Current close must still be above a longer-term SMA.

    This is useful for 'buy the dip in broader uptrend' mean reversion,
    rather than catching falling knives in structural downtrends.
    """

    name = "AboveLongTermSMAFilter"

    def __init__(self, slow_length: int = 200):
        self.slow_length = slow_length

    def passes(self, data: pd.DataFrame, i: int) -> bool:
        if i < self.slow_length:
            return False

        slow_col = f"sma_{self.slow_length}"

        if slow_col in data.columns:
            slow_sma = data.iloc[i][slow_col]
        else:
            close_series = data["close"]
            slow_sma = close_series.iloc[i - self.slow_length + 1 : i + 1].mean()

        current_close = data.iloc[i]["close"]

        if pd.isna(slow_sma) or pd.isna(current_close):
            return False

        return bool(current_close > slow_sma)
```

---
#### modules/feature_builder.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

import pandas as pd


def add_precomputed_features(
    data: pd.DataFrame,
    sma_lengths: list[int] | None = None,
    avg_range_lookbacks: list[int] | None = None,
    momentum_lookbacks: list[int] | None = None,
) -> pd.DataFrame:
    """
    Add reusable precomputed feature columns to the OHLCV dataframe.

    This reduces repeated rolling calculations during:
    - filter combination sweeps
    - parameter refinement
    """

    df = data.copy()

    sma_lengths = sma_lengths or []
    avg_range_lookbacks = avg_range_lookbacks or []
    momentum_lookbacks = momentum_lookbacks or []

    # -----------------------------
    # Basic reusable columns
    # -----------------------------
    df["bar_range"] = df["high"] - df["low"]
    df["prev_close"] = df["close"].shift(1)

    # -----------------------------
    # SMA columns
    # -----------------------------
    for length in sma_lengths:
        col = f"sma_{length}"
        if col not in df.columns:
            df[col] = df["close"].rolling(length).mean()

    # -----------------------------
    # Average range columns
    # -----------------------------
    for lookback in avg_range_lookbacks:
        col = f"avg_range_{lookback}"
        if col not in df.columns:
            df[col] = df["bar_range"].rolling(lookback).mean()

    # -----------------------------
    # Momentum columns
    # -----------------------------
    for lookback in momentum_lookbacks:
        diff_col = f"mom_diff_{lookback}"
        if diff_col not in df.columns:
            df[diff_col] = df["close"] - df["close"].shift(lookback)

    return df
```

---
#### modules/engine.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd


@dataclass
class EngineConfig:
    # Global Presets from Master Prompt
    initial_capital: float = 250_000.0
    risk_per_trade: float = 0.01
    symbol: str = "ES"

    # Friction Assumptions
    commission_per_contract: float = 2.00
    slippage_ticks: int = 4
    tick_value: float = 12.50
    dollars_per_point: float = 50.0


@dataclass
class Trade:
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    direction: str
    entry_price: float
    exit_price: float
    contracts: int
    pnl: float
    bars_held: int
    exit_reason: str
    mae_points: float
    mfe_points: float


class MasterStrategyEngine:
    def __init__(self, data: pd.DataFrame, config: Optional[EngineConfig] = None):
        if data is None or data.empty:
            raise ValueError("Data is empty. Cannot initialize engine.")

        self.data = data.copy()
        self.config = config or EngineConfig()

        self.initial_capital = float(self.config.initial_capital)
        self.current_capital = float(self.config.initial_capital)
        self.risk_per_trade = float(self.config.risk_per_trade)

        self.position: Optional[dict] = None
        self.trades: list[Trade] = []
        self.equity_curve: list[dict] = []
        self.strategy_name: str = "UnknownStrategy"

    def calculate_position_size_contracts(
        self,
        stop_distance_points: float,
        dollars_per_point: Optional[float] = None,
    ) -> int:
        if dollars_per_point is None:
            dollars_per_point = self.config.dollars_per_point

        if stop_distance_points <= 0 or dollars_per_point <= 0:
            return 0

        risk_amount = self.current_capital * self.risk_per_trade
        contracts_float = risk_amount / (stop_distance_points * dollars_per_point)
        contracts = int(np.floor(contracts_float))

        return max(1, contracts) if contracts > 0 else 0

    def _close_position(
        self,
        exit_time: pd.Timestamp,
        exit_price: float,
        bars_held: int,
        exit_reason: str,
    ) -> None:
        entry_price = self.position["entry_price"]
        contracts = self.position["contracts"]

        gross_pnl = (exit_price - entry_price) * self.config.dollars_per_point * contracts
        commission_cost = contracts * self.config.commission_per_contract * 2.0
        net_pnl = gross_pnl - commission_cost

        self.current_capital += net_pnl

        trade = Trade(
            entry_time=self.position["entry_time"],
            exit_time=exit_time,
            direction="LONG",
            entry_price=entry_price,
            exit_price=exit_price,
            contracts=contracts,
            pnl=net_pnl,
            bars_held=bars_held,
            exit_reason=exit_reason,
            mae_points=float(self.position["mae_points"]),
            mfe_points=float(self.position["mfe_points"]),
        )
        self.trades.append(trade)
        self.position = None

    def _update_open_position_excursions(self, bar_low: float, bar_high: float) -> None:
        if self.position is None:
            return

        entry_price = self.position["entry_price"]

        adverse_excursion = bar_low - entry_price
        favorable_excursion = bar_high - entry_price

        self.position["mae_points"] = min(self.position["mae_points"], adverse_excursion)
        self.position["mfe_points"] = max(self.position["mfe_points"], favorable_excursion)

    def run(
        self,
        strategy,
        hold_bars: Optional[int] = None,
        stop_distance_points: Optional[float] = None,
    ) -> None:
        if len(self.data) < 2:
            raise ValueError("Not enough data to run backtest.")

        self.position = None
        self.trades = []
        self.equity_curve = []
        self.current_capital = float(self.initial_capital)
        self.strategy_name = getattr(strategy, "name", "UnknownStrategy")

        if hold_bars is None:
            hold_bars = getattr(strategy, "hold_bars", 3)

        if stop_distance_points is None:
            stop_distance_points = getattr(strategy, "stop_distance_points", 10.0)

        slippage_points = self.config.slippage_ticks * (
            self.config.tick_value / self.config.dollars_per_point
        )

        for i in range(len(self.data)):
            bar = self.data.iloc[i]
            timestamp = self.data.index[i]
            close_price = float(bar["close"])
            low_price = float(bar["low"])
            high_price = float(bar["high"])

            self.equity_curve.append(
                {
                    "datetime": timestamp,
                    "equity": self.current_capital,
                }
            )

            if self.position is not None:
                bars_held = i - self.position["entry_index"]

                self._update_open_position_excursions(
                    bar_low=low_price,
                    bar_high=high_price,
                )

                stop_price = self.position["stop_price"]

                if low_price <= stop_price:
                    stop_exit_price = stop_price - (slippage_points / 2.0)
                    self._close_position(
                        exit_time=timestamp,
                        exit_price=stop_exit_price,
                        bars_held=bars_held,
                        exit_reason="STOP",
                    )
                    continue

                if bars_held >= hold_bars:
                    time_exit_price = close_price - (slippage_points / 2.0)
                    self._close_position(
                        exit_time=timestamp,
                        exit_price=time_exit_price,
                        bars_held=bars_held,
                        exit_reason="TIME",
                    )
                    continue

            if self.position is None:
                signal = strategy.generate_signal(self.data, i)

                if signal == 1:
                    contracts = self.calculate_position_size_contracts(
                        stop_distance_points=stop_distance_points
                    )

                    if contracts > 0:
                        entry_price = close_price + (slippage_points / 2.0)
                        stop_price = entry_price - stop_distance_points

                        self.position = {
                            "entry_index": i,
                            "entry_time": timestamp,
                            "entry_price": entry_price,
                            "stop_price": stop_price,
                            "contracts": contracts,
                            "mae_points": 0.0,
                            "mfe_points": 0.0,
                        }

        if self.position is not None:
            final_bar = self.data.iloc[-1]
            final_time = self.data.index[-1]
            final_close = float(final_bar["close"])
            final_low = float(final_bar["low"])
            final_high = float(final_bar["high"])
            bars_held = len(self.data) - 1 - self.position["entry_index"]

            self._update_open_position_excursions(
                bar_low=final_low,
                bar_high=final_high,
            )

            final_exit_price = final_close - (slippage_points / 2.0)
            self._close_position(
                exit_time=final_time,
                exit_price=final_exit_price,
                bars_held=bars_held,
                exit_reason="FINAL_BAR",
            )

    def trades_dataframe(self) -> pd.DataFrame:
        if not self.trades:
            return pd.DataFrame()

        return pd.DataFrame(
            [
                {
                    "entry_time": t.entry_time,
                    "exit_time": t.exit_time,
                    "direction": t.direction,
                    "entry_price": t.entry_price,
                    "exit_price": t.exit_price,
                    "contracts": t.contracts,
                    "pnl": t.pnl,
                    "bars_held": t.bars_held,
                    "exit_reason": t.exit_reason,
                    "mae_points": t.mae_points,
                    "mfe_points": t.mfe_points,
                }
                for t in self.trades
            ]
        )

    def equity_curve_dataframe(self) -> pd.DataFrame:
        if not self.equity_curve:
            return pd.DataFrame()

        return pd.DataFrame(self.equity_curve)

    def _calculate_max_drawdown(self) -> float:
        equity_df = self.equity_curve_dataframe()
        if equity_df.empty or "equity" not in equity_df.columns:
            return 0.0

        running_peak = equity_df["equity"].cummax()
        drawdown = equity_df["equity"] - running_peak
        max_drawdown = float(drawdown.min())

        return max_drawdown

    def results(self) -> dict:
        total_pnl = self.current_capital - self.initial_capital
        total_trades = len(self.trades)

        gross_profit = sum(t.pnl for t in self.trades if t.pnl > 0)
        gross_loss = sum(t.pnl for t in self.trades if t.pnl < 0)
        net_pnl = gross_profit + gross_loss

        wins = sum(1 for t in self.trades if t.pnl > 0)
        losses = sum(1 for t in self.trades if t.pnl <= 0)
        win_rate = (wins / total_trades * 100.0) if total_trades > 0 else 0.0
        average_trade = (net_pnl / total_trades) if total_trades > 0 else 0.0

        if gross_loss != 0:
            profit_factor = gross_profit / abs(gross_loss)
        else:
            profit_factor = 0.0

        max_drawdown = self._calculate_max_drawdown()

        exit_reason_counts: dict[str, int] = {}
        for trade in self.trades:
            exit_reason_counts[trade.exit_reason] = exit_reason_counts.get(trade.exit_reason, 0) + 1

        average_mae = (
            sum(t.mae_points for t in self.trades) / total_trades
            if total_trades > 0
            else 0.0
        )
        average_mfe = (
            sum(t.mfe_points for t in self.trades) / total_trades
            if total_trades > 0
            else 0.0
        )

        return {
            "Strategy": self.strategy_name,
            "Symbol": self.config.symbol,
            "Initial Capital": f"${self.initial_capital:,.2f}",
            "Current Capital": f"${self.current_capital:,.2f}",
            "Net PnL": f"${total_pnl:,.2f}",
            "Gross Profit": f"${gross_profit:,.2f}",
            "Gross Loss": f"${gross_loss:,.2f}",
            "Average Trade": f"${average_trade:,.2f}",
            "Profit Factor": f"{profit_factor:.2f}",
            "Max Drawdown": f"${max_drawdown:,.2f}",
            "Average MAE (pts)": f"{average_mae:.2f}",
            "Average MFE (pts)": f"{average_mfe:.2f}",
            "Total Trades": total_trades,
            "Wins": wins,
            "Losses": losses,
            "Win Rate": f"{win_rate:.2f}%",
            "Exit Reasons": exit_reason_counts,
        }
```

---
#### modules/data_loader.py @ 3/13/2026, 1:03:30 PM
```python
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

def load_tradestation_csv(filepath: str | Path, debug: bool = True) -> pd.DataFrame:
    """
    Loads TradeStation CSV exports, handling custom date/time formats,
    cleaning string artifacts, and enforcing the 2008 backtest start date.
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"CSV not found: {filepath}")

    # Read as strings to control parsing
    df = pd.read_csv(filepath, dtype=str)

    # Clean column names (strip spaces and quotes)
    df.columns = [c.strip().strip('"').strip("'") for c in df.columns]

    required = {"Date", "Time", "Open", "High", "Low", "Close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}. Found: {list(df.columns)}")

    if debug:
        print("\n[LOADER DEBUG] Columns:", df.columns.tolist())

    # ---- Datetime parsing ----
    dt_text = df["Date"].astype(str).str.strip() + " " + df["Time"].astype(str).str.strip()

    dt_dayfirst = pd.to_datetime(dt_text, errors="coerce", dayfirst=True)
    dt_monthfirst = pd.to_datetime(dt_text, errors="coerce", dayfirst=False)

    nat_dayfirst = int(dt_dayfirst.isna().sum())
    nat_monthfirst = int(dt_monthfirst.isna().sum())

    # Choose the parse with fewer NaT (Not a Time)
    dt = dt_dayfirst if nat_dayfirst <= nat_monthfirst else dt_monthfirst

    # ---- Numeric helper ----
    def num(series: pd.Series) -> pd.Series:
        # strip quotes/spaces; remove commas
        x = (
            series.astype(str)
            .str.replace('"', "", regex=False)
            .str.replace(",", "", regex=False)
            .str.strip()
        )
        return pd.to_numeric(x, errors="coerce")

    open_ = num(df["Open"])
    high_ = num(df["High"])
    low_ = num(df["Low"])
    close_ = num(df["Close"])

    if "Volume" in df.columns:
        vol = num(df["Volume"]).fillna(0)
    elif "Up" in df.columns and "Down" in df.columns:
        vol = (num(df["Up"]).fillna(0) + num(df["Down"]).fillna(0))
    else:
        vol = pd.Series(np.zeros(len(df)), index=df.index)

    # ---- Construct DataFrame (Using .values to fix the index alignment bug) ----
    out = pd.DataFrame(
        {
            "open": open_.values, 
            "high": high_.values, 
            "low": low_.values, 
            "close": close_.values, 
            "volume": vol.values
        },
        index=dt,
    )
    out.index.name = "datetime"

    # ---- Clean and Filter ----
    out = out[~out.index.isna()]  # drop NaT datetimes
    out = out.dropna(subset=["open", "high", "low", "close"])  # drop bad OHLC rows
    out = out.sort_index()
    out = out[~out.index.duplicated(keep="last")]

    # Master Prompt Enforcement: Start Date 01 January 2008
    out = out.loc["2008-01-01":]

    if debug:
        print(f"[LOADER DEBUG] Final rows after cleaning and filtering: {len(out):,}")

    return out
```

---
