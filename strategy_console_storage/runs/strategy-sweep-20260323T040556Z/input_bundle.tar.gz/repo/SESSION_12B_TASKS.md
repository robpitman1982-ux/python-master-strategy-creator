SESSION 12A — Cloud Runner Stability Fixes

Goal:
Make the GCP cloud launcher fully automatic and remove manual VM intervention.

Required fixes:

1) Fix CRLF runner script bug
Ensure remote_runner.sh is always written with Unix LF line endings.

Implementation:
open(file, "w", newline="\n")

2) Strip hidden carriage returns from run_id
Apply .strip() to run_id and any remote path components to prevent duplicate directories like:
strategy-sweep-...$'\r'

3) Improve SSH execution confirmation
Ensure the launcher verifies remote_runner.sh started successfully before exiting.

4) Automatically execute runner with correct argument
Launcher must run:

bash remote_runner.sh <run_root>

5) Improve runner logging
Ensure logs always capture:
runner.log
runner_stdout.log
engine_run.log

Acceptance Criteria:

Cloud run works from a single command:

python -m cloud.launch_gcp_run --config cloud/config_es_all_timeframes_gcp96.yaml

No manual SSH intervention required.
No CRLF errors.
No duplicate run folders.
Logs and artifacts generated automatically.