# SESSION 21 TASKS — Post-Debugging Cleanup & Infrastructure Hardening

> **Context**: Session 20 (Codex) attempted to fix dataset path resolution and push to cloud.
> This session (Claude.ai + manual debugging) discovered the real blockers:
> 1. Strategy-console VM had insufficient auth scopes (could not create/manage other VMs)
> 2. DEFAULT_ZONE was australia-southeast2-a (no SPOT capacity + poor pricing)
> 3. run_cloud_sweep.py prints misleading stage labels before launcher actually runs
> 4. CLAUDE.md and CHANGELOG_DEV.md not updated since Session 14
> 5. GitHub Actions deploy workflow exists but has no SSH secrets configured
> 6. Junk file in repo root: `ersRobDocumentsGIT Repospython-master-strategy-creator`
> 7. QUICKFIX_TASKS.md is stale (bug was already fixed)
>
> **Auth scopes were fixed manually via GCP Cloud Shell (not code).**
> **DEFAULT_ZONE was changed manually on the VM via python3 one-liner.**
> **These code changes need to be committed properly.**

Read CLAUDE.md and CHANGELOG_DEV.md first. Then work through all steps in order.
Commit after each step.

---

## Step 1: Commit the DEFAULT_ZONE change

Change `cloud/launch_gcp_run.py` line 28:
```python
DEFAULT_ZONE = "us-central1-a"
```
Also make zone configurable from the YAML config so it doesn't need a code change:
- In `cloud/launch_gcp_run.py`, after loading config, check for `cloud.zone` in the config dict
- If present, use it; otherwise fall back to DEFAULT_ZONE
- Update `cloud/config_quick_test.yaml` to include:
```yaml
cloud:
  zone: "us-central1-a"
  machine_type: "n2-highcpu-96"
  provisioning_model: "SPOT"
  boot_disk_size: "120GB"
  image_family: "ubuntu-2404-lts-amd64"
```
- Update `cloud/config_es_all_timeframes_gcp96.yaml` similarly

This means zone/machine changes never require editing Python code again.

**Commit**: `feat: make cloud zone/machine configurable via YAML, default to us-central1-a`

---

## Step 2: Fix misleading wrapper prints in run_cloud_sweep.py

Current `run_cloud_sweep.py` prints "VM LAUNCHING", "UPLOAD START", "SWEEP START", "DOWNLOAD COMPLETE", "VM DESTROY" unconditionally BEFORE and AFTER `launcher_main()` runs. This is misleading because:
- During dry runs, it prints "SWEEP START" even though no sweep happens
- If the launcher fails early, it still prints "DOWNLOAD COMPLETE" and "VM DESTROY"

Fix: Remove all the hardcoded stage prints. The launcher itself already prints proper status.
The wrapper should only print:
- The config being used (before launcher)
- A brief "Launcher finished with exit code X" (after launcher)

```python
def main(argv: list[str] | None = None) -> int:
    args, passthrough = parse_args(argv)
    launcher_argv = build_launcher_argv(args, passthrough)
    print(f"Starting sweep with config: {args.config}")
    if args.dry_run:
        print("Mode: DRY RUN (no VM will be created)")
    exit_code = launcher_main(launcher_argv)
    print(f"Launcher finished with exit code: {exit_code}")
    return exit_code
```

**Commit**: `fix: remove misleading stage labels from run_cloud_sweep.py wrapper`

---

## Step 3: Add STRATEGY_CONSOLE_STORAGE auto-detection

Currently the user must remember to set the env var:
```
STRATEGY_CONSOLE_STORAGE=/home/robpitman1982/strategy_console_storage
```

Fix: In `paths.py` and/or `cloud/launch_gcp_run.py`, auto-detect if running on the strategy-console:
- If `~/strategy_console_storage` exists, use it automatically
- If env var is set, use that (override)
- If neither, fall back to repo-relative paths

The user should be able to just run:
```
python3 run_cloud_sweep.py --config cloud/config_quick_test.yaml
```
without the env var prefix.

**Commit**: `feat: auto-detect strategy_console_storage path`

---

## Step 4: Clean up repo junk

- Delete `ersRobDocumentsGIT Repospython-master-strategy-creator` from repo root (this is a Windows path artifact)
- Delete `QUICKFIX_TASKS.md` (the accepted_final bug was already fixed)
- Delete `germin code for project.rtf` if it's no longer needed (check with Rob first — if unsure, leave it)
- Delete `full_project_context.txt` if it's stale/outdated (check with Rob first)

**Commit**: `chore: remove stale files and artifacts from repo root`

---

## Step 5: Set up GitHub Actions auto-deploy

Create/fix `.github/workflows/deploy_strategy_console.yml` to:
1. Trigger on push to `main`
2. SSH into the strategy-console VM
3. Run `cd ~/python-master-strategy-creator && git pull`
4. Run `pip install -r requirements.txt --quiet` (only if requirements changed)
5. Restart the dashboard service: `sudo systemctl restart strategy-dashboard`

Requirements:
- GitHub repository secret: `GCP_SSH_PRIVATE_KEY` — the private key for SSH access
- GitHub repository secret: `GCP_CONSOLE_IP` — the external IP of strategy-console (currently 35.232.131.181, but should be a static IP)
- The workflow should use `appleboy/ssh-action@v1` or similar

**Important**: The workflow needs the strategy-console to have a **static IP**. Add a note in the workflow file that `GCP_CONSOLE_IP` must be updated if the VM's IP changes, or ideally Rob should reserve a static IP first (instructions below).

**Static IP setup (manual, not automated — add as comment in workflow)**:
```bash
# Run from GCP Cloud Shell:
gcloud compute addresses create strategy-console-ip --region=us-central1
gcloud compute instances delete-access-config strategy-console --zone=us-central1-c --access-config-name="External NAT"
gcloud compute instances add-access-config strategy-console --zone=us-central1-c --address=$(gcloud compute addresses describe strategy-console-ip --region=us-central1 --format="get(address)")
```

**Commit**: `feat: add GitHub Actions auto-deploy workflow for strategy console`

---

## Step 6: Update CLAUDE.md

Update the following sections:

### Repository structure
- Add `paths.py` to the tree
- Add `scripts/run_console_job.py` if it exists
- Update cloud/ section to reflect new YAML-configurable zone/machine

### Known issues — mark as FIXED
- Auth scopes on strategy-console VM (fixed manually via Cloud Shell)
- DEFAULT_ZONE was hardcoded to Australia (now configurable via YAML)
- run_cloud_sweep.py misleading prints (fixed)
- Dataset path resolution (fixed in Session 20 / commit 76dd69a)

### Known issues — add NEW
- Dashboard LargeUtf8 Arrow decoding error (Parquet viewer can't read newer pyarrow format)
- Python 3.14 on console VM causes numpy issues (dashboard venv unhealthy)
- No static IP on strategy-console (IP changes on restart)
- status.json first-update delay (fix: change `if done % step == 0` to `if done == 1 or done % step == 0`)

### Current deployment
Add a new section:
```
## Deployment

**Strategy Console**: GCP e2-micro, us-central1-c, IP: [check current]
**Compute VMs**: n2-highcpu-96 SPOT, us-central1-a (configurable via YAML)
**GitHub Actions**: auto-deploy on push to main
**Dashboard**: Streamlit on port 8501, systemd service `strategy-dashboard`
```

### Last updated
Change to: `2026-03-23 — Session 21: Infrastructure hardening, US region migration, auth fix, auto-deploy`

**Commit**: `docs: update CLAUDE.md for Session 21`

---

## Step 7: Update CHANGELOG_DEV.md

Add Session 21 entry at the TOP with:

**What was done**:
- Fixed strategy-console VM auth scopes (ACCESS_TOKEN_SCOPE_INSUFFICIENT) — resolved via GCP Cloud Shell `set-service-account --scopes=cloud-platform`
- Migrated DEFAULT_ZONE from australia-southeast2-a to us-central1-a for better SPOT pricing and availability
- Made cloud zone/machine_type configurable via YAML config (no more Python edits for region changes)
- Fixed misleading stage labels in run_cloud_sweep.py wrapper
- Added auto-detection of strategy_console_storage path
- Cleaned up stale repo files (QUICKFIX_TASKS.md, Windows path artifact)
- Set up GitHub Actions auto-deploy workflow
- Updated CLAUDE.md with current deployment architecture
- Authenticated strategy-console gcloud CLI with personal account (bypasses service account scope issues)

**Key discoveries**:
- The failed run (strategy-sweep-20260322T200637Z) was caused by insufficient VM auth scopes, not quota or code issues
- N2 CPU quotas are already 200 in us-central1, us-east1, us-east4, us-east5, us-south1, us-west4
- General CPU quota in us-central1 is 200 (199 available)
- SPOT pricing in US regions is significantly cheaper than Australia

**Verified**:
- Dry run passes with us-central1-a zone
- Dataset resolution from uploads/ directory works correctly
- gcloud auth working on strategy-console after personal login

**Next session priorities**:
1. Confirm quick test run completed successfully with real results
2. Run full ES 60m sweep across all strategy families
3. Run multi-timeframe sweep (daily, 60m, 30m, 15m)
4. Fix dashboard LargeUtf8 Arrow error
5. Reserve static IP for strategy-console
6. Begin multi-region parallel sweep architecture

**Commit**: `docs: add Session 21 changelog entry`

---

## Step 8: Run smoke tests

```bash
python -m pytest tests/test_smoke.py -v
```

If there are launcher tests:
```bash
python -m pytest tests/ -v
```

All tests must pass. Fix any failures before pushing.

**Commit** (only if fixes needed): `fix: resolve test failures from Session 21 changes`

---

## Step 9: Push to GitHub

```bash
git push origin main
```

Verify GitHub Actions workflow triggers and check its status.

---

## POST-SESSION: Manual steps for Rob

These cannot be done by Claude Code and need to be done manually:

1. **Reserve static IP** (from GCP Cloud Shell):
```bash
gcloud compute addresses create strategy-console-ip --region=us-central1
gcloud compute instances delete-access-config strategy-console --zone=us-central1-c --access-config-name="External NAT"
gcloud compute instances add-access-config strategy-console --zone=us-central1-c --address=$(gcloud compute addresses describe strategy-console-ip --region=us-central1 --format="get(address)")
```

2. **Add GitHub secrets** for auto-deploy:
   - Go to repo → Settings → Secrets → Actions
   - Add `GCP_CONSOLE_IP`: the static IP from step 1
   - Add `GCP_SSH_PRIVATE_KEY`: generate a new key pair, add public key to strategy-console's `~/.ssh/authorized_keys`

3. **Check run results**: 
```bash
ls ~/strategy_console_storage/runs/strategy-sweep-*/
```
   Look for the latest run with actual result CSVs.

4. **Submit N2 CPU quota increase for us-west1** (currently 100, request 200) if you want a second parallel region.
