SESSION_16_TASKS.md

Strategy Engine — Control Plane Hardening

Objective

Stabilize and operationalize the strategy-console control VM so the monitoring dashboard and repo updates behave like a proper service.

This session must accomplish four things:

Make the dashboard environment reproducible
Run the dashboard as a persistent system service
Create a safe GitHub deploy/update workflow
Improve launcher clarity when runs fail or VMs are preserved

The goal is that the control plane becomes stable infrastructure before scaling strategy sweeps.

Current Architecture (Important Context)

The project currently runs like this:

Local machine
↓
run_cloud_sweep.py
↓
cloud/launch_gcp_run.py
↓
GCP compute VM launches
↓
Strategy engine runs remotely
↓
Outputs bundle returned
↓
Results saved under

cloud_results/

The strategy-console VM hosts:

dashboard.py

Which reads launcher outputs and displays run status.

The dashboard currently works but has problems:

• dependencies are not pinned
• Python version compatibility issues occurred
• Altair / imghdr patching required
• dashboard not running as service
• repo updates require manual restart

Session 16 fixes this.

Task 1 — Stabilize Dashboard Environment

Update requirements.txt to ensure reproducibility.

Target Python compatibility: 3.11 or 3.12

Add explicit pins.

Example target versions (adjust if needed for compatibility):

numpy==2.1.4
pandas==2.2.2
pyyaml==6.0.2

streamlit==1.37.1
plotly==5.23.0
altair==5.3.0

Ensure the environment installs cleanly on:

Ubuntu 24.04
Python 3.11+

Remove ambiguous dependency behaviour.

Acceptance criteria:

pip install -r requirements.txt

must succeed with no manual patching.

Task 2 — Add Dashboard Launch Script

Create a helper script:

scripts/start_dashboard.sh

Content:

#!/bin/bash
set -e

cd ~/python-master-strategy-creator

source venv/bin/activate

exec streamlit run dashboard.py \
    --server.port 8501 \
    --server.address 0.0.0.0

Make executable.

Task 3 — Add Systemd Service

Create:

/etc/systemd/system/strategy-dashboard.service

Service file:

[Unit]
Description=Strategy Engine Dashboard
After=network.target

[Service]
User=root
WorkingDirectory=/root/python-master-strategy-creator
ExecStart=/root/python-master-strategy-creator/scripts/start_dashboard.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target

Enable the service.

systemctl daemon-reload
systemctl enable strategy-dashboard
systemctl start strategy-dashboard

Acceptance criteria:

Dashboard starts automatically on reboot.

Task 4 — Add Repo Deploy Script

Create:

scripts/update_console.sh

Purpose: update strategy-console after a GitHub push.

Script behaviour:

#!/bin/bash
set -e

cd ~/python-master-strategy-creator

echo "Pulling latest repo..."
git pull origin main

echo "Updating environment..."
source venv/bin/activate
pip install -r requirements.txt

echo "Restarting dashboard..."
systemctl restart strategy-dashboard

echo "Done."
git rev-parse HEAD

Acceptance criteria:

Running

./scripts/update_console.sh

updates the repo and restarts the dashboard safely.

Task 5 — Improve Launcher Final Status Messaging

Improve terminal clarity in:

cloud/launch_gcp_run.py

When a run ends, output a clear block such as:

=============================
STRATEGY ENGINE RUN COMPLETE
=============================

Run ID: XXXXX
Artifacts downloaded: YES
Artifacts verified: YES

VM outcome: vm_destroyed
Billing stopped: YES

Results location:
cloud_results/<run_id>/Outputs

If VM preserved:

VM outcome: vm_preserved
Destroy manually if finished.

If failure:

RUN STATUS: FAILED
Artifacts incomplete
Inspect logs in:
cloud_results/<run_id>

This improves operator clarity.

Task 6 — Dashboard Status Enhancements

Add to dashboard display:

• current git commit hash
• last dashboard restart time
• machine hostname

Useful for identifying which VM is running the console.

Example additions:

import subprocess
commit = subprocess.check_output(["git","rev-parse","HEAD"]).decode().strip()

Display in sidebar.

Deliverables

The following files must be created or updated.

New:

scripts/start_dashboard.sh
scripts/update_console.sh

New system service:

strategy-dashboard.service

Modified:

requirements.txt
dashboard.py
cloud/launch_gcp_run.py
Acceptance Criteria

After Session 16:

1️⃣ strategy-console dashboard auto-starts on reboot
2️⃣ dashboard environment installs without manual patching
3️⃣ repo updates deploy with one script
4️⃣ launcher prints clear run completion status
5️⃣ dashboard shows commit + machine info

Out of Scope (Future Sessions)

Not part of Session 16:

• distributed worker fleets
• multi-VM sweeps
• cost optimization
• job queues

Those will come in later sessions.

Operator Workflow After Session 16

Normal run workflow:

Run engine:

python run_cloud_sweep.py --config <config>

Monitor:

http://strategy-console:8501

Update dashboard after code changes:

ssh strategy-console
./scripts/update_console.sh
End of Session 16 Tasks