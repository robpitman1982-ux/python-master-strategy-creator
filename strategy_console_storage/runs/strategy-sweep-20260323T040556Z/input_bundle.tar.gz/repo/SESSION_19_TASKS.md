ESSION_19_TASKS.md

Strategy Console — Final Cleanup, Production Wiring, and Test-Run Readiness

Objective

Do a final cleanup pass so the strategy-console environment is ready for a real overnight validation run.

This session must:

clean up remaining dashboard / deploy inconsistencies
make sure the storage layout is the true source of truth
make the auto-deploy workflow production-ready
make tonight’s test run easy to launch and easy to verify afterward

This is a stabilization and readiness session, not a scaling session.

Current State

Session 18 has already landed:

storage-aware dashboard console
deploy workflow in GitHub Actions
improved deploy scripts
dataset / run / export discovery helpers
leaderboard preview
WinSCP upload flow working to:
~/strategy_console_storage/uploads
~/strategy_console_storage/runs
~/strategy_console_storage/exports
~/strategy_console_storage/backups

There are still a few things to clean up before a real overnight run:

ensure scripts and dashboard use the same storage assumptions everywhere
verify service/deploy path is fully consistent
reduce operator friction for run launch and post-run verification
make “tonight test run” a clean documented workflow
Task 1 — Audit and Normalize Storage Paths

Do a repo-wide audit for any remaining hardcoded references to:

cloud_results
repo-local Outputs
repo-local ad hoc data paths

Normalize path handling so the intended production layout is:

~/strategy_console_storage/
    uploads/
    runs/
    exports/
    backups/

Requirements:

code should prefer storage-aware paths where appropriate
legacy paths may still be supported as fallback, but should not be the primary console path
avoid scattering path literals in UI code

Acceptance criteria:

dashboard and helpers consistently understand storage-root layout
no confusing mixed-source behavior for normal console usage
Task 2 — Make Run Output Landing Zone Explicit

Right now users can upload datasets to uploads/, but completed runs also need a clear, standard landing area.

Implement or document a standard convention so completed launcher runs can be copied or surfaced under:

~/strategy_console_storage/runs/

If code changes are needed, add a helper or post-run sync step that makes the latest completed run visible there cleanly.

Requirements:

each run should have a stable run folder
dashboard should browse those folders consistently
operator should not need to hunt through multiple directories

Acceptance criteria:

completed runs appear in one obvious place
dashboard run history reflects that place cleanly
Task 3 — Finalize start_dashboard.sh and update_console.sh

Audit both scripts for production use.

start_dashboard.sh

Ensure it:

activates venv
starts Streamlit with:
--server.port 8501
--server.address 0.0.0.0
exits cleanly on failure
uses exec
update_console.sh

Ensure it:

pulls latest code
activates venv
installs requirements
restarts dashboard service
prints commit hash
prints a short success/failure summary

Also make sure it does not fail silently.

Acceptance criteria:

these scripts are usable as the canonical deploy/update interface
Task 4 — Harden GitHub Auto-Deploy Workflow

Review .github/workflows/deploy_strategy_console.yml.

Ensure:

required secrets are clearly documented
SSH setup is robust
failure logs are readable
deploy step calls the canonical update script only
workflow is minimal and predictable

Add a short markdown note in repo comments or workflow comments listing required secrets:

STRATEGY_CONSOLE_HOST
STRATEGY_CONSOLE_USER
STRATEGY_CONSOLE_PORT
STRATEGY_CONSOLE_SSH_KEY

Acceptance criteria:

push to main should be enough to update strategy-console
workflow should be understandable at a glance
Task 5 — Add “Tonight Test Run” Operator Section to Dashboard

Add a small operator-focused panel to the dashboard that surfaces the essentials for a validation run.

Example information to show:

selected dataset
selected latest run
latest run outcome
billing status
operator action
path to uploads folder
path to runs folder
path to exports folder

Optional but useful:

a “Test Run Checklist” section in the dashboard sidebar or main panel

Example checklist:

dataset uploaded
dashboard reachable
latest code deployed
latest commit visible
VM billing state understood
recovery commands available if needed

Acceptance criteria:

operator can glance at dashboard and know whether system is ready for tonight’s run
Task 6 — Add a Simple Test-Run Readiness Helper

Create a small helper function or section that determines whether the environment looks ready for a test run.

Possible inputs:

uploads folder exists
at least one dataset exists
dashboard storage paths resolve correctly
latest run metadata can be read
required directories exist

Return a simple readiness state:

ready
partially ready
not ready

Surface this in dashboard.

Acceptance criteria:

dashboard provides a simple readiness signal instead of just raw file listings
Task 7 — Add a Lightweight Launch Note / Operator Doc

Create a small markdown doc in the repo, for example:

docs/TEST_RUN_CHECKLIST.md

Include:

how to upload a dataset with WinSCP
how to verify dashboard is live
how to verify latest code is deployed
how to launch tonight’s run
where outputs should appear
how to verify whether billing stopped afterward
what to do if VM is preserved

Keep it short and operator-friendly.

Acceptance criteria:

one concise document exists for the real overnight test workflow
Task 8 — Clean Up Any Session 16–18 Residue

Do a tidy pass for obvious leftovers:

duplicate helper logic
stale comments that no longer match current behavior
path assumptions that were superseded
UI text that still refers only to cloud_results when storage-aware behavior exists

Do not over-refactor. Just remove obvious inconsistencies.

Acceptance criteria:

repo feels coherent after Sessions 16–18
operator-facing wording matches actual behavior
Task 9 — Validation

Run targeted checks:

python -m py_compile dashboard.py dashboard_utils.py
dashboard helper tests
any focused tests relevant to deploy/storage helpers

Do not spend the session trying to fully solve unrelated Windows temp-dir pytest issues unless directly required.

Acceptance criteria:

changed files validate cleanly
session ends with a clear statement of what is ready for tonight’s run
Files Likely To Change

Primary:

dashboard.py
dashboard_utils.py
scripts/start_dashboard.sh
scripts/update_console.sh
.github/workflows/deploy_strategy_console.yml

New:

docs/TEST_RUN_CHECKLIST.md

Possibly:

launcher helper path logic if needed for storage consistency
relevant tests
Acceptance Criteria

After Session 19:

dashboard/storage/deploy behavior is internally consistent
strategy-console is ready for an overnight test run
dashboard clearly shows readiness / operator status
auto-deploy workflow is production-ready
run outputs have one obvious home
a short test-run checklist doc exists
Out of Scope

Not part of Session 19:

multi-VM scaling
region hunting
queue systems
strategy logic redesign
major new launcher architecture
Operator Goal After Session 19

Tonight, the operator should be able to:

upload dataset with WinSCP
confirm dashboard is live
confirm latest code is deployed
launch one real test run
monitor run state and billing state
know exactly where results should land
know exactly what to do if VM is preserved

with minimal guesswork.