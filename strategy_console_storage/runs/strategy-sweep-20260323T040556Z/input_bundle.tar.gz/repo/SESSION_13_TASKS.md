# SESSION 13 TASKS — Dashboard Upgrade + VM Cost Visibility

## Goal

Turn `dashboard.py` into a genuinely useful **operations + research control panel** for the strategy engine.

This session is about **visibility, usability, and cost awareness**.

The launcher is now close to stable enough for real overnight use. The next bottleneck is that the dashboard does not yet tell the user enough about:

- what the current run is doing
- whether the VM is still alive and costing money
- what progress has been made so far
- what results are already available
- which candidates look best during or after a run

This session should make the dashboard feel like a **mini quant research control room**, not just a file browser.

---

## Non-goals

Do **not** change strategy logic.

Do **not** modify `master_strategy_engine.py` unless absolutely necessary for compatibility.

Prefer changes in:

- `dashboard.py`
- lightweight helper module(s) if needed
- launcher status interpretation
- optional small support helpers/tests
- docs/changelog if dashboard capabilities materially change

---

## Main objectives

### 1. Upgrade Cloud Monitor into a real live control panel

The Cloud Monitor view should clearly surface, for the selected run:

- `run_id`
- current launcher `state`
- current `stage`
- current `message`
- `updated_utc`
- instance name
- zone
- VM outcome
- run outcome
- bundle size
- local results directory
- remote run root

Use a strong visual hierarchy at the top:
- large top summary area
- clean metric cards
- readable values
- avoid truncated cryptic labels like `VM_PRESE...`

If multiple runs exist in `cloud_results/`:
- default to the newest run
- sort newest first
- clearly label which runs are:
  - running
  - completed
  - preserved
  - failed
  - dry-run only

---

### 2. Add a VM cost meter / cost awareness panel

Add a visible **estimated cost section** to Cloud Monitor.

This does **not** need exact GCP billing integration yet.
A practical estimate is enough.

At minimum:
- detect machine type from launcher/run metadata where possible
- detect provisioning model if available
- infer elapsed runtime from launcher timestamps
- estimate hourly cost using a simple local mapping table
- estimate total run cost so far

Show something like:
- machine type
- provisioning mode (Spot / Standard if known)
- elapsed runtime
- estimated hourly rate
- estimated total cost so far
- VM still accruing cost? Yes / No

Important:
- If VM is preserved / destroy skipped / not confirmed destroyed:
  show a prominent warning banner such as:

  **⚠ VM may still be running and billing may still be active**

- If VM is destroyed:
  show a green confirmation such as:

  **✅ VM destroyed — billing should have stopped**

Implementation notes:
- Use a small local pricing map initially (for example keyed by machine type)
- Make it obvious that this is an estimate
- Keep it maintainable and easy to update later

---

### 3. Show live per-dataset progress properly

Improve dataset progress display so each dataset card shows:
- dataset name
- market
- timeframe
- current family
- current stage
- progress %
- ETA
- elapsed
- completed families
- remaining families

If dataset `status.json` files are not yet available:
- show a clear “waiting for dataset progress files” message
- do not leave the user with an empty-feeling screen

Add an overall progress section if inferable:
- completed datasets / total datasets
- currently active dataset
- total completed families across datasets
- total remaining families across datasets

---

### 4. Add a “Best Candidates So Far” panel

If result files exist for the selected run, show a prominent panel for best candidates discovered so far.

Look for files such as:
- `master_leaderboard.csv`
- `family_leaderboard_results.csv`
- `family_summary_results.csv`

Display a compact, readable table using the most useful columns available, such as:
- rank
- market
- timeframe
- strategy_type
- leader_strategy_name
- leader_pf
- oos_pf
- recent_12m_pf
- leader_trades
- leader_net_pnl
- quality_flag

This panel should work:
- after run completion
- and, if partial files already exist, during a run

This should become the first place the user looks when checking whether a run is promising.

---

### 5. Make Results Explorer much more guided

Right now Results Explorer feels too much like “pick a folder and hope.”

Improve it so it:
- groups result sources into logical categories:
  - current `cloud_results` runs
  - legacy `cloud_outputs*`
  - local `Outputs/...`
- defaults to the newest `cloud_results` run that has extracted artifacts
- shows a short summary for the selected result set:
  - run id
  - config
  - launcher state
  - updated time
  - artifact extraction present or not
  - VM outcome

Also clearly indicate whether these files are found:
- `master_leaderboard.csv`
- `portfolio_review_table.csv`
- `correlation_matrix.csv`
- `yearly_stats_breakdown.csv`
- `strategy_returns.csv`

If files are missing, explain that cleanly rather than just leaving a blank section.

---

### 6. Improve Prop Firm Simulator integration

Make Prop Firm Simulator feel connected to the rest of the app.

Requirements:
- default to the same selected results directory as Results Explorer if available
- show a small summary of the chosen data source
- show how many strategy return columns were found
- display clearer feedback if there are too few trades
- show a clearer explanation if `strategy_returns.csv` is absent
- reduce the feeling that the user is “starting over” when switching tabs

Do not overcomplicate the simulator logic itself in this session.
Focus on usability and integration.

---

### 7. Better dashboard status badges and banners

Add readable badges / indicators for launcher states and outcomes.

Examples:
- 🟢 `run_completed_verified`
- 🟡 `run_completed_unverified`
- 🔴 `remote_failed_artifacts_preserved`
- ⚪ `dry_run_complete`
- 🟠 `vm_preserved_for_inspection`
- ✅ `vm_destroyed`

Also add obvious banners for:
- VM still preserved / possible ongoing billing
- dry-run mode
- completed verified
- completed but not fully verified
- remote failure with artifacts preserved

The user should not need to interpret raw state strings mentally.

---

### 8. Improve readability and layout

Make the dashboard cleaner and easier to scan.

Guidelines:
- clearer section headers
- better metric labels
- less truncation
- concise captions
- practical layout over flashy styling
- keep Streamlit structure simple and maintainable

Avoid a huge CSS/style rabbit hole.
Use native Streamlit components well.

---

### 9. Add lightweight helpers if useful

If `dashboard.py` becomes too large, split small pure helper functions into something like:

- `dashboard_utils.py`

Only do this if it genuinely improves maintainability.

Do not over-architect.

---

### 10. Add tests where reasonable

Add fast local-only tests for helper logic if practical, such as:
- launcher run discovery ordering
- result source grouping logic
- cost-estimate helper logic
- selected run/result summary extraction
- best-candidate source detection
- status badge / state mapping helpers

Do **not** try to test full Streamlit rendering.
Keep tests lightweight and useful.

---

## Launcher / status compatibility

If small changes to launcher status fields would significantly improve the dashboard, they are allowed, but:
- keep them backward-compatible where reasonable
- do not break the launcher flow
- do not change core engine logic

If needed, make sure `launcher_status.json` consistently preserves fields needed for the dashboard:
- run_id
- state
- stage
- message
- updated_utc
- instance_name
- zone
- local_results_dir
- remote_run_root
- bundle_size_bytes
- run_outcome
- vm_outcome
- created_utc

---

## Acceptance criteria

1. Cloud Monitor clearly shows what the current or selected run is doing.
2. The dashboard shows whether the VM may still be billing.
3. An estimated cost meter is visible for the selected run.
4. Dataset-level progress is useful when available and clearly explained when not yet available.
5. A “Best Candidates So Far” panel appears when leaderboard files exist.
6. Results Explorer defaults intelligently and is easier to navigate.
7. Prop Firm Simulator feels connected to the selected run/results.
8. Status badges and banners make launcher outcomes obvious.
9. Existing dashboard functionality is preserved.
10. No core strategy logic is changed.

---

## Deliverables

- updated `dashboard.py`
- optional helper module if useful
- any lightweight supporting tests
- update `CHANGELOG_DEV.md`
- update `CLAUDE.md` if dashboard capabilities changed materially

---

## Final verification

Run:

```bash
python -m py_compile dashboard.py
python -m pytest tests/test_smoke.py tests/test_cloud_launcher.py -v --basetemp=.tmp_pytest_run