# SESSION 3: Cloud deployment (DigitalOcean)

Read CLAUDE.md and CHANGELOG_DEV.md first for full project context.

This session prepares the pipeline for cloud execution on DigitalOcean Droplets.
The goal: one command to spin up a droplet, run the full pipeline, download
results, and destroy the droplet. Pay only for compute time.

This session has 6 steps. Work through them in order. Git commit after each step.

---

## STEP 1: Create Dockerfile

The Docker image packages the entire pipeline so it runs identically on any machine.

### 1a. Create `Dockerfile` in the project root

```dockerfile
FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies (needed for numpy/pandas compilation on slim)
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first (for Docker layer caching)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY modules/ modules/
COPY master_strategy_engine.py .
COPY config.yaml .
COPY run_evaluator.py .

# Data directory will be mounted at runtime
RUN mkdir -p /app/Data /app/Outputs

# Default command
CMD ["python", "master_strategy_engine.py"]
```

### 1b. Create `requirements.txt` in the project root

```txt
numpy>=1.24.0
pandas>=2.0.0
pyyaml>=6.0
```

### 1c. Create `.dockerignore` in the project root

```
.git/
__pycache__/
*.pyc
Data/
Outputs/
.claude/
*.rtf
*.md
!CLAUDE.md
paste.md
full_project_context.txt
project_to_text.py
SESSION_*_TASKS.md
.vscode/
```

**Git commit**: `build: add Dockerfile, requirements.txt, and .dockerignore`

---

## STEP 2: Create cloud run script

This is the script that automates the full cloud workflow:
upload data -> run pipeline -> download results -> clean up.

### 2a. Create `cloud/run_cloud.sh` in the project root

```bash
#!/bin/bash
# =============================================================
# Cloud Pipeline Runner for DigitalOcean
# Usage: ./cloud/run_cloud.sh [config_override.yaml]
# =============================================================

set -e

# --- Configuration ---
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DROPLET_NAME="strategy-engine-$(date +%Y%m%d-%H%M)"
DROPLET_SIZE="c-8"          # 8 vCPU dedicated, ~$0.095/hr
DROPLET_REGION="sgp1"       # Singapore (closest to Melbourne)
DROPLET_IMAGE="docker-24-04" # Ubuntu 24.04 with Docker pre-installed
SSH_KEY_NAME="strategy-engine"
CONFIG_FILE="${1:-config.yaml}"
DATA_DIR="Data"
OUTPUT_DIR="Outputs"

echo "============================================"
echo " Strategy Engine Cloud Runner"
echo "============================================"
echo "Droplet:  $DROPLET_NAME"
echo "Size:     $DROPLET_SIZE"
echo "Region:   $DROPLET_REGION"
echo "Config:   $CONFIG_FILE"
echo "============================================"

# --- Step 1: Create Droplet ---
echo ""
echo "[1/7] Creating droplet..."
DROPLET_ID=$(doctl compute droplet create "$DROPLET_NAME" \
    --size "$DROPLET_SIZE" \
    --image "$DROPLET_IMAGE" \
    --region "$DROPLET_REGION" \
    --ssh-keys "$(doctl compute ssh-key list --format ID --no-header | head -1)" \
    --wait \
    --format ID \
    --no-header)

echo "Droplet created: ID=$DROPLET_ID"

# Get IP address
DROPLET_IP=$(doctl compute droplet get "$DROPLET_ID" --format PublicIPv4 --no-header)
echo "IP: $DROPLET_IP"

# Wait for SSH to be ready
echo "[2/7] Waiting for SSH..."
for i in $(seq 1 30); do
    if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 root@"$DROPLET_IP" "echo ready" 2>/dev/null; then
        break
    fi
    echo "  Attempt $i/30..."
    sleep 10
done

# --- Step 2: Upload project ---
echo ""
echo "[3/7] Uploading project files..."
ssh root@"$DROPLET_IP" "mkdir -p /app/Data /app/Outputs"

# Upload code (rsync is faster for many files)
rsync -az --exclude '.git' --exclude '__pycache__' --exclude 'Outputs' --exclude 'Data' \
    --exclude '.claude' --exclude '*.rtf' --exclude 'paste.md' \
    "$PROJECT_DIR/" root@"$DROPLET_IP":/app/

# Upload data files
echo "[4/7] Uploading data files..."
rsync -az "$PROJECT_DIR/$DATA_DIR/" root@"$DROPLET_IP":/app/Data/

# Upload config override if specified
if [ "$CONFIG_FILE" != "config.yaml" ]; then
    scp "$PROJECT_DIR/$CONFIG_FILE" root@"$DROPLET_IP":/app/config.yaml
fi

# --- Step 3: Build and run ---
echo ""
echo "[5/7] Building Docker image on droplet..."
ssh root@"$DROPLET_IP" "cd /app && docker build -t strategy-engine ."

echo ""
echo "[6/7] Running pipeline..."
START_TIME=$(date +%s)

ssh root@"$DROPLET_IP" "docker run --rm \
    -v /app/Data:/app/Data:ro \
    -v /app/Outputs:/app/Outputs \
    strategy-engine"

END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))
echo "Pipeline completed in ${ELAPSED}s ($((ELAPSED / 60))m $((ELAPSED % 60))s)"

# --- Step 4: Download results ---
echo ""
echo "[7/7] Downloading results..."
RESULTS_DIR="$PROJECT_DIR/cloud_results/${DROPLET_NAME}"
mkdir -p "$RESULTS_DIR"
rsync -az root@"$DROPLET_IP":/app/Outputs/ "$RESULTS_DIR/"
echo "Results saved to: $RESULTS_DIR"

# --- Step 5: Destroy droplet ---
echo ""
echo "Destroying droplet $DROPLET_NAME..."
doctl compute droplet delete "$DROPLET_ID" --force
echo "Droplet destroyed. Run complete."

# --- Summary ---
echo ""
echo "============================================"
echo " CLOUD RUN COMPLETE"
echo "============================================"
echo "Results:    $RESULTS_DIR"
echo "Runtime:    ${ELAPSED}s ($((ELAPSED / 60))m)"
echo "Est. cost:  ~\$$(echo "scale=2; $ELAPSED * 0.095 / 3600" | bc) (at \$0.095/hr)"
echo "============================================"
```

### 2b. Create `cloud/run_cloud.ps1` for Windows PowerShell

Since you're on Windows, create a PowerShell equivalent:

```powershell
# =============================================================
# Cloud Pipeline Runner for DigitalOcean (Windows PowerShell)
# Usage: .\cloud\run_cloud.ps1 [-ConfigFile config.yaml]
# =============================================================
param(
    [string]$ConfigFile = "config.yaml"
)

$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$DropletName = "strategy-engine-$(Get-Date -Format 'yyyyMMdd-HHmm')"
$DropletSize = "c-8"
$DropletRegion = "sgp1"
$DropletImage = "docker-24-04"

Write-Host "============================================"
Write-Host " Strategy Engine Cloud Runner"
Write-Host "============================================"
Write-Host "Droplet:  $DropletName"
Write-Host "Size:     $DropletSize"
Write-Host "Region:   $DropletRegion"
Write-Host "Config:   $ConfigFile"
Write-Host "============================================"

# Step 1: Create Droplet
Write-Host "`n[1/7] Creating droplet..."
$SshKeyId = (doctl compute ssh-key list --format ID --no-header | Select-Object -First 1).Trim()
$DropletId = (doctl compute droplet create $DropletName `
    --size $DropletSize `
    --image $DropletImage `
    --region $DropletRegion `
    --ssh-keys $SshKeyId `
    --wait `
    --format ID `
    --no-header).Trim()

Write-Host "Droplet created: ID=$DropletId"
$DropletIp = (doctl compute droplet get $DropletId --format PublicIPv4 --no-header).Trim()
Write-Host "IP: $DropletIp"

# Step 2: Wait for SSH
Write-Host "`n[2/7] Waiting for SSH..."
for ($i = 1; $i -le 30; $i++) {
    $result = ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 root@$DropletIp "echo ready" 2>$null
    if ($result -eq "ready") { break }
    Write-Host "  Attempt $i/30..."
    Start-Sleep -Seconds 10
}

# Step 3: Upload project
Write-Host "`n[3/7] Uploading project files..."
ssh root@$DropletIp "mkdir -p /app/Data /app/Outputs"
scp -r "$ProjectDir\modules" root@${DropletIp}:/app/
scp "$ProjectDir\master_strategy_engine.py" root@${DropletIp}:/app/
scp "$ProjectDir\config.yaml" root@${DropletIp}:/app/
scp "$ProjectDir\requirements.txt" root@${DropletIp}:/app/
scp "$ProjectDir\Dockerfile" root@${DropletIp}:/app/
scp "$ProjectDir\run_evaluator.py" root@${DropletIp}:/app/

# Step 4: Upload data
Write-Host "`n[4/7] Uploading data files..."
scp -r "$ProjectDir\Data\*" root@${DropletIp}:/app/Data/

# Step 5: Build and run
Write-Host "`n[5/7] Building Docker image..."
ssh root@$DropletIp "cd /app && docker build -t strategy-engine ."

Write-Host "`n[6/7] Running pipeline..."
$StartTime = Get-Date
ssh root@$DropletIp "docker run --rm -v /app/Data:/app/Data:ro -v /app/Outputs:/app/Outputs strategy-engine"
$Elapsed = (Get-Date) - $StartTime
Write-Host "Pipeline completed in $([math]::Round($Elapsed.TotalMinutes, 1)) minutes"

# Step 6: Download results
Write-Host "`n[7/7] Downloading results..."
$ResultsDir = "$ProjectDir\cloud_results\$DropletName"
New-Item -ItemType Directory -Force -Path $ResultsDir | Out-Null
scp -r root@${DropletIp}:/app/Outputs/* $ResultsDir/
Write-Host "Results saved to: $ResultsDir"

# Step 7: Destroy droplet
Write-Host "`nDestroying droplet..."
doctl compute droplet delete $DropletId --force
Write-Host "Droplet destroyed."

# Summary
$EstCost = [math]::Round($Elapsed.TotalHours * 0.095, 2)
Write-Host "`n============================================"
Write-Host " CLOUD RUN COMPLETE"
Write-Host "============================================"
Write-Host "Results:    $ResultsDir"
Write-Host "Runtime:    $([math]::Round($Elapsed.TotalMinutes, 1)) minutes"
Write-Host "Est. cost:  ~`$$EstCost (at `$0.095/hr)"
Write-Host "============================================"
```

### 2c. Make the bash script executable

```bash
mkdir -p cloud
chmod +x cloud/run_cloud.sh
```

**Git commit**: `build: add cloud run scripts for DigitalOcean (bash + PowerShell)`

---

## STEP 3: Create cloud-specific config files

Different configs for different run scenarios. The local config.yaml stays
as-is for local testing. Cloud configs optimize for full compute.

### 3a. Create `cloud/config_full_es.yaml`

```yaml
# Full ES sweep across all timeframes
# Estimated runtime: 5-6 hours on c-8 droplet (~$0.50)

datasets:
  - path: "Data/ES_60m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "60m"

strategy_types: "all"

engine:
  initial_capital: 250000.0
  risk_per_trade: 0.01
  commission_per_contract: 2.00
  slippage_ticks: 4
  tick_value: 12.50
  dollars_per_point: 50.0

pipeline:
  max_workers_sweep: 7       # Leave 1 CPU free for system on c-8
  max_workers_refinement: 7
  max_candidates_to_refine: 5 # More candidates on cloud (more compute available)
  oos_split_date: "2019-01-01"

promotion_gate:
  min_profit_factor: 1.00
  min_average_trade: 0.00
  require_positive_net_pnl: false
  min_trades: 50
  min_trades_per_year: 3.0
  max_promoted_candidates: 20

leaderboard:
  min_net_pnl: 0.0
  min_pf: 1.00
  min_oos_pf: 1.00
  min_total_trades: 60

output_dir: "Outputs"
```

### 3b. Create `cloud/config_quick_test.yaml`

```yaml
# Quick test config — single family, fast validation
# Estimated runtime: 30-40 minutes on c-8 droplet (~$0.05)

datasets:
  - path: "Data/ES_60m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "60m"

strategy_types: "mean_reversion"

engine:
  initial_capital: 250000.0
  risk_per_trade: 0.01
  commission_per_contract: 2.00
  slippage_ticks: 4
  tick_value: 12.50
  dollars_per_point: 50.0

pipeline:
  max_workers_sweep: 7
  max_workers_refinement: 7
  max_candidates_to_refine: 2
  oos_split_date: "2019-01-01"

promotion_gate:
  min_profit_factor: 1.00
  min_average_trade: 0.00
  require_positive_net_pnl: false
  min_trades: 50
  min_trades_per_year: 3.0
  max_promoted_candidates: 10

leaderboard:
  min_net_pnl: 0.0
  min_pf: 1.00
  min_oos_pf: 1.00
  min_total_trades: 60

output_dir: "Outputs"
```

**Git commit**: `build: add cloud-specific config files`

---

## STEP 4: Add config file CLI argument support

The pipeline needs to accept a config path from the command line so
cloud scripts can pass different configs.

### 4a. Update master_strategy_engine.py

At the top of the file, after imports, add argparse support:

```python
import argparse
```

Then update the config loading section. Replace the current config loading
(wherever `load_config()` is called) with:

```python
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Master Strategy Engine")
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="Path to config YAML file (default: config.yaml)",
    )
    return parser.parse_args()
```

In the `if __name__ == "__main__":` block, at the very start, add:

```python
    args = parse_args()
```

Then update the config load call to use args.config:

```python
    _cfg = load_config(args.config)
```

Make sure any module-level code that currently calls `load_config()` is moved
inside `__main__` so it uses the CLI argument. If `_cfg` is used at module level
for constants (like CSV_PATH, OUTPUTS_DIR etc.), wrap those in a function or
move them into `__main__`.

This allows cloud scripts to do:
```bash
python master_strategy_engine.py --config cloud/config_full_es.yaml
```

### 4b. Update the Dockerfile CMD

```dockerfile
# Support config override via environment variable
CMD ["python", "master_strategy_engine.py", "--config", "config.yaml"]
```

And update the docker run command in both cloud scripts to pass config:

```bash
ssh root@"$DROPLET_IP" "docker run --rm \
    -v /app/Data:/app/Data:ro \
    -v /app/Outputs:/app/Outputs \
    -v /app/config.yaml:/app/config.yaml:ro \
    strategy-engine \
    python master_strategy_engine.py --config config.yaml"
```

**Git commit**: `feat: add --config CLI argument for config file path`

---

## STEP 5: Create DigitalOcean setup guide

This is a reference document, not code. It tells the user how to set up
DigitalOcean and doctl for the first time.

### 5a. Create `cloud/SETUP.md`

```markdown
# DigitalOcean Cloud Setup Guide

## One-time setup (do this once)

### 1. Create DigitalOcean account
- Go to https://www.digitalocean.com
- Sign up (they usually offer $200 free credit for new accounts)

### 2. Install doctl (DigitalOcean CLI)
Windows (PowerShell as admin):
```powershell
winget install DigitalOcean.Doctl
```
Or download from: https://docs.digitalocean.com/reference/doctl/how-to/install/

### 3. Authenticate doctl
```bash
doctl auth init
```
Paste your API token when prompted.
Generate a token at: https://cloud.digitalocean.com/account/api/tokens

### 4. Add SSH key
```bash
# Generate key if you don't have one
ssh-keygen -t ed25519 -C "strategy-engine"

# Add to DigitalOcean
doctl compute ssh-key import strategy-engine --public-key-file ~/.ssh/id_ed25519.pub
```

## Droplet size reference

| Size slug | vCPUs | RAM | $/hr | $/mo | Est. pipeline time (3 families) |
|-----------|-------|-----|------|------|-------------------------------|
| s-2vcpu-4gb | 2 | 4GB | $0.030 | $18 | ~15 hours |
| c-4 | 4 dedicated | 8GB | $0.048 | $32 | ~8 hours |
| **c-8** | **8 dedicated** | **16GB** | **$0.095** | **$63** | **~3 hours** |
| c-16 | 16 dedicated | 32GB | $0.190 | $126 | ~1.5 hours |

Recommended: **c-8** for most runs. Cost per full ES run: ~$0.30-0.50

## Running the pipeline

### Quick test (single family, ~30 min, ~$0.05)
```powershell
.\cloud\run_cloud.ps1 -ConfigFile cloud\config_quick_test.yaml
```

### Full ES run (all families, ~3 hours, ~$0.30)
```powershell
.\cloud\run_cloud.ps1 -ConfigFile cloud\config_full_es.yaml
```

### Check on a running droplet
```bash
doctl compute droplet list
ssh root@<DROPLET_IP> "docker logs -f $(docker ps -q)"
```

### Emergency: destroy all droplets
```bash
doctl compute droplet list --format ID --no-header | xargs -I {} doctl compute droplet delete {} --force
```

## Cost management
- Droplets are billed per hour while running
- The run script automatically destroys the droplet when done
- Set a billing alert at https://cloud.digitalocean.com/account/billing
- Typical full run cost: $0.30-0.50 per ES dataset
```

**Git commit**: `docs: add DigitalOcean setup guide and cost reference`

---

## STEP 6: Add cloud_results/ to .gitignore and update docs

### 6a. Update .gitignore

Add these lines:
```
cloud_results/
```

### 6b. Update CLAUDE.md

Add to the repo structure section:
```
├── cloud/
│   ├── run_cloud.sh            # Linux/Mac cloud run script
│   ├── run_cloud.ps1           # Windows cloud run script
│   ├── config_full_es.yaml     # Full ES sweep config
│   ├── config_quick_test.yaml  # Quick test config
│   └── SETUP.md                # DigitalOcean setup guide
├── Dockerfile
├── requirements.txt
├── .dockerignore
```

Update the issues list — check off:
- [x] Dataset path hardcoded to ES_60m (now configurable via config.yaml)
- [x] Config file instead of hardcoded constants

Add new items if relevant:
- [ ] Test Docker build locally before first cloud run
- [ ] Add multi-timeframe data files for ES (5m, 15m, 30m, daily)
- [ ] Add CL and NQ data exports from TradeStation

Update the "Last updated" line.

### 6c. Update CHANGELOG_DEV.md

Add new entry at the TOP:
```markdown
## 2026-03-17 — Session 3: Cloud deployment preparation

**What was done**:
- Created Dockerfile (python:3.11-slim based)
- Created requirements.txt
- Created cloud run scripts (bash + PowerShell) for automated DigitalOcean workflow
- Created cloud-specific configs (full_es, quick_test)
- Added --config CLI argument to master_strategy_engine.py
- Created DigitalOcean setup guide with cost reference

**Cloud workflow**:
1. run_cloud.ps1 creates a droplet
2. Uploads code + data via SCP
3. Builds Docker image on droplet
4. Runs pipeline inside container
5. Downloads results
6. Destroys droplet
Total estimated cost: $0.30-0.50 per full ES run on c-8

**Next session priorities**:
1. Test Docker build locally
2. First cloud test run (config_quick_test.yaml)
3. Export additional TradeStation data (ES 5m/15m/30m/daily, CL, NQ)
4. Create multi-instrument config and run
```

### 6d. Final commit and push

```bash
git add -A
git commit -m "Session 3: DigitalOcean cloud deployment setup"
git push origin main
```
