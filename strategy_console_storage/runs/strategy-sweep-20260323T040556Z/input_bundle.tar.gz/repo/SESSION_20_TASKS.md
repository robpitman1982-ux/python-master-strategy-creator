SESSION_20_TASKS.md

Stability & Architecture Cleanup — Strategy Console + Cloud Runner

Objective

Stabilize and simplify the Strategy Console + Cloud Runner architecture after the Session 18–19 changes.

During testing we discovered several issues:

Dataset path mismatch between console storage and engine configs
Streamlit compatibility errors (hide_index, LargeUtf8)
dashboard table rendering instability
inconsistent dataset discovery
unclear run launch workflow
quick-test config still pointing to repo-local Data/
fragile table rendering in the console
lack of canonical dataset resolver

Session 20 will clean the architecture so the system runs reliably from the console datasets and requires minimal manual patching.

1. DATASET PATH ARCHITECTURE FIX
Problem

The engine configs expect datasets in:

Data/

But the console stores them in:

~/strategy_console_storage/uploads

This caused the failure:

Dataset not found:
python-master-strategy-creator/Data/ES_60m_2008_2026_tradestation.csv
Solution

Implement a dataset resolver that supports:

absolute paths
console storage
repo Data/

Priority order:

1. absolute path
2. strategy_console_storage/uploads
3. repo Data/
Modify
cloud/launch_gcp_run.py

Create helper:

def resolve_dataset_path(path: str) -> Path:

Logic:

if absolute -> use
elif exists in uploads -> use
elif exists in repo Data -> use
else -> error

Use this everywhere dataset paths are loaded.

2. UPDATE QUICK TEST CONFIG

Modify:

cloud/config_quick_test.yaml

Change dataset reference to just the filename, not a path.

Example:

datasets:
  - path: "ES_60m_2008_2026_tradestation.csv"
    market: "ES"
    timeframe: "60m"

Dataset resolver will now locate it in uploads automatically.

3. STREAMLIT COMPATIBILITY FIX

We discovered the VM Streamlit stack does not support:

hide_index=True

and crashes on Arrow type:

LargeUtf8
Fix

Remove all usage of:

st.dataframe(...)

Replace with a safe wrapper:

render_table(df)

Create helper:

def render_table(df):
    try:
        st.dataframe(df, use_container_width=True)
    except Exception:
        st.code(df.to_string(index=False))

This prevents console crashes.

4. FIX DASHBOARD TABLE RENDERING

Edit:

dashboard.py

Replace all instances of:

st.dataframe(...)
st.table(...)

with:

render_table(...)

Affected sections:

Uploaded datasets
Run history
Export files
Leaderboard preview
5. ADD DATASET VALIDATION PANEL

Improve the Uploaded Datasets panel so it shows:

| filename | size | timeframe | market |

Parse timeframe automatically from filename.

Example:

ES_60m_2008_2026_tradestation.csv

Display:

market = ES
timeframe = 60m
6. ADD DATASET SELECTOR FOR RUNS

The console currently shows a dataset but does not allow selecting multiple.

Add UI control:

multiselect datasets

Allow operator to choose datasets for the run.

Example:

[ ] ES_daily
[ ] ES_60m
[ ] ES_30m
[ ] ES_15m

This will later feed into launcher arguments.

7. CLEAN RUN STORAGE DETECTION

Dashboard currently reports:

No launcher-managed runs found

Even when runs exist.

Update run discovery logic to scan:

~/strategy_console_storage/runs

Structure:

runs/
   run_YYYYMMDD_HHMMSS/
       metadata.json
       leaderboard.csv

Add fallback detection for older run structures.

8. ADD RUN STATUS LOGGING

Add simple run status file:

strategy_console_storage/run_status.json

Fields:

run_id
vm_status
run_state
dataset
start_time
end_time

Dashboard will read this to display:

Running
Completed
Failed
9. CLEAN LAUNCH COMMAND

Create new helper script:

scripts/run_console_job.py

This script should:

read datasets selected in console
build temporary config
call launcher

Example:

python scripts/run_console_job.py

This avoids manually editing YAML files.

10. FIX CLOUD RUN WORKFLOW

Improve run_cloud_sweep.py launch output so it prints:

CONFIG LOADED
DATASETS RESOLVED
VM LAUNCHING
UPLOAD START
SWEEP START
DOWNLOAD COMPLETE
VM DESTROY
RUN COMPLETE

This makes debugging easier.

11. DASHBOARD HEALTH PANEL

Add small panel:

System Health

Display:

Uploads directory OK
Runs directory OK
Exports directory OK
Dataset count
Latest run status
12. REMOVE HARD CODED PATHS

Search entire repo for:

Data/
strategy_console_storage/uploads

Replace with constants:

UPLOADS_DIR
RUNS_DIR
EXPORTS_DIR

Defined in a new file:

paths.py
13. TEST PLAN

After implementation verify:

Dataset discovery
dashboard shows uploaded datasets
Quick run
python run_cloud_sweep.py --config cloud/config_quick_test.yaml
Console launch
python scripts/run_console_job.py
VM lifecycle

Confirm:

VM launches
sweep runs
outputs downloaded
VM destroyed
14. FINAL RESULT

After Session 20 the system should have:

stable dashboard
no Streamlit crashes
automatic dataset resolution
simple run launching
consistent storage paths
clearer logs
Expected outcome

After this cleanup the workflow becomes:

1️⃣ Upload datasets
2️⃣ Open Strategy Console
3️⃣ Select datasets
4️⃣ Click run (future UI step)
5️⃣ VM runs sweep
6️⃣ Results appear automatically

No manual YAML editing required.