# SESSION 13A — Launcher Hardening Before Next GCP Run

## Objective

Perform a small, targeted stability pass on the cloud launcher before the next real run.

This session should ONLY modify the launcher infrastructure.

DO NOT change:

- strategy discovery logic
- master_strategy_engine.py
- ranking logic
- filter sweeps
- Monte Carlo logic

Focus only on launcher reliability.

Files expected to change:

- cloud/launch_gcp_run.py
- tests/test_cloud_launcher.py (small additions)
- possibly manifest structures


------------------------------------------------------------
Task 1 — Fix launcher status persistence
------------------------------------------------------------

Problem

Launcher status currently rebuilds payloads from a base template each time.

This causes previously written values to disappear such as:

- bundle_size_bytes
- vm_outcome
- run_outcome
- artifact paths

The dashboard depends on these values staying persistent.

Fix

Modify LauncherStatusStore.update() so it:

1. Loads existing launcher_status.json if it exists
2. Merges new fields onto the existing payload
3. Only falls back to base payload if file does not exist

Requirements

Always update:

- state
- stage
- message
- updated_utc

Never overwrite existing fields with None.


------------------------------------------------------------
Task 2 — Add provisioning metadata to manifest
------------------------------------------------------------

Problem

Dashboard cost estimation needs to know the provisioning model.

Currently this may not be present in the manifest.

Add these fields to RunManifest:

provisioning_model
machine_type
zone

Optional but helpful:

boot_disk_size
image_family

Ensure these fields propagate to launcher status if appropriate.


------------------------------------------------------------
Task 3 — Make remote runner fail fast
------------------------------------------------------------

Locate the REMOTE_RUNNER_SCRIPT definition.

Currently it contains:

set -uo pipefail

Replace with:

set -euo pipefail

Explanation:

- -e stops the script immediately if a command fails
- prevents partial execution states
- ensures launcher detects failure quickly


------------------------------------------------------------
Task 4 — Run engine unbuffered
------------------------------------------------------------

Change engine launch command inside REMOTE_RUNNER_SCRIPT.

Current:

python master_strategy_engine.py --config "$RUN_ROOT/config.yaml"

Replace with:

python -u master_strategy_engine.py --config "$RUN_ROOT/config.yaml"

Reason:

- prevents Python stdout buffering
- allows real-time log updates in engine_run.log
- improves monitoring reliability


------------------------------------------------------------
Task 5 — Add regression tests
------------------------------------------------------------

Update tests/test_cloud_launcher.py

Add tests covering:

Test A — Status persistence

Simulate:

1. Write launcher status with fields:
   - bundle_size_bytes
   - vm_outcome
   - run_outcome

2. Call LauncherStatusStore.update() again.

Ensure those fields remain.

------------------------------------------------------------

Test B — Runner script LF line endings

Verify:

create_remote_runner_file()

produces a script with LF-only endings.

Confirm:

b"\r\n" not present

------------------------------------------------------------

Test C — Runner script fail-fast

Ensure generated runner script contains:

set -euo pipefail

------------------------------------------------------------

Test D — Unbuffered engine launch

Ensure runner script includes:

python -u master_strategy_engine.py


------------------------------------------------------------
Task 6 — Final validation
------------------------------------------------------------

Run locally:

python -m py_compile cloud/launch_gcp_run.py dashboard.py

Then:

python -m pytest tests/test_smoke.py tests/test_cloud_launcher.py -v --basetemp=.tmp_pytest_run

All tests must pass.


------------------------------------------------------------
Acceptance criteria
------------------------------------------------------------

The following must be true:

1. launcher_status.json persists previously written fields
2. provisioning metadata available in manifest
3. remote runner uses set -euo pipefail
4. engine launched with python -u
5. tests pass locally
6. launcher still runs via:

python -m cloud.launch_gcp_run --config cloud/config_es_all_timeframes_gcp96.yaml


------------------------------------------------------------
Expected outcome
------------------------------------------------------------

After this session the launcher should be fully stable for unattended runs.

The next run should:

- launch VM
- execute engine
- stream logs reliably
- download artifacts
- destroy VM automatically
- preserve accurate status for dashboard monitoring