# SESSION 9 TASKS — GCP Automation Bug Fixes + Streamlit Dashboard
# Date: 2026-03-20

---

## Context

Session 8 fixed the critical portfolio evaluator timeframe bug and created GCP automation scripts. During the actual GCP run, we hit 10 automation bugs that required manual intervention. This session fixes ALL of them so the next run is truly unattended.

Additionally, Rob wants a local Streamlit dashboard to monitor cloud runs and review results, replacing the manual SSH + tail workflow.

Work through each step in order. Commit after each step. Push to GitHub when all done.

---

## Step 1: Fix GCP startup script — race condition and path issues

**File**: `cloud/gcp_startup.sh`

### Bugs found:
1. **Race condition**: Startup script grabbed the first CSV it found and moved on before all uploads finished
2. **Config not detected**: find pattern didn't match config.yaml uploaded late
3. **Wildcard in cp**: `cp *.csv` inside bash didn't expand in some contexts

### Fix — replace the "wait for data files" and "move files" sections:

Replace the entire section from `# --- Wait for data files ---` through `# --- Find config file ---` and the config block with:

```bash
# --- Wait for ALL data files ---
echo "[4/6] Waiting for data files to appear..."
# We need at least 1 CSV file. But we also wait an extra 30 seconds
# after the first file appears to allow remaining uploads to complete.
WAITED=0
MAX_WAIT=1800
DATA_FOUND=0
FIRST_FOUND_AT=0

while [ $WAITED -lt $MAX_WAIT ]; do
    CSV_COUNT=$(find $UPLOAD_SCAN_DIR -maxdepth 3 -name "ES_*.csv" -o -name "CL_*.csv" -o -name "NQ_*.csv" -o -name "GC_*.csv" 2>/dev/null | wc -l)
    
    if [ "$CSV_COUNT" -gt 0 ] && [ "$FIRST_FOUND_AT" -eq 0 ]; then
        FIRST_FOUND_AT=$WAITED
        echo "  First CSV found after ${WAITED}s. Waiting 60s for remaining uploads..."
    fi
    
    # Wait 60 seconds after first file to let all uploads complete
    if [ "$FIRST_FOUND_AT" -gt 0 ] && [ $((WAITED - FIRST_FOUND_AT)) -ge 60 ]; then
        CSV_COUNT=$(find $UPLOAD_SCAN_DIR -maxdepth 3 -name "ES_*.csv" -o -name "CL_*.csv" -o -name "NQ_*.csv" -o -name "GC_*.csv" 2>/dev/null | wc -l)
        echo "  Found $CSV_COUNT CSV file(s) total. Proceeding."
        DATA_FOUND=1
        break
    fi
    
    sleep 10
    WAITED=$((WAITED + 10))
    if [ $((WAITED % 60)) -eq 0 ]; then
        echo "  Still waiting for data files... (${WAITED}s elapsed)"
    fi
done

if [ $DATA_FOUND -eq 0 ]; then
    echo "ERROR: No data files found after ${MAX_WAIT}s. Exiting."
    exit 1
fi

# --- Move data files to correct location ---
echo "[5/6] Moving data files and config..."

# Copy ALL CSVs from any user's upload directory
for csv_file in $(find $UPLOAD_SCAN_DIR -maxdepth 3 -name "*.csv" 2>/dev/null); do
    cp "$csv_file" "$WORK_DIR/Data/"
    echo "  Copied: $(basename $csv_file)"
done

# Copy config if uploaded (look for .yaml files)
UPLOADED_CONFIG=$(find $UPLOAD_SCAN_DIR -maxdepth 3 -name "*.yaml" 2>/dev/null | head -1)
if [ -n "$UPLOADED_CONFIG" ]; then
    cp "$UPLOADED_CONFIG" "$WORK_DIR/config.yaml"
    echo "  Using uploaded config: $(basename $UPLOADED_CONFIG)"
else
    echo "  No config uploaded, using repo default"
fi

echo "  Data files in place:"
ls -la "$WORK_DIR/Data/"
echo "  Config:"
head -5 "$WORK_DIR/config.yaml"
```

Also update the "Run the engine" section — remove the `--config` flag since we now copy config.yaml to the repo root directly:

```bash
# --- Run the engine ---
echo "[6/6] Starting engine..."
cd "$WORK_DIR"
source venv/bin/activate

echo "RUNNING" > /tmp/engine_status
# Clear any old log
rm -f /tmp/engine_run.log

python master_strategy_engine.py > /tmp/engine_run.log 2>&1
EXIT_CODE=$?
```

**Commit**: `fix: startup script race condition — wait 60s after first CSV, explicit file copy`

---

## Step 2: Fix GCP PowerShell automation script — all SCP and path bugs

**File**: `cloud/run_gcp_job.ps1`

### Bugs found:
1. **Tilde expansion**: `~/uploads/` doesn't work with PuTTY's pscp.exe — must use `/home/<user>/uploads/`
2. **Working directory**: SCP commands used relative paths but cwd was wrong
3. **gcloud.ps1 stderr**: Python warnings routed through PS error pipeline — use `gcloud.cmd`
4. **ErrorActionPreference**: `Stop` killed script on benign warnings — use `Continue`
5. **OS Login username**: Hardcoded `Rob` — should detect from gcloud config

### Complete rewrite of the script:

Replace the entire content of `cloud/run_gcp_job.ps1` with:

```powershell
<#
.SYNOPSIS
    Fully automated GCP cloud run for the Strategy Discovery Engine.
    Creates VM -> uploads data -> waits for engine -> downloads results -> destroys VM.

.PARAMETER ConfigFile
    Path to the YAML config file. Default: cloud/config_es_all_timeframes_gcp96.yaml

.PARAMETER MachineType
    GCP machine type. Default: n2-highcpu-96

.PARAMETER Zone
    GCP zone. Default: australia-southeast2-a (Melbourne)

.PARAMETER DataDir
    Local directory containing CSV data files. Default: Data

.PARAMETER OutputDir
    Local directory prefix for results. Default: cloud_outputs

.PARAMETER InstanceName
    VM instance name. Default: strategy-sweep

.PARAMETER SkipDestroy
    If set, don't destroy the VM after downloading results.

.EXAMPLE
    .\cloud\run_gcp_job.ps1
    .\cloud\run_gcp_job.ps1 -ConfigFile cloud/config_es_5m_only.yaml -OutputDir cloud_outputs_5m
#>

param(
    [string]$ConfigFile = "cloud/config_es_all_timeframes_gcp96.yaml",
    [string]$MachineType = "n2-highcpu-96",
    [string]$Zone = "australia-southeast2-a",
    [string]$DataDir = "Data",
    [string]$OutputDir = "cloud_outputs",
    [string]$InstanceName = "strategy-sweep",
    [switch]$SkipDestroy = $false
)

# --- Critical PowerShell settings ---
# Use gcloud.cmd to bypass gcloud.ps1 which routes Python stderr through PS error pipeline
$Gcloud = "gcloud.cmd"
# Don't terminate on stderr warnings from gcloud
$ErrorActionPreference = "Continue"
# Use native OpenSSH instead of PuTTY (fixes freezing and tilde issues)
$env:CLOUDSDK_SSH_NATIVE = "1"

# --- Resolve paths ---
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Split-Path -Parent $ScriptDir
# Ensure we work from the project directory so relative paths work
Push-Location $ProjectDir

$StartupScript = "cloud/gcp_startup.sh"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmm"

# --- Detect GCP username (OS Login maps to lowercase email prefix) ---
$GcpAccount = (& $Gcloud config get-value account 2>$null).Trim()
$GcpUser = ($GcpAccount -split "@")[0] -replace "\.", "_"
if (-not $GcpUser) { $GcpUser = "rob" }
$RemoteHome = "/home/$GcpUser"
Write-Host "Detected GCP user: $GcpUser (home: $RemoteHome)" -ForegroundColor Gray

Write-Host "============================================" -ForegroundColor Cyan
Write-Host " GCP Strategy Engine - Automated Run" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Instance:  $InstanceName"
Write-Host "Machine:   $MachineType"
Write-Host "Zone:      $Zone"
Write-Host "Config:    $ConfigFile"
Write-Host "Data dir:  $DataDir"
Write-Host "Output:    $OutputDir"
Write-Host "GCP user:  $GcpUser"
Write-Host "============================================" -ForegroundColor Cyan

# ---------------------------------------------------------------
# STEP 1: Create VM with startup script
# ---------------------------------------------------------------
Write-Host "`n[1/7] Creating VM..." -ForegroundColor Yellow

# Check if instance already exists
$existing = & $Gcloud compute instances list --filter="name=$InstanceName" --format="value(name)" 2>$null
if ($existing) {
    Write-Host "  Instance '$InstanceName' already exists. Deleting..." -ForegroundColor Red
    & $Gcloud compute instances delete $InstanceName --zone=$Zone --quiet
    Start-Sleep -Seconds 15
}

& $Gcloud compute instances create $InstanceName `
    --zone=$Zone `
    --machine-type=$MachineType `
    --provisioning-model=SPOT `
    --instance-termination-action=STOP `
    --image-family=ubuntu-2404-lts-amd64 `
    --image-project=ubuntu-os-cloud `
    --boot-disk-size=120GB `
    --boot-disk-type=pd-ssd `
    --metadata-from-file startup-script=$StartupScript

Write-Host "  VM created." -ForegroundColor Green

# ---------------------------------------------------------------
# STEP 2: Wait for SSH
# ---------------------------------------------------------------
Write-Host "`n[2/7] Waiting for SSH..." -ForegroundColor Yellow

$sshReady = $false
for ($i = 1; $i -le 40; $i++) {
    $result = & $Gcloud compute ssh $InstanceName --zone=$Zone --command="echo ready" 2>$null
    if ($result -match "ready") {
        $sshReady = $true
        Write-Host "  SSH ready (attempt $i)" -ForegroundColor Green
        break
    }
    Write-Host "  Attempt $i/40..."
    Start-Sleep -Seconds 10
}

if (-not $sshReady) {
    Write-Host "ERROR: SSH not ready after 400s." -ForegroundColor Red
    Pop-Location
    exit 1
}

# ---------------------------------------------------------------
# STEP 3: Create uploads directory
# ---------------------------------------------------------------
Write-Host "`n[3/7] Creating upload directory..." -ForegroundColor Yellow

& $Gcloud compute ssh $InstanceName --zone=$Zone --command="mkdir -p $RemoteHome/uploads"

# ---------------------------------------------------------------
# STEP 4: Upload data files and config
# ---------------------------------------------------------------
Write-Host "`n[4/7] Uploading data files..." -ForegroundColor Yellow

# Upload CSVs — use FULL remote path (not ~, pscp can't expand it)
$csvFiles = Get-ChildItem -Path $DataDir -Filter "*.csv" -ErrorAction SilentlyContinue
if ($csvFiles.Count -eq 0) {
    Write-Host "ERROR: No CSV files found in $DataDir" -ForegroundColor Red
    Pop-Location
    exit 1
}

foreach ($csv in $csvFiles) {
    Write-Host "  Uploading $($csv.Name) ($([math]::Round($csv.Length / 1MB, 1)) MB)..."
    & $Gcloud compute scp "$($csv.FullName)" "${InstanceName}:${RemoteHome}/uploads/$($csv.Name)" --zone=$Zone
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  RETRY with --tunnel-through-iap..." -ForegroundColor Yellow
        & $Gcloud compute scp "$($csv.FullName)" "${InstanceName}:${RemoteHome}/uploads/$($csv.Name)" --zone=$Zone --tunnel-through-iap
    }
}

# Upload config
Write-Host "  Uploading config: $ConfigFile..."
& $Gcloud compute scp "$ConfigFile" "${InstanceName}:${RemoteHome}/uploads/config.yaml" --zone=$Zone

Write-Host "  All uploads complete." -ForegroundColor Green

# ---------------------------------------------------------------
# STEP 5: Poll for engine completion
# ---------------------------------------------------------------
Write-Host "`n[5/7] Waiting for engine to complete..." -ForegroundColor Yellow
Write-Host "  Startup script installs deps, clones repo, copies data, runs engine."
Write-Host "  Typical runtime: 4-5 hours for 4-timeframe ES sweep on 96 cores."
Write-Host ""

$pollStart = Get-Date
$engineDone = $false
$lastStatus = ""

while (-not $engineDone) {
    Start-Sleep -Seconds 60

    $elapsed = (Get-Date) - $pollStart
    $elapsedStr = "{0:hh\:mm\:ss}" -f $elapsed

    try {
        $status = & $Gcloud compute ssh $InstanceName --zone=$Zone --command="cat /tmp/engine_status 2>/dev/null || echo PENDING" 2>$null
        $status = ($status | Out-String).Trim()
    } catch {
        $status = "SSH_ERROR"
    }

    if ($status -ne $lastStatus) {
        Write-Host "  [$elapsedStr] Status changed: $status" -ForegroundColor Cyan
        $lastStatus = $status
    }

    # Detailed progress every 5 minutes
    $minElapsed = [math]::Floor($elapsed.TotalMinutes)
    if ($minElapsed -gt 0 -and $minElapsed % 5 -eq 0) {
        try {
            $logTail = & $Gcloud compute ssh $InstanceName --zone=$Zone --command="sudo tail -3 /tmp/engine_run.log 2>/dev/null" 2>$null
            if ($logTail) {
                $lastLine = ($logTail | Out-String).Trim().Split("`n")[-1]
                Write-Host "  [$elapsedStr] $lastLine" -ForegroundColor Gray
            }
        } catch { }
    }

    if ($status -match "COMPLETED") {
        Write-Host "`n  Engine completed!" -ForegroundColor Green
        $engineDone = $true
    }
    elseif ($status -match "FAILED") {
        Write-Host "`n  Engine FAILED. Downloading logs..." -ForegroundColor Red
        $engineDone = $true
    }

    # Check for SPOT preemption
    if (-not $engineDone) {
        try {
            $vmStatus = & $Gcloud compute instances describe $InstanceName --zone=$Zone --format="value(status)" 2>$null
            $vmStatus = ($vmStatus | Out-String).Trim()
            if ($vmStatus -eq "TERMINATED" -or $vmStatus -eq "STOPPED") {
                Write-Host "  [$elapsedStr] SPOT preempted! Restarting VM..." -ForegroundColor Red
                & $Gcloud compute instances start $InstanceName --zone=$Zone
                Start-Sleep -Seconds 60
            }
        } catch { }
    }
}

# ---------------------------------------------------------------
# STEP 6: Download results
# ---------------------------------------------------------------
Write-Host "`n[6/7] Downloading results..." -ForegroundColor Yellow

# First, copy outputs to user-accessible location on VM
& $Gcloud compute ssh $InstanceName --zone=$Zone --command="sudo cp -r /root/python-master-strategy-creator/Outputs $RemoteHome/outputs 2>/dev/null; sudo cp /tmp/engine_run.log $RemoteHome/outputs/ 2>/dev/null; sudo chown -R ${GcpUser}:${GcpUser} $RemoteHome/outputs/ 2>/dev/null"

$localOutputDir = "${OutputDir}_${Timestamp}"
New-Item -ItemType Directory -Path $localOutputDir -Force | Out-Null

& $Gcloud compute scp --recurse "${InstanceName}:${RemoteHome}/outputs" "$localOutputDir/" --zone=$Zone

if ($LASTEXITCODE -eq 0) {
    Write-Host "  Results saved to: $localOutputDir" -ForegroundColor Green

    $leaderboard = Get-ChildItem -Path $localOutputDir -Recurse -Filter "master_leaderboard.csv" | Select-Object -First 1
    if ($leaderboard) {
        Write-Host "`n  === MASTER LEADERBOARD ===" -ForegroundColor Cyan
        Get-Content $leaderboard.FullName | Select-Object -First 12
    }
} else {
    Write-Host "  WARNING: Download may have failed." -ForegroundColor Red
}

# ---------------------------------------------------------------
# STEP 7: DESTROY VM (always, unless -SkipDestroy)
# ---------------------------------------------------------------
if ($SkipDestroy) {
    Write-Host "`n[7/7] SKIPPING destroy (-SkipDestroy)" -ForegroundColor Yellow
    Write-Host "  Destroy manually: gcloud compute instances delete $InstanceName --zone=$Zone --quiet"
} else {
    Write-Host "`n[7/7] Destroying VM to stop billing..." -ForegroundColor Yellow
    & $Gcloud compute instances delete $InstanceName --zone=$Zone --quiet

    if ($LASTEXITCODE -eq 0) {
        Write-Host "  VM DESTROYED. No more charges." -ForegroundColor Green
    } else {
        Write-Host "  WARNING: Destroy may have failed! Run manually:" -ForegroundColor Red
        Write-Host "  gcloud compute instances delete $InstanceName --zone=$Zone --quiet" -ForegroundColor Red
    }
}

# ---------------------------------------------------------------
# Done
# ---------------------------------------------------------------
Pop-Location

$totalElapsed = (Get-Date) - $pollStart
Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host " Run Complete" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Total time:  $("{0:hh\:mm\:ss}" -f $totalElapsed)"
Write-Host "Results in:  $localOutputDir"
if (-not $SkipDestroy) {
    Write-Host "VM status:   DESTROYED" -ForegroundColor Green
}
Write-Host "============================================" -ForegroundColor Cyan
```

**Commit**: `fix: rewrite GCP PowerShell script — fix SCP paths, gcloud.cmd, tilde, cwd, user detection`

---

## Step 3: Fix bash GCP automation script (same issues)

**File**: `cloud/run_gcp_job.sh`

Apply the same fixes as the PowerShell script:
- Detect username from gcloud config
- Use full `/home/<user>/uploads/` paths instead of `~/uploads/`
- Resolve project directory for correct relative paths
- Clear old logs before restart
- Copy outputs to user-accessible location before download

The key changes to the SCP section:

```bash
# Detect GCP username
GCP_ACCOUNT=$(gcloud config get-value account 2>/dev/null)
GCP_USER=$(echo "$GCP_ACCOUNT" | cut -d@ -f1 | tr '.' '_')
REMOTE_HOME="/home/${GCP_USER}"

# ...

# Step 4: Upload — use full paths, not tilde
echo "[4/7] Uploading data files..."
for csv in "$DATA_DIR"/*.csv; do
    [ -f "$csv" ] || continue
    echo "  Uploading $(basename "$csv")..."
    gcloud compute scp "$csv" "${INSTANCE_NAME}:${REMOTE_HOME}/uploads/" --zone="$ZONE"
done
echo "  Uploading config..."
gcloud compute scp "$CONFIG_FILE" "${INSTANCE_NAME}:${REMOTE_HOME}/uploads/config.yaml" --zone="$ZONE"
```

And the download section:

```bash
# Step 6: Copy outputs to user-accessible path, then download
echo "[6/7] Downloading results..."
gcloud compute ssh "$INSTANCE_NAME" --zone="$ZONE" \
    --command="sudo cp -r /root/python-master-strategy-creator/Outputs ${REMOTE_HOME}/outputs; sudo cp /tmp/engine_run.log ${REMOTE_HOME}/outputs/; sudo chown -R ${GCP_USER}:${GCP_USER} ${REMOTE_HOME}/outputs/"
mkdir -p "$OUTPUT_DIR"
gcloud compute scp --recurse "${INSTANCE_NAME}:${REMOTE_HOME}/outputs" "$OUTPUT_DIR/" --zone="$ZONE"
```

**Commit**: `fix: bash GCP script — same path and user detection fixes as PowerShell`

---

## Step 4: Create Streamlit dashboard for monitoring and results

**File**: `dashboard.py`

### Requirements
Add `streamlit` to `requirements.txt` if not present.

### Dashboard features:

**Tab 1: Cloud Run Monitor**
- Input fields: VM instance name, zone (with defaults)
- "Check Status" button that runs `gcloud compute ssh ... --command="cat /tmp/engine_status; cat .../status.json"` and parses the output
- Progress bars per dataset showing sweep/refinement % from status.json
- Auto-refresh toggle (polls every 60 seconds)
- Shows: current dataset, current family, current stage, ETA, elapsed time
- Pipeline visualization: dataset1 [DONE] → dataset2 [SWEEP 45%] → dataset3 [PENDING] → dataset4 [PENDING]
- "Destroy VM" button with confirmation

**Tab 2: Results Explorer**
- File picker to select a cloud_outputs directory
- Loads master_leaderboard.csv and displays as interactive table
- Strategy detail expander: click a strategy to see its quality flag, IS/OOS PF, trade count, filters
- Portfolio review table if available
- Correlation matrix heatmap
- Yearly PnL bar chart per strategy
- Equity curve from strategy_returns.csv

**Tab 3: Prop Firm Simulator**
- Select strategies from leaderboard
- Choose prop firm config (Bootcamp $250K, High Stakes, Hyper Growth)
- Run Monte Carlo pass rate simulation
- Display: pass rate %, avg trades to pass, worst drawdown, equity curve fan chart

### Implementation notes:

Use `streamlit` with `pandas`, `plotly` for charts. The dashboard runs locally on Rob's Windows machine — no cloud deployment needed.

For the cloud monitor tab, shell out to gcloud via `subprocess.run()` to get status. Parse the JSON from status.json.

For the results explorer, just read CSVs from the selected output directory.

The Streamlit app should be launchable with:
```bash
streamlit run dashboard.py
```

### Skeleton structure:

```python
"""
Strategy Discovery Engine — Dashboard
Run: streamlit run dashboard.py
"""
from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(page_title="Strategy Engine Dashboard", layout="wide")

# --- Sidebar ---
st.sidebar.title("Strategy Engine")
tab = st.sidebar.radio("Navigate", ["Cloud Monitor", "Results Explorer", "Prop Firm Simulator"])

# ============================================================
# TAB 1: Cloud Monitor
# ============================================================
if tab == "Cloud Monitor":
    st.title("Cloud Run Monitor")
    
    col1, col2 = st.columns(2)
    instance = col1.text_input("Instance name", "strategy-sweep")
    zone = col2.text_input("Zone", "australia-southeast2-a")
    
    auto_refresh = st.checkbox("Auto-refresh every 60s", value=False)
    
    def run_gcloud_cmd(cmd: str) -> str:
        """Run a gcloud command and return stdout."""
        try:
            result = subprocess.run(
                f"gcloud compute ssh {instance} --zone={zone} --command=\"{cmd}\"",
                shell=True, capture_output=True, text=True, timeout=30,
                env={**__import__('os').environ, "CLOUDSDK_SSH_NATIVE": "1"},
            )
            return result.stdout.strip()
        except Exception as e:
            return f"ERROR: {e}"
    
    if st.button("Check Status") or auto_refresh:
        with st.spinner("Connecting to VM..."):
            # Get engine status
            status_raw = run_gcloud_cmd("cat /tmp/engine_status 2>/dev/null || echo PENDING")
            st.metric("Engine Status", status_raw)
            
            # Get all status.json files
            status_json_raw = run_gcloud_cmd(
                "for f in /root/python-master-strategy-creator/Outputs/*/status.json; do echo FILE:$f; sudo cat $f 2>/dev/null; done"
            )
            
            # Parse each dataset's status
            if "FILE:" in status_json_raw:
                chunks = status_json_raw.split("FILE:")
                for chunk in chunks:
                    if not chunk.strip():
                        continue
                    lines = chunk.strip().split("\n", 1)
                    filepath = lines[0].strip()
                    if len(lines) > 1:
                        try:
                            sj = json.loads(lines[1])
                            dataset = sj.get("dataset", "Unknown")
                            stage = sj.get("current_stage", "?")
                            family = sj.get("current_family", "?")
                            pct = sj.get("progress_pct", 0)
                            eta = sj.get("eta_seconds", 0)
                            elapsed = sj.get("elapsed_seconds", 0)
                            
                            st.subheader(f"Dataset: {dataset}")
                            cols = st.columns(4)
                            cols[0].metric("Family", family)
                            cols[1].metric("Stage", stage)
                            cols[2].metric("Progress", f"{pct:.0f}%")
                            cols[3].metric("ETA", f"{eta/60:.1f} min" if eta > 0 else "—")
                            st.progress(min(pct / 100, 1.0))
                            
                            completed = sj.get("families_completed", [])
                            remaining = sj.get("families_remaining", [])
                            st.caption(f"Completed: {completed} | Remaining: {remaining} | Elapsed: {elapsed/60:.0f} min")
                        except json.JSONDecodeError:
                            st.text(f"Could not parse status for {filepath}")
            
            # Engine log tail
            with st.expander("Engine Log (last 20 lines)"):
                log_tail = run_gcloud_cmd("sudo tail -20 /tmp/engine_run.log 2>/dev/null")
                st.code(log_tail)
    
    st.divider()
    
    # Destroy VM button
    if st.button("Destroy VM", type="primary"):
        if st.checkbox("I confirm I want to destroy the VM and stop all billing"):
            result = subprocess.run(
                f"gcloud compute instances delete {instance} --zone={zone} --quiet",
                shell=True, capture_output=True, text=True,
            )
            if result.returncode == 0:
                st.success("VM destroyed. No more charges.")
            else:
                st.error(f"Failed to destroy: {result.stderr}")

# ============================================================
# TAB 2: Results Explorer
# ============================================================
elif tab == "Results Explorer":
    st.title("Results Explorer")
    
    # Select output directory
    output_dirs = sorted(Path(".").glob("cloud_outputs*"))
    output_dirs += sorted(Path("Outputs").glob("*")) if Path("Outputs").exists() else []
    
    dir_options = [str(d) for d in output_dirs if d.is_dir()]
    if not dir_options:
        st.warning("No output directories found. Run a cloud job first.")
        st.stop()
    
    selected_dir = st.selectbox("Select output directory", dir_options)
    base = Path(selected_dir)
    
    # Find CSV files recursively
    def find_csv(name: str) -> Path | None:
        matches = list(base.rglob(name))
        return matches[0] if matches else None
    
    # Master Leaderboard
    ml_path = find_csv("master_leaderboard.csv")
    if ml_path:
        st.subheader("Master Leaderboard")
        ml = pd.read_csv(ml_path)
        
        # Color code by quality flag
        st.dataframe(
            ml[["rank", "market", "timeframe", "strategy_type", "leader_strategy_name",
                "quality_flag", "leader_pf", "is_pf", "oos_pf", "recent_12m_pf",
                "leader_trades", "leader_net_pnl"]].style.format({
                    "leader_pf": "{:.2f}", "is_pf": "{:.2f}", "oos_pf": "{:.2f}",
                    "recent_12m_pf": "{:.2f}", "leader_net_pnl": "${:,.0f}",
                }),
            use_container_width=True,
        )
    
    # Portfolio Review
    pr_path = find_csv("portfolio_review_table.csv")
    if pr_path:
        st.subheader("Portfolio Review (Monte Carlo + Stress Tests)")
        pr = pd.read_csv(pr_path)
        st.dataframe(pr, use_container_width=True)
    
    # Correlation Matrix
    corr_path = find_csv("correlation_matrix.csv")
    if corr_path:
        st.subheader("Strategy Correlations")
        corr = pd.read_csv(corr_path, index_col=0)
        import plotly.express as px
        fig = px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r",
                        zmin=-1, zmax=1, title="Return Correlation Matrix")
        st.plotly_chart(fig, use_container_width=True)
    
    # Yearly Stats
    ys_path = find_csv("yearly_stats_breakdown.csv")
    if ys_path:
        st.subheader("Yearly Performance")
        ys = pd.read_csv(ys_path)
        strategies = ys["strategy_name"].unique()
        selected_strat = st.selectbox("Select strategy", strategies)
        strat_data = ys[ys["strategy_name"] == selected_strat]
        
        import plotly.graph_objects as go
        fig = go.Figure()
        colors = ["green" if v > 0 else "red" for v in strat_data["net_pnl"]]
        fig.add_trace(go.Bar(x=strat_data["year"], y=strat_data["net_pnl"],
                             marker_color=colors, name="Net PnL"))
        fig.update_layout(title=f"Yearly PnL: {selected_strat}", yaxis_title="Net PnL ($)")
        st.plotly_chart(fig, use_container_width=True)
    
    # Strategy Returns / Equity Curve
    sr_path = find_csv("strategy_returns.csv")
    if sr_path:
        st.subheader("Equity Curves")
        sr = pd.read_csv(sr_path)
        strat_cols = [c for c in sr.columns if c != "exit_time"]
        
        import plotly.graph_objects as go
        fig = go.Figure()
        for col in strat_cols:
            # Truncate long column names for display
            display_name = col.split("_", 3)[-1] if "_" in col else col
            cumulative = sr[col].cumsum()
            fig.add_trace(go.Scatter(x=sr["exit_time"], y=cumulative,
                                     mode="lines", name=display_name))
        fig.update_layout(title="Cumulative Equity Curves", yaxis_title="Cumulative PnL ($)",
                          xaxis_title="Exit Time")
        st.plotly_chart(fig, use_container_width=True)

# ============================================================
# TAB 3: Prop Firm Simulator
# ============================================================
elif tab == "Prop Firm Simulator":
    st.title("Prop Firm Challenge Simulator")
    st.info("Select an output directory in Results Explorer first, then come back here.")
    
    # This tab will use strategy_returns.csv and the prop_firm_simulator module
    # to run Monte Carlo pass rate estimates
    
    output_dirs = sorted(Path(".").glob("cloud_outputs*"))
    dir_options = [str(d) for d in output_dirs if d.is_dir()]
    
    if not dir_options:
        st.warning("No output directories found.")
        st.stop()
    
    selected_dir = st.selectbox("Output directory", dir_options, key="prop_dir")
    sr_path = list(Path(selected_dir).rglob("strategy_returns.csv"))
    
    if not sr_path:
        st.warning("No strategy_returns.csv found in selected directory.")
        st.stop()
    
    sr = pd.read_csv(sr_path[0])
    strat_cols = [c for c in sr.columns if c != "exit_time"]
    
    selected_strat = st.selectbox("Select strategy", strat_cols)
    
    col1, col2, col3 = st.columns(3)
    firm = col1.selectbox("Prop firm", ["The5ers Bootcamp $250K", "The5ers Bootcamp $100K", "The5ers High Stakes"])
    n_sims = col2.number_input("Simulations", value=5000, min_value=100, max_value=50000, step=1000)
    source_capital = col3.number_input("Source capital ($)", value=250000, step=50000)
    
    if st.button("Run Simulation"):
        trade_pnls = sr[selected_strat].dropna()
        trade_pnls = trade_pnls[trade_pnls != 0].tolist()
        
        if len(trade_pnls) < 10:
            st.error(f"Not enough trades ({len(trade_pnls)}). Need at least 10.")
            st.stop()
        
        st.write(f"Running {n_sims} Monte Carlo simulations on {len(trade_pnls)} trades...")
        
        # Import and run simulator
        try:
            from modules.prop_firm_simulator import (
                The5ersBootcampConfig,
                The5ersHighStakesConfig,
                monte_carlo_pass_rate,
            )
            
            target_map = {
                "The5ers Bootcamp $250K": 250_000,
                "The5ers Bootcamp $100K": 100_000,
                "The5ers High Stakes": 100_000,
            }
            target = target_map.get(firm, 250_000)
            
            if "High Stakes" in firm:
                config = The5ersHighStakesConfig(target=target)
            else:
                config = The5ersBootcampConfig(target=target)
            
            with st.spinner("Running Monte Carlo..."):
                stats = monte_carlo_pass_rate(
                    trade_pnls=trade_pnls,
                    config=config,
                    n_sims=int(n_sims),
                    source_capital=float(source_capital),
                )
            
            # Display results
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Pass Rate", f"{stats['pass_rate']*100:.1f}%")
            col2.metric("Avg Trades to Pass", f"{stats['avg_trades_to_pass']:.0f}")
            col3.metric("Median Trades", f"{stats['median_trades_to_pass']:.0f}")
            col4.metric("Worst DD %", f"{stats['worst_dd_pct']*100:.1f}%")
            
            st.success(f"Monte Carlo complete: {stats['pass_rate']*100:.1f}% pass rate over {n_sims} simulations")
            
        except ImportError as e:
            st.error(f"Could not import prop firm simulator: {e}")
        except Exception as e:
            st.error(f"Simulation error: {e}")
```

### Add streamlit and plotly to requirements.txt:

```
numpy
pandas
pyyaml
pytest
streamlit
plotly
```

**Commit**: `feat: add Streamlit dashboard for cloud monitoring, results explorer, and prop firm simulator`

---

## Step 5: Update CLAUDE.md and CHANGELOG_DEV.md

### CLAUDE.md updates:
- Add `dashboard.py` to repository structure
- Mark completed: GCP automation bug fixes
- Add `streamlit` and `plotly` to requirements section
- Update "Last updated" line to Session 9
- Update test count if any new tests added

### CHANGELOG_DEV.md:
Add new entry at the TOP:

```
## 2026-03-20 — Session 9: GCP automation bug fixes + Streamlit dashboard

**What was done**:
- Fixed 10 automation bugs found during Session 8 GCP run:
  1. SCP tilde expansion: use /home/<user>/uploads/ instead of ~/uploads/
  2. Working directory: Push-Location to project dir before SCP
  3. Wildcard cp: explicit file-by-file copy in startup script
  4. Config path: copy to repo root config.yaml, no --config flag needed
  5. gcloud.cmd: bypass gcloud.ps1 stderr routing issue
  6. ErrorActionPreference=Continue: benign warnings no longer kill script
  7. Race condition: startup script waits 60s after first CSV before proceeding
  8. Config detection: broader find pattern for uploaded config
  9. Log clearing: rm old log before engine restart
  10. GCP username detection: auto-detect from gcloud config, don't hardcode Rob
- Rewrote cloud/run_gcp_job.ps1 with all fixes applied
- Updated cloud/run_gcp_job.sh with same fixes
- Updated cloud/gcp_startup.sh with race condition fix
- Created dashboard.py — Streamlit app with 3 tabs:
  - Cloud Monitor: SSH into VM, parse status.json, show progress bars + ETA
  - Results Explorer: load master_leaderboard, portfolio review, correlations, yearly PnL charts, equity curves
  - Prop Firm Simulator: select strategy, run MC pass rate, display metrics
- Added streamlit and plotly to requirements.txt

**Verified**:
- All existing smoke tests still pass
- Streamlit app launches with: streamlit run dashboard.py

**Next session priorities**:
1. Analyze Session 8 re-run results (with fixed portfolio evaluator)
2. Run prop firm simulator on all accepted strategies
3. Portfolio assembly for The5ers Bootcamp
4. ES 5m run, then CL/NQ/GC
```

**Commit**: `docs: update CLAUDE.md and CHANGELOG_DEV.md for Session 9`

---

## Final: Push to GitHub

```bash
git push origin main
```

---

## Summary of deliverables

| # | File | What |
|---|------|------|
| 1 | `cloud/gcp_startup.sh` | Fix race condition, wait 60s after first CSV, explicit file copy |
| 2 | `cloud/run_gcp_job.ps1` | Full rewrite: gcloud.cmd, /home/user/ paths, cwd fix, user detection, auto-destroy |
| 3 | `cloud/run_gcp_job.sh` | Same fixes as PowerShell version |
| 4 | `dashboard.py` | Streamlit dashboard: Cloud Monitor + Results Explorer + Prop Firm Simulator |
| 5 | `requirements.txt` | Add streamlit, plotly |
| 6 | `CLAUDE.md` | Updated issues, structure |
| 7 | `CHANGELOG_DEV.md` | Session 9 entry |

---

## How to run this session

Copy-paste this into VS Code terminal:

```
claude --dangerously-skip-permissions "Read SESSION_9_TASKS.md in the repo root. Follow every step in order. Commit after each step with the specified commit message. Run existing smoke tests after Step 2 to verify nothing broke: python -m pytest tests/test_smoke.py -v. Test that the Streamlit app at least imports without error: python -c 'import dashboard'. Push to GitHub at the end. Do not skip any steps."
```
